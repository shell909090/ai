typedef unsigned char   undefined;

typedef unsigned char    byte;
typedef unsigned char    dwfenc;
typedef unsigned int    dword;
typedef unsigned long    qword;
typedef unsigned char    uchar;
typedef unsigned int    uint;
typedef unsigned long    ulong;
typedef unsigned char    undefined1;
typedef unsigned short    undefined2;
typedef unsigned int    undefined4;
typedef unsigned long    undefined8;
typedef unsigned short    ushort;
typedef int    wchar_t;
typedef unsigned short    word;
typedef struct eh_frame_hdr eh_frame_hdr, *Peh_frame_hdr;

struct eh_frame_hdr {
    byte eh_frame_hdr_version; // Exception Handler Frame Header Version
    dwfenc eh_frame_pointer_encoding; // Exception Handler Frame Pointer Encoding
    dwfenc eh_frame_desc_entry_count_encoding; // Encoding of # of Exception Handler FDEs
    dwfenc eh_frame_table_encoding; // Exception Handler Table Encoding
};

typedef struct NoteGnuPropertyElement_4 NoteGnuPropertyElement_4, *PNoteGnuPropertyElement_4;

struct NoteGnuPropertyElement_4 {
    dword prType;
    dword prDatasz;
    byte data[4];
};

typedef struct fde_table_entry fde_table_entry, *Pfde_table_entry;

struct fde_table_entry {
    dword initial_loc; // Initial Location
    dword data_loc; // Data location
};

typedef void _IO_lock_t;

typedef struct _IO_marker _IO_marker, *P_IO_marker;

typedef struct _IO_FILE _IO_FILE, *P_IO_FILE;

typedef long __off_t;

typedef long __off64_t;

typedef ulong size_t;

struct _IO_FILE {
    int _flags;
    char *_IO_read_ptr;
    char *_IO_read_end;
    char *_IO_read_base;
    char *_IO_write_base;
    char *_IO_write_ptr;
    char *_IO_write_end;
    char *_IO_buf_base;
    char *_IO_buf_end;
    char *_IO_save_base;
    char *_IO_backup_base;
    char *_IO_save_end;
    struct _IO_marker *_markers;
    struct _IO_FILE *_chain;
    int _fileno;
    int _flags2;
    __off_t _old_offset;
    ushort _cur_column;
    char _vtable_offset;
    char _shortbuf[1];
    _IO_lock_t *_lock;
    __off64_t _offset;
    void *__pad1;
    void *__pad2;
    void *__pad3;
    void *__pad4;
    size_t __pad5;
    int _mode;
    char _unused2[20];
};

struct _IO_marker {
    struct _IO_marker *_next;
    struct _IO_FILE *_sbuf;
    int _pos;
};

typedef struct stat stat, *Pstat;

typedef ulong __dev_t;

typedef ulong __ino_t;

typedef ulong __nlink_t;

typedef uint __mode_t;

typedef uint __uid_t;

typedef uint __gid_t;

typedef long __blksize_t;

typedef long __blkcnt_t;

typedef struct timespec timespec, *Ptimespec;

typedef long __time_t;

struct timespec {
    __time_t tv_sec;
    long tv_nsec;
};

struct stat {
    __dev_t st_dev;
    __ino_t st_ino;
    __nlink_t st_nlink;
    __mode_t st_mode;
    __uid_t st_uid;
    __gid_t st_gid;
    int __pad0;
    __dev_t st_rdev;
    __off_t st_size;
    __blksize_t st_blksize;
    __blkcnt_t st_blocks;
    struct timespec st_atim;
    struct timespec st_mtim;
    struct timespec st_ctim;
    long __unused[3];
};

typedef int __clockid_t;

typedef __clockid_t clockid_t;

typedef struct tm tm, *Ptm;

struct tm {
    int tm_sec;
    int tm_min;
    int tm_hour;
    int tm_mday;
    int tm_mon;
    int tm_year;
    int tm_wday;
    int tm_yday;
    int tm_isdst;
    long tm_gmtoff;
    char *tm_zone;
};

typedef __time_t time_t;

typedef union _union_1457 _union_1457, *P_union_1457;

typedef struct siginfo siginfo, *Psiginfo;

typedef struct siginfo siginfo_t;

typedef void (*__sighandler_t)(int);

typedef union _union_1441 _union_1441, *P_union_1441;

typedef struct _struct_1442 _struct_1442, *P_struct_1442;

typedef struct _struct_1443 _struct_1443, *P_struct_1443;

typedef struct _struct_1444 _struct_1444, *P_struct_1444;

typedef struct _struct_1445 _struct_1445, *P_struct_1445;

typedef struct _struct_1446 _struct_1446, *P_struct_1446;

typedef struct _struct_1447 _struct_1447, *P_struct_1447;

typedef int __pid_t;

typedef union sigval sigval, *Psigval;

typedef union sigval sigval_t;

typedef long __clock_t;

struct _struct_1445 {
    __pid_t si_pid;
    __uid_t si_uid;
    int si_status;
    __clock_t si_utime;
    __clock_t si_stime;
};

union sigval {
    int sival_int;
    void *sival_ptr;
};

struct _struct_1444 {
    __pid_t si_pid;
    __uid_t si_uid;
    sigval_t si_sigval;
};

struct _struct_1443 {
    int si_tid;
    int si_overrun;
    sigval_t si_sigval;
};

struct _struct_1446 {
    void *si_addr;
};

struct _struct_1447 {
    long si_band;
    int si_fd;
};

struct _struct_1442 {
    __pid_t si_pid;
    __uid_t si_uid;
};

union _union_1441 {
    int _pad[28];
    struct _struct_1442 _kill;
    struct _struct_1443 _timer;
    struct _struct_1444 _rt;
    struct _struct_1445 _sigchld;
    struct _struct_1446 _sigfault;
    struct _struct_1447 _sigpoll;
};

union _union_1457 {
    __sighandler_t sa_handler;
    void (*sa_sigaction)(int, siginfo_t *, void *);
};

struct siginfo {
    int si_signo;
    int si_errno;
    int si_code;
    union _union_1441 _sifields;
};

typedef struct sigaction sigaction, *Psigaction;

typedef struct __sigset_t __sigset_t, *P__sigset_t;

struct __sigset_t {
    ulong __val[16];
};

struct sigaction {
    union _union_1457 __sigaction_handler;
    struct __sigset_t sa_mask;
    int sa_flags;
    void (*sa_restorer)(void);
};

typedef struct __jmp_buf_tag __jmp_buf_tag, *P__jmp_buf_tag;

typedef long __jmp_buf[8];

struct __jmp_buf_tag {
    __jmp_buf __jmpbuf;
    int __mask_was_saved;
    struct __sigset_t __saved_mask;
};

typedef struct _IO_FILE FILE;

typedef uint wint_t;

typedef struct __sigset_t sigset_t;

typedef long __ssize_t;

typedef __ssize_t ssize_t;

typedef int __int32_t;

typedef struct passwd passwd, *Ppasswd;

struct passwd {
    char *pw_name;
    char *pw_passwd;
    __uid_t pw_uid;
    __gid_t pw_gid;
    char *pw_gecos;
    char *pw_dir;
    char *pw_shell;
};

typedef int nl_item;

typedef struct __dirstream __dirstream, *P__dirstream;

struct __dirstream {
};

typedef struct __dirstream DIR;

typedef struct dirent dirent, *Pdirent;

struct dirent {
    __ino_t d_ino;
    __off_t d_off;
    ushort d_reclen;
    uchar d_type;
    char d_name[256];
};

typedef struct __mbstate_t __mbstate_t, *P__mbstate_t;

typedef union _union_27 _union_27, *P_union_27;

union _union_27 {
    uint __wch;
    char __wchb[4];
};

struct __mbstate_t {
    int __count;
    union _union_27 __value;
};

typedef struct __mbstate_t mbstate_t;

typedef enum Elf_ProgramHeaderType {
    PT_NULL=0,
    PT_LOAD=1,
    PT_DYNAMIC=2,
    PT_INTERP=3,
    PT_NOTE=4,
    PT_SHLIB=5,
    PT_PHDR=6,
    PT_TLS=7,
    PT_GNU_EH_FRAME=1685382480,
    PT_GNU_STACK=1685382481,
    PT_GNU_RELRO=1685382482
} Elf_ProgramHeaderType;

typedef struct Elf64_Rela Elf64_Rela, *PElf64_Rela;

struct Elf64_Rela {
    qword r_offset; // location to apply the relocation action
    qword r_info; // the symbol table index and the type of relocation
    qword r_addend; // a constant addend used to compute the relocatable field value
};

typedef struct Elf64_Dyn Elf64_Dyn, *PElf64_Dyn;

typedef enum Elf64_DynTag {
    DT_NULL=0,
    DT_NEEDED=1,
    DT_PLTRELSZ=2,
    DT_PLTGOT=3,
    DT_HASH=4,
    DT_STRTAB=5,
    DT_SYMTAB=6,
    DT_RELA=7,
    DT_RELASZ=8,
    DT_RELAENT=9,
    DT_STRSZ=10,
    DT_SYMENT=11,
    DT_INIT=12,
    DT_FINI=13,
    DT_SONAME=14,
    DT_RPATH=15,
    DT_SYMBOLIC=16,
    DT_REL=17,
    DT_RELSZ=18,
    DT_RELENT=19,
    DT_PLTREL=20,
    DT_DEBUG=21,
    DT_TEXTREL=22,
    DT_JMPREL=23,
    DT_BIND_NOW=24,
    DT_INIT_ARRAY=25,
    DT_FINI_ARRAY=26,
    DT_INIT_ARRAYSZ=27,
    DT_FINI_ARRAYSZ=28,
    DT_RUNPATH=29,
    DT_FLAGS=30,
    DT_PREINIT_ARRAY=32,
    DT_PREINIT_ARRAYSZ=33,
    DT_RELRSZ=35,
    DT_RELR=36,
    DT_RELRENT=37,
    DT_ANDROID_REL=1610612751,
    DT_ANDROID_RELSZ=1610612752,
    DT_ANDROID_RELA=1610612753,
    DT_ANDROID_RELASZ=1610612754,
    DT_ANDROID_RELR=1879040000,
    DT_ANDROID_RELRSZ=1879040001,
    DT_ANDROID_RELRENT=1879040003,
    DT_GNU_PRELINKED=1879047669,
    DT_GNU_CONFLICTSZ=1879047670,
    DT_GNU_LIBLISTSZ=1879047671,
    DT_CHECKSUM=1879047672,
    DT_PLTPADSZ=1879047673,
    DT_MOVEENT=1879047674,
    DT_MOVESZ=1879047675,
    DT_FEATURE_1=1879047676,
    DT_POSFLAG_1=1879047677,
    DT_SYMINSZ=1879047678,
    DT_SYMINENT=1879047679,
    DT_GNU_XHASH=1879047924,
    DT_GNU_HASH=1879047925,
    DT_TLSDESC_PLT=1879047926,
    DT_TLSDESC_GOT=1879047927,
    DT_GNU_CONFLICT=1879047928,
    DT_GNU_LIBLIST=1879047929,
    DT_CONFIG=1879047930,
    DT_DEPAUDIT=1879047931,
    DT_AUDIT=1879047932,
    DT_PLTPAD=1879047933,
    DT_MOVETAB=1879047934,
    DT_SYMINFO=1879047935,
    DT_VERSYM=1879048176,
    DT_RELACOUNT=1879048185,
    DT_RELCOUNT=1879048186,
    DT_FLAGS_1=1879048187,
    DT_VERDEF=1879048188,
    DT_VERDEFNUM=1879048189,
    DT_VERNEED=1879048190,
    DT_VERNEEDNUM=1879048191,
    DT_AUXILIARY=2147483645,
    DT_FILTER=2147483647
} Elf64_DynTag;

struct Elf64_Dyn {
    enum Elf64_DynTag d_tag;
    qword d_val;
};

typedef struct Elf64_Sym Elf64_Sym, *PElf64_Sym;

struct Elf64_Sym {
    dword st_name;
    byte st_info;
    byte st_other;
    word st_shndx;
    qword st_value;
    qword st_size;
};

typedef struct Elf64_Shdr Elf64_Shdr, *PElf64_Shdr;

typedef enum Elf_SectionHeaderType {
    SHT_NULL=0,
    SHT_PROGBITS=1,
    SHT_SYMTAB=2,
    SHT_STRTAB=3,
    SHT_RELA=4,
    SHT_HASH=5,
    SHT_DYNAMIC=6,
    SHT_NOTE=7,
    SHT_NOBITS=8,
    SHT_REL=9,
    SHT_SHLIB=10,
    SHT_DYNSYM=11,
    SHT_INIT_ARRAY=14,
    SHT_FINI_ARRAY=15,
    SHT_PREINIT_ARRAY=16,
    SHT_GROUP=17,
    SHT_SYMTAB_SHNDX=18,
    SHT_ANDROID_REL=1610612737,
    SHT_ANDROID_RELA=1610612738,
    SHT_GNU_ATTRIBUTES=1879048181,
    SHT_GNU_HASH=1879048182,
    SHT_GNU_LIBLIST=1879048183,
    SHT_CHECKSUM=1879048184,
    SHT_SUNW_move=1879048186,
    SHT_SUNW_COMDAT=1879048187,
    SHT_SUNW_syminfo=1879048188,
    SHT_GNU_verdef=1879048189,
    SHT_GNU_verneed=1879048190,
    SHT_GNU_versym=1879048191
} Elf_SectionHeaderType;

struct Elf64_Shdr {
    dword sh_name;
    enum Elf_SectionHeaderType sh_type;
    qword sh_flags;
    qword sh_addr;
    qword sh_offset;
    qword sh_size;
    dword sh_link;
    dword sh_info;
    qword sh_addralign;
    qword sh_entsize;
};

typedef struct GnuBuildId GnuBuildId, *PGnuBuildId;

struct GnuBuildId {
    dword namesz; // Length of name field
    dword descsz; // Length of description field
    dword type; // Vendor specific type
    char name[4]; // Vendor name
    byte hash[20];
};

typedef struct NoteGnuProperty_4 NoteGnuProperty_4, *PNoteGnuProperty_4;

struct NoteGnuProperty_4 {
    dword namesz; // Length of name field
    dword descsz; // Length of description field
    dword type; // Vendor specific type
    char name[4]; // Vendor name
};

typedef struct Elf64_Phdr Elf64_Phdr, *PElf64_Phdr;

struct Elf64_Phdr {
    enum Elf_ProgramHeaderType p_type;
    dword p_flags;
    qword p_offset;
    qword p_vaddr;
    qword p_paddr;
    qword p_filesz;
    qword p_memsz;
    qword p_align;
};

typedef struct Elf64_Ehdr Elf64_Ehdr, *PElf64_Ehdr;

struct Elf64_Ehdr {
    byte e_ident_magic_num;
    char e_ident_magic_str[3];
    byte e_ident_class;
    byte e_ident_data;
    byte e_ident_version;
    byte e_ident_osabi;
    byte e_ident_abiversion;
    byte e_ident_pad[7];
    word e_type;
    word e_machine;
    dword e_version;
    qword e_entry;
    qword e_phoff;
    qword e_shoff;
    dword e_flags;
    word e_ehsize;
    word e_phentsize;
    word e_phnum;
    word e_shentsize;
    word e_shnum;
    word e_shstrndx;
};

typedef struct NoteAbiTag NoteAbiTag, *PNoteAbiTag;

struct NoteAbiTag {
    dword namesz; // Length of name field
    dword descsz; // Length of description field
    dword type; // Vendor specific type
    char name[4]; // Vendor name
    dword abiType; // 0 == Linux
    dword requiredKernelVersion[3]; // Major.minor.patch
};

typedef struct GnuDebugLink_48 GnuDebugLink_48, *PGnuDebugLink_48;

struct GnuDebugLink_48 {
    char filename[48];
    dword crc;
};

typedef struct lconv lconv, *Plconv;

struct lconv {
    char *decimal_point;
    char *thousands_sep;
    char *grouping;
    char *int_curr_symbol;
    char *currency_symbol;
    char *mon_decimal_point;
    char *mon_thousands_sep;
    char *mon_grouping;
    char *positive_sign;
    char *negative_sign;
    char int_frac_digits;
    char frac_digits;
    char p_cs_precedes;
    char p_sep_by_space;
    char n_cs_precedes;
    char n_sep_by_space;
    char p_sign_posn;
    char n_sign_posn;
    char int_p_cs_precedes;
    char int_p_sep_by_space;
    char int_n_cs_precedes;
    char int_n_sep_by_space;
    char int_p_sign_posn;
    char int_n_sign_posn;
};

typedef struct group group, *Pgroup;

struct group {
    char *gr_name;
    char *gr_passwd;
    __gid_t gr_gid;
    char **gr_mem;
};



undefined8 stderr;
undefined4 error_message_count;
undefined8 stdout;
undefined DAT_0011d529;
undefined8 error_print_progname;
int DAT_00128418;
char *DAT_00128410;
undefined DAT_0011d536;
undefined4 error_one_per_line;
undefined4 DAT_001271f8;
undefined4 DAT_00128230;
undefined1 DAT_001282d8;
long *DAT_001283a0;
undefined8 DAT_00128390;
uint DAT_0012835c;
ulong DAT_001282d0;
long DAT_00128220;
undefined *DAT_001282e0;
byte DAT_001282f8;
undefined1 DAT_001283c8;
undefined8 DAT_001282f0;
uint DAT_00128334;
undefined8 DAT_001282e8;
byte DAT_00128331;
char DAT_00127019;
byte DAT_00128338;
int DAT_00128350;
byte DAT_00128332;
byte DAT_00128314;
undefined1 DAT_0012831d;
int DAT_00128318;
char DAT_00128315;
byte DAT_00128316;
long DAT_001283e8;
byte DAT_00128389;
byte DAT_0012834c;
undefined8 DAT_001282c8;
byte DAT_001282c2;
byte DAT_001282c1;
undefined1 DAT_001282c0;
undefined8 DAT_001283d8;
undefined8 DAT_001283e0;
long DAT_001283d0;
char DAT_00128330;
undefined8 DAT_00127060;
pointer PTR_DAT_00127068;
int DAT_00128234;
int DAT_00128238;
undefined8 DAT_00127070;
undefined *PTR_DAT_00127078;
long DAT_00128118;
undefined DAT_00128110;
long DAT_00128218;
undefined *DAT_001283a8;
undefined *DAT_00128320;
size_t *DAT_00128328;
long DAT_001270d0;
undefined *PTR_DAT_001270d8;
char DAT_001283b0;
undefined *PTR_DAT_00127040;
undefined *PTR_s_%b_%e_%H:%M_00127048;
int DAT_001271e0;
char DAT_00128354;
undefined8 DAT_00128340;
undefined4 DAT_00128348;
undefined4 DAT_0012833c;
long DAT_00127020;
undefined8 DAT_00128398;
undefined *PTR_FUN_001271f0;
undefined4 DAT_00128358;
undefined8 *DAT_00128300;
undefined1 DAT_0012834e;
undefined1 DAT_0012834f;
undefined1 DAT_00127028;
undefined1 DAT_0012834d;
undefined1 DAT_0012831c;
undefined1 DAT_00127029;
undefined4 DAT_00128310;
undefined *PTR_DAT_001271e8;
undefined DAT_0011b680;
undefined DAT_0011b6c0;
undefined DAT_0011b6f0;
undefined DAT_0011b710;
undefined DAT_0011b7c0;
undefined DAT_0011cf4c;
undefined DAT_0011d0ee;
undefined DAT_0011d0ef;
undefined4 optind;
undefined free;
undefined DAT_0011d1ab;
string s_%Y-%m-%d_%H:%M:%S.%N_%z_0011d20a;
undefined DAT_0011d222;
undefined8 optarg;
undefined DAT_0011d225;
string s_%Y-%m-%d_0011d231;
undefined DAT_0011d277;
undefined malloc;
undefined DAT_00120220;
undefined *PTR_s_always_00126200;
undefined DAT_00126260;
undefined DAT_001262c0;
undefined *PTR_s_verbose_00126300;
pointer PTR_s_all_00126340;
undefined *PTR_DAT_001268e0;
pointer PTR_s_full-iso_00126920;
undefined *PTR_s_literal_001269a0;
undefined DAT_00128000;
undefined FUN_00106880;
undefined FUN_0010fe00;
undefined DAT_00128100;
undefined DAT_00128160;
undefined FUN_00106890;
undefined DAT_001281c0;
uint switchdataD_0011b174;
undefined FUN_00104c00;
char DAT_001272c8;
undefined *PTR_LOOP_00127008;
int DAT_00128334;
undefined8 *DAT_00128308;
int DAT_0012835c;
char DAT_0012831c;
undefined4 DAT_00128350;
uint DAT_00128358;
char DAT_00127029;
byte DAT_00127028;
char DAT_0012834e;
undefined DAT_0011b5d0;
byte DAT_00127018;
undefined1 DAT_001273e8;
pointer PTR_DAT_00127040;
undefined DAT_00127400;
undefined8 *DAT_001283a0;
undefined strcmp;
ulong DAT_001282e0;
undefined DAT_0011cf00;
int DAT_00128230;
undefined DAT_00128240;
undefined DAT_00128250;
undefined DAT_00128260;
undefined DAT_00128270;
undefined DAT_00128280;
undefined FUN_00107750;
undefined DAT_00128290;
undefined DAT_001282a0;
undefined DAT_001282b0;
undefined4 DAT_0011b600;
undefined DAT_0011b630;
undefined8 UNK_00128248;
undefined8 UNK_00128258;
undefined8 UNK_00128268;
undefined8 UNK_00128278;
undefined8 UNK_00128288;
undefined8 UNK_00128298;
undefined8 UNK_001282a8;
undefined8 UNK_001282b8;
undefined FUN_00106900;
long DAT_00127088;
undefined DAT_00127080;
undefined DAT_00127090;
char DAT_001283c8;
char DAT_001283c9;
int DAT_00128384;
char DAT_0012834c;
int DAT_00128380;
char DAT_00128389;
int DAT_00128378;
ulong DAT_00128220;
ulong DAT_001283d0;
undefined8 DAT_001272e0;
char *DAT_00128228;
long DAT_001283c0;
char DAT_0012834d;
undefined DAT_0011cf05;
undefined1 DAT_001283c9;
undefined1 DAT_00128388;
undefined4 DAT_00128384;
undefined4 DAT_00128380;
undefined4 DAT_0012837c;
undefined4 DAT_00128374;
undefined4 DAT_00128370;
undefined4 DAT_0012836c;
undefined4 DAT_00128378;
undefined4 DAT_00128368;
undefined4 DAT_00128364;
undefined4 DAT_00128360;
undefined DAT_0012702a;
ulong DAT_001283b8;
long *DAT_001283c0;
long DAT_001283e0;
uint DAT_00128350;
long DAT_001282d0;
int DAT_00128358;
byte DAT_0012834f;
undefined *PTR_FUN_00125fc0;
undefined DAT_00127320;
ulong DAT_001270a0;
char *DAT_001270a8;
undefined8 DAT_001283a8;
char DAT_00128338;
undefined DAT_0011cf32;
undefined DAT_0011cf46;
char DAT_00128332;
ulong DAT_00127120;
char *DAT_00127128;
ulong DAT_00127130;
char *DAT_00127138;
ulong DAT_00127180;
undefined *PTR_DAT_00127188;
ulong DAT_00127190;
undefined *PTR_DAT_00127198;
ulong DAT_001271a0;
undefined *PTR_DAT_001271a8;
ulong DAT_00127160;
undefined *PTR_DAT_00127168;
ulong DAT_00127140;
undefined *PTR_DAT_00127148;
ulong DAT_001271c0;
char *DAT_001271c8;
ulong DAT_00127170;
undefined *PTR_DAT_00127178;
undefined DAT_0011b640;
undefined DAT_001271d0;
char DAT_00128388;
char DAT_00127028;
undefined8 DAT_00127020;
int DAT_00128360;
int DAT_00127014;
char DAT_001273e8;
long DAT_00128398;
int DAT_00128368;
int DAT_00128364;
undefined1 DAT_0011cf4d;
undefined DAT_0011cf57;
undefined DAT_0011cf5a;
undefined DAT_0011cf5f;
undefined DAT_0011cf64;
undefined8 DAT_001270a0;
undefined8 *DAT_001283c0;
byte DAT_00127019;
undefined4 DAT_0012835c;
long DAT_00128228;
byte DAT_001282c0;
uint DAT_00128318;
char DAT_00127310;
long DAT_00127308;
byte DAT_00128388;
char DAT_0012831d;
int DAT_0012837c;
int DAT_0012836c;
int DAT_00128370;
int DAT_00128374;
char DAT_001272f0;
long DAT_001272e8;
uint DAT_001272f4;
undefined8 DAT_00127300;
uint DAT_001272f8;
char DAT_00128331;
char DAT_001282c2;
char DAT_001282c1;
undefined DAT_0011b7e0;
undefined DAT_0011b8e0;
undefined DAT_0011d505;
undefined8 *DAT_00128118;
long DAT_00128120;
char DAT_00128316;
char DAT_00127010;
int DAT_00128310;
char DAT_001282d8;
undefined8 DAT_00128448;
undefined DAT_0011d011;
undefined DAT_0011d503;
undefined FUN_001126e0;
undefined FUN_00112710;
undefined FUN_00112760;
undefined8 DAT_001283f8;
undefined1 DAT_001283f0;
char DAT_001283f0;
int DAT_001271f8;
long DAT_001283f8;
undefined lgetxattr;
undefined getxattr;
undefined DAT_0011fcb2;
undefined FUN_00118c40;
undefined llistxattr;
undefined FUN_00118d40;
undefined listxattr;
undefined8 program_invocation_short_name;
undefined DAT_0011fcc0;
undefined FUN_00111480;
undefined FUN_001114a0;
undefined DAT_0011fc90;
undefined DAT_0011fce8;
undefined DAT_0011fce0;
pointer PTR_s_human-readable_00126980;
__uid_t *DAT_00128438;
__uid_t *DAT_00128430;
__gid_t *DAT_00128428;
__gid_t *DAT_00128420;
undefined8 DAT_00128440;
uint switchdataD_0011fcf4;
pointer obstack_alloc_failed_handler;
undefined8 program_invocation_name;
char *DAT_00128448;
undefined DAT_0011d670;
undefined DAT_0011d674;
undefined DAT_0011d679;
undefined DAT_0011d67d;
undefined DAT_0011d681;
undefined *PTR_DAT_00127260;
int DAT_00127258;
undefined DAT_00127270;
undefined *PTR_DAT_00127278;
undefined DAT_00128460;
undefined4 DAT_00128560;
undefined DAT_00128560;
undefined8 DAT_00128590;
undefined DAT_00128570;
undefined DAT_00128580;
undefined8 DAT_00128588;
undefined DAT_00128568;
undefined8 UNK_00128578;
undefined4 DAT_0012856c;
undefined DAT_00127220;
uint switchdataD_00120248;
undefined DAT_0011d6fc;
undefined DAT_0011d7d6;

void _DT_INIT(void)

{
  __gmon_start__();
  return;
}



void FUN_00104020(void)

{
  (*(code *)(undefined *)0x0)();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

__int32_t ** __ctype_toupper_loc(void)

{
  __int32_t **pp_Var1;
  
  pp_Var1 = __ctype_toupper_loc();
  return pp_Var1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

char * getenv(char *__name)

{
  char *pcVar1;
  
  pcVar1 = getenv(__name);
  return pcVar1;
}



void cap_to_text(void)

{
  cap_to_text();
  return;
}



void fgetfilecon(void)

{
  fgetfilecon();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int sigprocmask(int __how,sigset_t *__set,sigset_t *__oset)

{
  int iVar1;
  
  iVar1 = sigprocmask(__how,__set,__oset);
  return iVar1;
}



void __snprintf_chk(void)

{
  __snprintf_chk();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int raise(int __sig)

{
  int iVar1;
  
  iVar1 = raise(__sig);
  return iVar1;
}



void __vfprintf_chk(void)

{
  __vfprintf_chk();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int * __errno_location(void)

{
  int *piVar1;
  
  piVar1 = __errno_location();
  return piVar1;
}



void getfilecon_raw(void)

{
  getfilecon_raw();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int strncmp(char *__s1,char *__s2,size_t __n)

{
  int iVar1;
  
  iVar1 = strncmp(__s1,__s2,__n);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

tm * localtime_r(time_t *__timer,tm *__tp)

{
  tm *ptVar1;
  
  ptVar1 = localtime_r(__timer,__tp);
  return ptVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void _exit(int __status)

{
                    // WARNING: Subroutine does not return
  _exit(__status);
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

char * strcpy(char *__dest,char *__src)

{
  char *pcVar1;
  
  pcVar1 = strcpy(__dest,__src);
  return pcVar1;
}



void __fpending(void)

{
  __fpending();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

ssize_t flistxattr(int __fd,char *__list,size_t __size)

{
  ssize_t sVar1;
  
  sVar1 = flistxattr(__fd,__list,__size);
  return sVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int isatty(int __fd)

{
  int iVar1;
  
  iVar1 = isatty(__fd);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int sigaction(int __sig,sigaction *__act,sigaction *__oact)

{
  int iVar1;
  
  iVar1 = sigaction(__sig,__act,__oact);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int iswcntrl(wint_t __wc)

{
  int iVar1;
  
  iVar1 = iswcntrl(__wc);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

lconv * localeconv(void)

{
  lconv *plVar1;
  
  plVar1 = localeconv();
  return plVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int faccessat(int __fd,char *__file,int __type,int __flag)

{
  int iVar1;
  
  iVar1 = faccessat(__fd,__file,__type,__flag);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

ssize_t readlink(char *__path,char *__buf,size_t __len)

{
  ssize_t sVar1;
  
  sVar1 = readlink(__path,__buf,__len);
  return sVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int fcntl(int __fd,int __cmd,...)

{
  int iVar1;
  
  iVar1 = fcntl(__fd,__cmd);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int clock_gettime(clockid_t __clock_id,timespec *__tp)

{
  int iVar1;
  
  iVar1 = clock_gettime(__clock_id,__tp);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int setenv(char *__name,char *__value,int __replace)

{
  int iVar1;
  
  iVar1 = setenv(__name,__value,__replace);
  return iVar1;
}



void textdomain(void)

{
  textdomain();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int fclose(FILE *__stream)

{
  int iVar1;
  
  iVar1 = fclose(__stream);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

DIR * opendir(char *__name)

{
  DIR *pDVar1;
  
  pDVar1 = opendir(__name);
  return pDVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

passwd * getpwuid(__uid_t __uid)

{
  passwd *ppVar1;
  
  ppVar1 = getpwuid(__uid);
  return ppVar1;
}



void bindtextdomain(void)

{
  bindtextdomain();
  return;
}



void dcgettext(void)

{
  dcgettext();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

size_t __ctype_get_mb_cur_max(void)

{
  size_t sVar1;
  
  sVar1 = __ctype_get_mb_cur_max();
  return sVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

size_t strlen(char *__s)

{
  size_t sVar1;
  
  sVar1 = strlen(__s);
  return sVar1;
}



void __stack_chk_fail(void)

{
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void getopt_long(void)

{
  getopt_long();
  return;
}



void freecon(void)

{
  freecon();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

char * strchr(char *__s,int __c)

{
  char *pcVar1;
  
  pcVar1 = strchr(__s,__c);
  return pcVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

group * getgrgid(__gid_t __gid)

{
  group *pgVar1;
  
  pgVar1 = getgrgid(__gid);
  return pgVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int snprintf(char *__s,size_t __maxlen,char *__format,...)

{
  int iVar1;
  
  iVar1 = snprintf(__s,__maxlen,__format);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int __overflow(_IO_FILE *param_1,int param_2)

{
  int iVar1;
  
  iVar1 = __overflow(param_1,param_2);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

char * strrchr(char *__s,int __c)

{
  char *pcVar1;
  
  pcVar1 = strrchr(__s,__c);
  return pcVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

tm * gmtime_r(time_t *__timer,tm *__tp)

{
  tm *ptVar1;
  
  ptVar1 = gmtime_r(__timer,__tp);
  return ptVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

__off_t lseek(int __fd,__off_t __offset,int __whence)

{
  __off_t _Var1;
  
  _Var1 = lseek(__fd,__offset,__whence);
  return _Var1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void __assert_fail(char *__assertion,char *__file,uint __line,char *__function)

{
                    // WARNING: Subroutine does not return
  __assert_fail(__assertion,__file,__line,__function);
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int fnmatch(char *__pattern,char *__name,int __flags)

{
  int iVar1;
  
  iVar1 = fnmatch(__pattern,__name,__flags);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void * memset(void *__s,int __c,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memset(__s,__c,__n);
  return pvVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int ioctl(int __fd,ulong __request,...)

{
  int iVar1;
  
  iVar1 = ioctl(__fd,__request);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

size_t strnlen(char *__string,size_t __maxlen)

{
  size_t sVar1;
  
  sVar1 = strnlen(__string,__maxlen);
  return sVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

char * getcwd(char *__buf,size_t __size)

{
  char *pcVar1;
  
  pcVar1 = getcwd(__buf,__size);
  return pcVar1;
}



void mbrtoc32(void)

{
  mbrtoc32();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

size_t strspn(char *__s,char *__accept)

{
  size_t sVar1;
  
  sVar1 = strspn(__s,__accept);
  return sVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int closedir(DIR *__dirp)

{
  int iVar1;
  
  iVar1 = closedir(__dirp);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int memcmp(void *__s1,void *__s2,size_t __n)

{
  int iVar1;
  
  iVar1 = memcmp(__s1,__s2,__n);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int _setjmp(__jmp_buf_tag *__env)

{
  int iVar1;
  
  iVar1 = _setjmp(__env);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int fputs_unlocked(char *__s,FILE *__stream)

{
  int iVar1;
  
  iVar1 = fputs_unlocked(__s,__stream);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void * rawmemchr(void *__s,int __c)

{
  void *pvVar1;
  
  pvVar1 = rawmemchr(__s,__c);
  return pvVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void * calloc(size_t __nmemb,size_t __size)

{
  void *pvVar1;
  
  pvVar1 = calloc(__nmemb,__size);
  return pvVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

__sighandler_t signal(int __sig,__sighandler_t __handler)

{
  __sighandler_t p_Var1;
  
  p_Var1 = signal(__sig,__handler);
  return p_Var1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int dirfd(DIR *__dirp)

{
  int iVar1;
  
  iVar1 = dirfd(__dirp);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int fputc_unlocked(int __c,FILE *__stream)

{
  int iVar1;
  
  iVar1 = fputc_unlocked(__c,__stream);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

passwd * getpwnam(char *__name)

{
  passwd *ppVar1;
  
  ppVar1 = getpwnam(__name);
  return ppVar1;
}



void __memcpy_chk(void)

{
  __memcpy_chk();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int sigemptyset(sigset_t *__set)

{
  int iVar1;
  
  iVar1 = sigemptyset(__set);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int stat(char *__file,stat *__buf)

{
  int iVar1;
  
  iVar1 = stat(__file,__buf);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void * memcpy(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memcpy(__dest,__src,__n);
  return pvVar1;
}



void lgetfilecon_raw(void)

{
  lgetfilecon_raw();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

group * getgrnam(char *__name)

{
  group *pgVar1;
  
  pgVar1 = getgrnam(__name);
  return pgVar1;
}



void __isoc23_strtoumax(void)

{
  __isoc23_strtoumax();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void tzset(void)

{
  tzset();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int fileno(FILE *__stream)

{
  int iVar1;
  
  iVar1 = fileno(__stream);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

__pid_t tcgetpgrp(int __fd)

{
  __pid_t _Var1;
  
  _Var1 = tcgetpgrp(__fd);
  return _Var1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

dirent * readdir(DIR *__dirp)

{
  dirent *pdVar1;
  
  pdVar1 = readdir(__dirp);
  return pdVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

char * strerror_r(int __errnum,char *__buf,size_t __buflen)

{
  char *pcVar1;
  
  pcVar1 = strerror_r(__errnum,__buf,__buflen);
  return pcVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int wcwidth(wchar_t __c)

{
  int iVar1;
  
  iVar1 = wcwidth(__c);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int fflush(FILE *__stream)

{
  int iVar1;
  
  iVar1 = fflush(__stream);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

char * nl_langinfo(nl_item __item)

{
  char *pcVar1;
  
  pcVar1 = nl_langinfo(__item);
  return pcVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int strcoll(char *__s1,char *__s2)

{
  int iVar1;
  
  iVar1 = strcoll(__s1,__s2);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

time_t mktime(tm *__tp)

{
  time_t tVar1;
  
  tVar1 = mktime(__tp);
  return tVar1;
}



void __freading(void)

{
  __freading();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

ssize_t fgetxattr(int __fd,char *__name,void *__value,size_t __size)

{
  ssize_t sVar1;
  
  sVar1 = fgetxattr(__fd,__name,__value,__size);
  return sVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

size_t fwrite_unlocked(void *__ptr,size_t __size,size_t __n,FILE *__stream)

{
  size_t sVar1;
  
  sVar1 = fwrite_unlocked(__ptr,__size,__n,__stream);
  return sVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void * realloc(void *__ptr,size_t __size)

{
  void *pvVar1;
  
  pvVar1 = realloc(__ptr,__size);
  return pvVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

char * setlocale(int __category,char *__locale)

{
  char *pcVar1;
  
  pcVar1 = setlocale(__category,__locale);
  return pcVar1;
}



void __printf_chk(void)

{
  __printf_chk();
  return;
}



void statx(void)

{
  statx();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

time_t timegm(tm *__tp)

{
  time_t tVar1;
  
  tVar1 = timegm(__tp);
  return tVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

size_t strftime(char *__s,size_t __maxsize,char *__format,tm *__tp)

{
  size_t sVar1;
  
  sVar1 = strftime(__s,__maxsize,__format,__tp);
  return sVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void * mempcpy(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = mempcpy(__dest,__src,__n);
  return pvVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void * memmove(void *__dest,void *__src,size_t __n)

{
  void *pvVar1;
  
  pvVar1 = memmove(__dest,__src,__n);
  return pvVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int fseeko(FILE *__stream,__off_t __off,int __whence)

{
  int iVar1;
  
  iVar1 = fseeko(__stream,__off,__whence);
  return iVar1;
}



void cap_get_file(void)

{
  cap_get_file();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int unsetenv(char *__name)

{
  int iVar1;
  
  iVar1 = unsetenv(__name);
  return iVar1;
}



void cap_free(void)

{
  cap_free();
  return;
}



void __cxa_atexit(void)

{
  __cxa_atexit();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int gethostname(char *__name,size_t __len)

{
  int iVar1;
  
  iVar1 = gethostname(__name,__len);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int sigismember(sigset_t *__set,int __signo)

{
  int iVar1;
  
  iVar1 = sigismember(__set,__signo);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void exit(int __status)

{
                    // WARNING: Subroutine does not return
  exit(__status);
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

size_t fwrite(void *__ptr,size_t __size,size_t __n,FILE *__s)

{
  size_t sVar1;
  
  sVar1 = fwrite(__ptr,__size,__n,__s);
  return sVar1;
}



void __fprintf_chk(void)

{
  __fprintf_chk();
  return;
}



void getfilecon(void)

{
  getfilecon();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int fflush_unlocked(FILE *__stream)

{
  int iVar1;
  
  iVar1 = fflush_unlocked(__stream);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int mbsinit(mbstate_t *__ps)

{
  int iVar1;
  
  iVar1 = mbsinit(__ps);
  return iVar1;
}



void lgetfilecon(void)

{
  lgetfilecon();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int iswprint(wint_t __wc)

{
  int iVar1;
  
  iVar1 = iswprint(__wc);
  return iVar1;
}



void fgetfilecon_raw(void)

{
  fgetfilecon_raw();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int sigaddset(sigset_t *__set,int __signo)

{
  int iVar1;
  
  iVar1 = sigaddset(__set,__signo);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

__int32_t ** __ctype_tolower_loc(void)

{
  __int32_t **pp_Var1;
  
  pp_Var1 = __ctype_tolower_loc();
  return pp_Var1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

ushort ** __ctype_b_loc(void)

{
  ushort **ppuVar1;
  
  ppuVar1 = __ctype_b_loc();
  return ppuVar1;
}



void __sprintf_chk(void)

{
  __sprintf_chk();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void free(void *__ptr)

{
  free(__ptr);
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int strcmp(char *__s1,char *__s2)

{
  int iVar1;
  
  iVar1 = strcmp(__s1,__s2);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void * malloc(size_t __size)

{
  void *pvVar1;
  
  pvVar1 = malloc(__size);
  return pvVar1;
}



void __cxa_finalize(void)

{
  __cxa_finalize();
  return;
}



void switchD_00106d53::default(void)

{
                    // WARNING: Subroutine does not return
  __assert_fail("sort_type != sort_version","src/ls.c",0x1017,"sort_files");
}



void FUN_0010475f(void)

{
                    // WARNING: Subroutine does not return
  __assert_fail("dev_ino_size <= __extension__ ({ struct obstack const *__o = (&dev_ino_obstack); (size_t) (__o->next_free - __o->object_base); })"
                ,"src/ls.c",0x442,"dev_ino_pop");
}



void FUN_001047bc(int param_1)

{
  char *pcVar1;
  long in_FS_OFFSET;
  char local_410 [1024];
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  pcVar1 = strerror_r(param_1,local_410,0x400);
  if (pcVar1 == (char *)0x0) {
    pcVar1 = (char *)dcgettext("gnulib","Unknown system error",5);
  }
  __fprintf_chk(stderr,1,": %s",pcVar1);
  if (local_10 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return;
}



undefined8
FUN_0010483d(int param_1,int param_2,undefined8 param_3,undefined8 param_4,undefined8 param_5)

{
  char *pcVar1;
  
  __vfprintf_chk(stderr,1);
  error_message_count = error_message_count + 1;
  if (param_2 != 0) {
    FUN_001047bc(param_2);
  }
  pcVar1 = stderr->_IO_write_ptr;
  if (pcVar1 < stderr->_IO_write_end) {
    stderr->_IO_write_ptr = pcVar1 + 1;
    *pcVar1 = '\n';
  }
  else {
    __overflow(stderr,10);
  }
  fflush_unlocked(stderr);
  if (param_1 != 0) {
                    // WARNING: Subroutine does not return
    exit(param_1);
  }
  return param_5;
}



int FUN_001048aa(void)

{
  int iVar1;
  int in_ECX;
  
  iVar1 = fcntl(1,3);
  if (-1 < iVar1) {
    iVar1 = fflush_unlocked(stdout);
    return iVar1;
  }
  return in_ECX;
}



void FUN_001048cf(undefined4 param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  FUN_001048aa();
  if (error_print_progname == (code *)0x0) {
    uVar1 = FUN_00111270();
    __fprintf_chk(stderr,1,&DAT_0011d529,uVar1);
  }
  else {
    (*error_print_progname)();
  }
  FUN_0010483d(param_1,param_2,param_3,param_4);
  return;
}



void error(void)

{
  long lVar1;
  long in_FS_OFFSET;
  
  lVar1 = *(long *)(in_FS_OFFSET + 0x28);
  FUN_001048cf();
  if (lVar1 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return;
}



undefined8
FUN_001049e2(undefined4 param_1,undefined4 param_2,char *param_3,int param_4,undefined8 param_5,
            undefined8 param_6)

{
  int iVar1;
  int iVar2;
  undefined8 uVar3;
  char *pcVar4;
  undefined8 in_R10;
  
  pcVar4 = DAT_00128410;
  iVar1 = DAT_00128418;
  if (((error_one_per_line != 0) && (pcVar4 = param_3, iVar1 = param_4, DAT_00128418 == param_4)) &&
     ((DAT_00128410 == param_3 ||
      (((pcVar4 = param_3, iVar1 = param_4, param_3 != (char *)0x0 &&
        (pcVar4 = param_3, iVar1 = param_4, DAT_00128410 != (char *)0x0)) &&
       (iVar2 = strcmp(DAT_00128410,param_3), pcVar4 = param_3, iVar1 = param_4, iVar2 == 0)))))) {
    return in_R10;
  }
  DAT_00128418 = iVar1;
  DAT_00128410 = pcVar4;
  FUN_001048aa();
  if (error_print_progname == (code *)0x0) {
    uVar3 = FUN_00111270();
    __fprintf_chk(stderr,1,&DAT_0011d536,uVar3);
  }
  else {
    (*error_print_progname)();
  }
  pcVar4 = " ";
  if (param_3 != (char *)0x0) {
    pcVar4 = "%s:%u: ";
  }
  __fprintf_chk(stderr,1,pcVar4,param_3,param_4);
  uVar3 = FUN_0010483d(param_1,param_2,param_5,param_6,in_R10);
  return uVar3;
}



void error_at_line(void)

{
  long lVar1;
  long in_FS_OFFSET;
  
  lVar1 = *(long *)(in_FS_OFFSET + 0x28);
  FUN_001049e2();
  if (lVar1 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



void FUN_00104b8c(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void switchD_00116736::default(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



void FUN_00104bb5(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void abort(void)

{
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

undefined4 FUN_00104c00(uint param_1,FILE *param_2)

{
  char cVar1;
  void *__s1;
  byte bVar2;
  FILE *__stream;
  ulong uVar3;
  char cVar4;
  undefined1 uVar5;
  char cVar6;
  byte bVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  long lVar11;
  undefined8 *puVar12;
  void *pvVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  ulong uVar16;
  size_t sVar17;
  size_t *psVar18;
  char *pcVar19;
  undefined **ppuVar20;
  long *__ptr;
  size_t *psVar21;
  char *pcVar22;
  undefined *puVar23;
  undefined8 *puVar24;
  undefined *in_R9;
  undefined8 *in_R10;
  undefined8 in_R11;
  char *pcVar25;
  long lVar26;
  size_t *psVar27;
  long in_FS_OFFSET;
  bool bVar28;
  int local_90;
  int local_8c;
  char *local_88;
  ulong local_80;
  undefined *local_78;
  int local_70;
  char *local_60;
  undefined8 local_58;
  undefined8 uStack_50;
  char local_44;
  char local_43;
  undefined1 local_42;
  long local_40;
  
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  FUN_00116460(*(undefined8 *)param_2);
  setlocale(6,"");
  bindtextdomain("coreutils","/usr/share/locale");
  textdomain("coreutils");
  DAT_001271f8 = 2;
  FUN_0011ace0(FUN_0010fe00);
  DAT_00128230 = 0;
  DAT_001282d8 = 1;
  DAT_001283a0 = (long *)0x0;
  local_80 = 0xffffffffffffffff;
  local_78 = (undefined *)0xffffffffffffffff;
  local_90 = -1;
  local_8c = -1;
  local_70 = -1;
  uVar10 = 0xffffffff;
  bVar28 = false;
  local_88 = (char *)0x0;
  DAT_00128390 = 0x8000000000000000;
  DAT_00128398 = 0xffffffffffffffff;
LAB_00104d00:
  ppuVar20 = &PTR_s_all_00126340;
  puVar23 = (undefined *)(ulong)param_1;
  local_58 = (undefined *)CONCAT44(local_58._4_4_,0xffffffff);
  puVar24 = &local_58;
  iVar8 = getopt_long(puVar23,param_2,"abcdfghiklmnopqrstuvw:xABCDFGHI:LNQRST:UXZ1");
  if (iVar8 != -1) {
    if (0x114 < iVar8 + 0x83U) goto switchD_00104d37_caseD_ffffff7f;
    switch(iVar8) {
    case 0x31:
      uVar10 = (uint)(uVar10 != 0);
      break;
    case 0x41:
      DAT_00128310 = 1;
      break;
    case 0x42:
      FUN_00106ce0(&DAT_0011d0ef);
      FUN_00106ce0(&DAT_0011d0ee);
      break;
    case 0x43:
      uVar10 = 2;
      break;
    case 0x44:
      in_R11 = 0;
      DAT_00128331 = 0;
      DAT_00128338 = 1;
      uVar10 = 0;
      break;
    case 0x46:
      if (optarg != (char *)0x0) {
        in_R9 = (undefined *)0x1;
        in_R10 = puVar24;
        lVar26 = FUN_0010f1d0("--classify",optarg,&PTR_s_always_00126200,&DAT_0011b680,4,
                              PTR_FUN_001271f0,1,puVar24);
        if ((*(int *)(&DAT_0011b680 + lVar26 * 4) != 1) &&
           ((*(int *)(&DAT_0011b680 + lVar26 * 4) != 2 || (cVar4 = FUN_00106e50(), cVar4 == '\0'))))
        break;
      }
      DAT_00128334 = 3;
      break;
    case 0x47:
      DAT_00127028 = 0;
      break;
    case 0x48:
      DAT_00128318 = 2;
      break;
    case 0x49:
      FUN_00106ce0(optarg);
      break;
    case 0x4c:
      DAT_00128318 = 4;
      break;
    case 0x4e:
      local_8c = 0;
      break;
    case 0x51:
      local_8c = 5;
      break;
    case 0x52:
      DAT_00128316 = 1;
      break;
    case 0x53:
      local_90 = 3;
      break;
    case 0x54:
      in_R9 = (undefined *)dcgettext(0,"invalid tab size",5);
      local_78 = (undefined *)FUN_0011a200(optarg,0,0,0x7fffffffffffffff,&DAT_0011cf4c,in_R9,2,0);
      break;
    case 0x55:
      local_90 = 6;
      break;
    case 0x58:
      local_90 = 1;
      break;
    case 0x5a:
      DAT_00128389 = 1;
      break;
    case 0x61:
      DAT_00128310 = 2;
      break;
    case 0x62:
      local_8c = 7;
      break;
    case 99:
      DAT_00128358 = 1;
      DAT_00128354 = '\x01';
      break;
    case 100:
      DAT_00128315 = '\x01';
      break;
    case 0x66:
      DAT_00128310 = 2;
      local_90 = 6;
      break;
    case 0x67:
      DAT_00127029 = 0;
    case 0x6c:
      uVar10 = 0;
      break;
    case 0x68:
      DAT_00128348 = 0xb0;
      DAT_0012833c = 0xb0;
      DAT_00128340 = 1;
      DAT_00127020 = 1;
      break;
    case 0x69:
      DAT_0012831c = 1;
      break;
    case 0x6b:
      bVar28 = true;
      break;
    case 0x6d:
      uVar10 = 4;
      break;
    case 0x6e:
      DAT_0012834d = 1;
      uVar10 = 0;
      break;
    case 0x6f:
      DAT_00127028 = 0;
      uVar10 = 0;
      break;
    case 0x70:
      DAT_00128334 = 1;
      break;
    case 0x71:
      local_70 = 1;
      break;
    case 0x72:
      DAT_0012834f = 1;
      break;
    case 0x73:
      DAT_0012834c = 1;
      break;
    case 0x74:
      local_90 = 5;
      break;
    case 0x75:
      DAT_00128358 = 2;
      DAT_00128354 = '\x01';
      break;
    case 0x76:
      goto switchD_00104d37_caseD_76;
    case 0x77:
      local_80 = FUN_00106de0(optarg);
      if (local_80 == 0xffffffffffffffff) {
        param_2 = (FILE *)FUN_00118c20(optarg);
        uVar14 = dcgettext(0,"invalid line width",5);
        error(2,0,"%s: %s",uVar14,param_2);
switchD_00104d37_caseD_76:
        local_90 = 4;
      }
      break;
    case 0x78:
      uVar10 = 3;
      break;
    case 0x80:
      DAT_0012834e = 1;
      break;
    case 0x81:
      iVar8 = FUN_00113490(optarg,&DAT_00128348,&DAT_00128340);
      if (iVar8 != 0) {
                    // WARNING: Subroutine does not return
        FUN_0011a470(iVar8,(ulong)local_58 & 0xffffffff,0,&PTR_s_all_00126340,optarg);
      }
      DAT_0012833c = DAT_00128348;
      DAT_00127020 = DAT_00128340;
      break;
    case 0x82:
      if (optarg == (char *)0x0) {
LAB_0010591d:
        bVar7 = 1;
      }
      else {
        in_R9 = PTR_FUN_001271f0;
        lVar26 = FUN_0010f1d0("--color",optarg,&PTR_s_always_00126200,&DAT_0011b680,4,
                              PTR_FUN_001271f0,1);
        if (*(int *)(&DAT_0011b680 + lVar26 * 4) == 1) goto LAB_0010591d;
        bVar7 = 0;
        if (*(int *)(&DAT_0011b680 + lVar26 * 4) == 2) {
          bVar7 = FUN_00106e50();
        }
      }
      DAT_00128332 = bVar7 & 1;
      break;
    case 0x83:
      DAT_00128318 = 3;
      break;
    case 0x84:
      DAT_00128334 = 2;
      break;
    case 0x85:
      in_R9 = puVar23;
      lVar26 = FUN_0010f1d0("--format",optarg,&PTR_s_verbose_00126300,&DAT_0011b710,4,
                            PTR_FUN_001271f0,1,puVar23);
      uVar10 = *(uint *)(&DAT_0011b710 + lVar26 * 4);
      break;
    case 0x86:
      uVar10 = 0;
      local_88 = "full-iso";
      break;
    case 0x87:
      DAT_00128314 = 1;
      break;
    case 0x88:
      puVar12 = (undefined8 *)FUN_00119d00(0x10);
      puVar24 = DAT_00128300;
      DAT_00128300 = puVar12;
      *puVar12 = optarg;
      puVar12[1] = puVar24;
      break;
    case 0x89:
      if (optarg == (char *)0x0) {
LAB_00105934:
        bVar7 = 1;
      }
      else {
        in_R9 = (undefined *)0x1;
        in_R10 = puVar24;
        lVar26 = FUN_0010f1d0("--hyperlink",optarg,&PTR_s_always_00126200,&DAT_0011b680,4,
                              PTR_FUN_001271f0,1,puVar24);
        if (*(int *)(&DAT_0011b680 + lVar26 * 4) == 1) goto LAB_00105934;
        bVar7 = 0;
        if (*(int *)(&DAT_0011b680 + lVar26 * 4) == 2) {
          bVar7 = FUN_00106e50();
        }
      }
      DAT_00128331 = bVar7 & 1;
      break;
    case 0x8a:
      in_R9 = PTR_FUN_001271f0;
      lVar26 = FUN_0010f1d0("--indicator-style",optarg,&PTR_DAT_001268e0,"",4,PTR_FUN_001271f0,1,
                            ppuVar20);
      DAT_00128334 = *(uint *)("lcrcecrsnofidilnpisobdcdmiorexdosusgstowtwcamhcl" +
                              lVar26 * 4 + 0x30);
      break;
    case 0x8b:
      in_R9 = PTR_FUN_001271f0;
      lVar26 = FUN_0010f1d0("--quoting-style",optarg,&PTR_s_literal_001269a0,&DAT_00120220,4,
                            PTR_FUN_001271f0,1,in_R11);
      local_8c = *(int *)(&DAT_00120220 + lVar26 * 4);
      break;
    case 0x8c:
      goto switchD_00104d37_caseD_8c;
    case 0x8d:
      DAT_00128348 = 0x90;
      DAT_0012833c = 0x90;
      DAT_00128340 = 1;
      DAT_00127020 = 1;
      break;
    case 0x8e:
      in_R9 = PTR_FUN_001271f0;
      lVar26 = FUN_0010f1d0("--sort",optarg,&DAT_001262c0,&DAT_0011b6f0,4,PTR_FUN_001271f0,1,
                            (long)&switchD_00104d37::switchdataD_0011b174 +
                            (long)(int)(&switchD_00104d37::switchdataD_0011b174)[iVar8 + 0x83U]);
      local_90 = *(int *)(&DAT_0011b6f0 + lVar26 * 4);
      break;
    case 0x8f:
      in_R11 = 1;
      in_R9 = PTR_FUN_001271f0;
      lVar26 = FUN_0010f1d0("--time",optarg,&DAT_00126260,&DAT_0011b6c0,4,PTR_FUN_001271f0,1,in_R10)
      ;
      DAT_00128354 = '\x01';
      DAT_00128358 = *(undefined4 *)(&DAT_0011b6c0 + lVar26 * 4);
      break;
    case 0x90:
      goto switchD_00104d37_caseD_90;
    case 0x91:
      DAT_00127019 = '\0';
      in_R10 = (undefined8 *)0x0;
      DAT_00128332 = 0;
      uVar10 = (uint)(uVar10 != 0);
      local_8c = 0;
switchD_00104d37_caseD_8c:
      local_70 = 0;
      break;
    case -0x83:
      uVar14 = FUN_00116520("David MacKenzie","David MacKenzie");
      uVar15 = FUN_00116520("Richard M. Stallman","Richard M. Stallman");
      pcVar25 = "ls";
      if ((DAT_001271e0 != 1) && (pcVar25 = "vdir", DAT_001271e0 == 2)) {
        pcVar25 = "dir";
      }
      FUN_00119b30(stdout,pcVar25,"GNU coreutils",PTR_DAT_001271e8,uVar15,uVar14,0,in_R9);
                    // WARNING: Subroutine does not return
      exit(0);
    case -0x82:
      goto switchD_00104d37_caseD_ffffff7e;
    default:
      goto switchD_00104d37_caseD_ffffff7f;
    }
    goto LAB_00104d00;
  }
  if (DAT_00128340 == 0) {
    pcVar25 = getenv("LS_BLOCK_SIZE");
    FUN_00113490(pcVar25,&DAT_00128348,&DAT_00128340);
    if ((pcVar25 != (char *)0x0) || (pcVar25 = getenv("BLOCK_SIZE"), pcVar25 != (char *)0x0)) {
      DAT_0012833c = DAT_00128348;
      DAT_00127020 = DAT_00128340;
    }
    if (bVar28) {
      DAT_00128340 = 0x400;
      DAT_00128348 = 0;
    }
  }
  if ((int)uVar10 < 0) {
    if (DAT_001271e0 == 1) goto LAB_001064c7;
    uVar10 = (uint)(DAT_001271e0 == 2) * 2;
  }
  do {
    uVar16 = local_80;
    DAT_0012835c = uVar10;
    uVar3 = local_80;
    if ((uVar10 - 2 < 3) || (DAT_00128332 != 0)) {
      if (local_80 == 0xffffffffffffffff) {
        cVar4 = FUN_00106e50();
        if ((cVar4 != '\0') && (iVar8 = ioctl(1,0x5413,&local_58), -1 < iVar8)) {
          uVar16 = (ulong)local_58._2_2_;
          uVar3 = uVar16;
          if (local_58._2_2_ != 0) goto LAB_00104db0;
        }
        pcVar25 = getenv("COLUMNS");
        if ((pcVar25 != (char *)0x0) && (*pcVar25 != '\0')) {
          local_80 = FUN_00106de0(pcVar25);
          uVar16 = local_80;
          uVar3 = local_80;
          if (local_80 != 0xffffffffffffffff) goto LAB_00104db0;
          uVar14 = FUN_00118c20(pcVar25);
          uVar15 = dcgettext(0,"ignoring invalid width in environment variable COLUMNS: %s",5);
          error(0,0,uVar15,uVar14);
        }
LAB_0010521e:
        uVar16 = 0x50;
        uVar3 = local_80;
      }
    }
    else if (local_80 == 0xffffffffffffffff) goto LAB_0010521e;
LAB_00104db0:
    local_80 = uVar3;
    DAT_00128220 = (uVar16 / 3 + 1) - (ulong)(uVar16 % 3 == 0);
    DAT_001282d0 = uVar16;
    puVar23 = DAT_001282e0;
    if ((DAT_0012835c - 2 < 3) && (puVar23 = local_78, (long)local_78 < 0)) {
      DAT_001282e0 = (undefined *)0x8;
      pcVar25 = getenv("TABSIZE");
      puVar23 = DAT_001282e0;
      if ((pcVar25 != (char *)0x0) &&
         (iVar8 = FUN_0011a540(pcVar25,0,0,&local_58,&DAT_0011cf4c), puVar23 = local_58, iVar8 != 0)
         ) {
        uVar14 = FUN_00118c20(pcVar25);
        uVar15 = dcgettext(0,"ignoring invalid tab size in environment variable TABSIZE: %s",5);
        error(0,0,uVar15,uVar14);
        puVar23 = DAT_001282e0;
      }
    }
    DAT_001282e0 = puVar23;
    bVar7 = (byte)local_70 & 1;
    if ((local_70 == -1) && (bVar7 = 0, DAT_001271e0 == 1)) {
      bVar7 = FUN_00106e50();
    }
    DAT_001282f8 = bVar7;
    if (local_8c < 0) {
      pcVar25 = getenv("QUOTING_STYLE");
      if (pcVar25 == (char *)0x0) goto LAB_00105a42;
      iVar8 = FUN_0010ee80(pcVar25,&PTR_s_literal_001269a0,&DAT_00120220,4);
      if (iVar8 < 0) goto LAB_0010670b;
      local_8c = *(int *)(&DAT_00120220 + (long)iVar8 * 4);
      if (local_8c < 0) goto LAB_00105a42;
    }
LAB_00104e16:
    FUN_00118160(0,local_8c);
    while( true ) {
      uVar10 = FUN_00118140(0);
      if (((DAT_0012835c == 0) || ((DAT_0012835c - 2 < 2 && (DAT_001282d0 != 0)))) && (uVar10 < 7))
      {
        if ((0x4aUL >> ((ulong)uVar10 & 0x3f) & 1) == 0) {
          DAT_001283c8 = 0;
          DAT_001282f0 = FUN_00118100(0);
        }
        else {
          DAT_001283c8 = 1;
          DAT_001282f0 = FUN_00118100(0);
        }
      }
      else {
        DAT_001283c8 = 0;
        DAT_001282f0 = FUN_00118100(0);
        if (uVar10 == 7) {
          FUN_00118180(DAT_001282f0,0x20,1);
        }
      }
      if (1 < DAT_00128334) {
        pcVar25 = &DAT_0011d1ab + (DAT_00128334 - 2);
        cVar4 = (&DAT_0011d1ab)[DAT_00128334 - 2];
        while (cVar4 != '\0') {
          pcVar25 = pcVar25 + 1;
          FUN_00118180(DAT_001282f0,(int)cVar4,1);
          cVar4 = *pcVar25;
        }
      }
      DAT_001282e8 = FUN_00118100(0);
      FUN_00118180(DAT_001282e8,0x3a,1);
      DAT_00128338 = (DAT_00128331 ^ 1) & DAT_0012835c == 0 & DAT_00128338;
      if ((int)(uint)DAT_00128338 <= (int)DAT_00127019) break;
LAB_001066e7:
      uVar14 = dcgettext(0,"--dired and --zero are incompatible",5);
      error(2,0,uVar14);
LAB_0010670b:
      uVar14 = FUN_00118c20();
      uVar15 = dcgettext(0,"ignoring invalid value of environment variable QUOTING_STYLE: %s",5);
      error(0,0,uVar15,uVar14);
LAB_00105a42:
      local_8c = 7;
      if (DAT_001271e0 != 1) goto LAB_00104e16;
      cVar4 = FUN_00106e50();
      if (cVar4 != '\0') goto code_r0x00105a64;
    }
    if (local_90 < 0) {
      if (DAT_0012835c == 0) {
        DAT_00128350 = 0;
        goto LAB_00104f1f;
      }
      if (DAT_00128354 == '\0') {
        DAT_00128350 = 0;
      }
      else {
        DAT_00128350 = 5;
      }
      goto LAB_00104f6a;
    }
    DAT_00128350 = local_90;
    if (DAT_0012835c != 0) goto LAB_00104f6a;
LAB_00104f1f:
    if ((local_88 == (char *)0x0) && (local_88 = getenv("TIME_STYLE"), local_88 == (char *)0x0)) {
      local_88 = "locale";
    }
    else {
      while (iVar8 = strncmp(local_88,"posix-",6), iVar8 == 0) {
        cVar4 = FUN_00111400(2);
        if (cVar4 == '\0') goto LAB_00104f6a;
        local_88 = local_88 + 6;
      }
    }
    if (*local_88 == '+') {
      pcVar25 = local_88 + 1;
      pcVar19 = strchr(pcVar25,10);
      pcVar22 = pcVar25;
      if (pcVar19 != (char *)0x0) {
        pcVar22 = strchr(pcVar19 + 1,10);
        if (pcVar22 != (char *)0x0) {
          param_2 = (FILE *)FUN_00118c20(pcVar25);
          uVar14 = dcgettext(0,"invalid time style format %s",5);
          error(2,0,uVar14,param_2);
          goto LAB_001066e7;
        }
        *pcVar19 = '\0';
        pcVar22 = pcVar19 + 1;
      }
      goto LAB_00106154;
    }
    ppuVar20 = &PTR_s_full_iso_00126920;
    lVar26 = FUN_0010ee80(local_88,&PTR_s_full_iso_00126920,&DAT_0011b7c0,4);
    if (-1 < lVar26) goto code_r0x00106124;
    param_1 = 0x11d1fa;
    FUN_0010f000("time style",local_88,lVar26);
    __stream = stderr;
    pcVar25 = (char *)dcgettext(0,"Valid arguments are:\n",5);
    fputs_unlocked(pcVar25,__stream);
    for (; param_2 = stderr, *ppuVar20 != (undefined *)0x0; ppuVar20 = ppuVar20 + 1) {
      __fprintf_chk(stderr,1,"  - [posix-]%s\n");
    }
    pcVar25 = (char *)dcgettext(0,"  - +FORMAT (e.g., +%H:%M) for a \'date\'-style format\n",5);
    fputs_unlocked(pcVar25,param_2);
switchD_00104d37_caseD_ffffff7f:
    FUN_0010e360();
switchD_00104d37_caseD_ffffff7e:
    FUN_0010e360(0);
LAB_001064c7:
    bVar7 = FUN_00106e50();
    uVar10 = bVar7 + 1;
  } while( true );
switchD_00104d37_caseD_90:
  local_88 = optarg;
  goto LAB_00104d00;
code_r0x00106124:
  if (lVar26 == 2) {
    PTR_DAT_00127040 = s__Y__m__d_0011d231;
    PTR_s__b__e__H__M_00127048 = &DAT_0011d225;
    pcVar25 = PTR_DAT_00127040;
    pcVar22 = PTR_s__b__e__H__M_00127048;
  }
  else if (lVar26 < 3) {
    if (lVar26 == 0) {
      PTR_DAT_00127040 = s__Y__m__d__H__M__S__N__z_0011d20a;
      PTR_s__b__e__H__M_00127048 = s__Y__m__d__H__M__S__N__z_0011d20a;
      pcVar25 = PTR_DAT_00127040;
      pcVar22 = PTR_s__b__e__H__M_00127048;
    }
    else {
      PTR_DAT_00127040 = &DAT_0011d222;
      PTR_s__b__e__H__M_00127048 = &DAT_0011d222;
      pcVar25 = PTR_DAT_00127040;
      pcVar22 = PTR_s__b__e__H__M_00127048;
    }
  }
  else {
    pcVar25 = PTR_DAT_00127040;
    pcVar22 = PTR_s__b__e__H__M_00127048;
    if ((lVar26 == 3) &&
       (cVar4 = FUN_00111400(2), pcVar25 = PTR_DAT_00127040, pcVar22 = PTR_s__b__e__H__M_00127048,
       cVar4 != '\0')) {
      PTR_DAT_00127040 = (undefined *)dcgettext(0,PTR_DAT_00127040,2);
      pcVar22 = (char *)dcgettext(0,PTR_s__b__e__H__M_00127048,2);
      pcVar25 = PTR_DAT_00127040;
    }
  }
LAB_00106154:
  PTR_s__b__e__H__M_00127048 = pcVar22;
  PTR_DAT_00127040 = pcVar25;
  FUN_00106e80();
LAB_00104f6a:
  bVar7 = DAT_00128332;
  iVar8 = optind;
  if (DAT_00128332 == 0) goto LAB_00104f82;
  local_60 = getenv("LS_COLORS");
  if ((local_60 != (char *)0x0) && (*local_60 != '\0')) {
    DAT_00128320 = (undefined *)FUN_0011a180(local_60);
    local_58 = DAT_00128320;
    goto LAB_00105d12;
  }
  pcVar25 = getenv("COLORTERM");
  if ((pcVar25 != (char *)0x0) && (*pcVar25 != '\0')) goto LAB_00106215;
  pcVar25 = getenv("TERM");
  if ((pcVar25 == (char *)0x0) || (*pcVar25 == '\0')) goto LAB_0010656a;
  pcVar22 = "# Configuration file for dircolors, a utility to help you set the";
  goto LAB_001062c5;
LAB_00105d12:
  pcVar25 = local_60;
  cVar4 = *local_60;
  if (cVar4 == '*') {
    psVar18 = (size_t *)FUN_00119d00(0x30);
    *(undefined1 *)(psVar18 + 4) = 0;
    local_60 = pcVar25 + 1;
    psVar18[5] = (size_t)DAT_00128328;
    psVar18[1] = (size_t)local_58;
    DAT_00128328 = psVar18;
    cVar4 = FUN_00106920(&local_58,&local_60,1,psVar18);
    pcVar25 = local_60;
    if ((cVar4 == '\0') || (pcVar25 = local_60 + 1, *local_60 != '=')) goto LAB_00105eeb;
    psVar18[3] = (size_t)local_58;
    local_60 = local_60 + 1;
    cVar4 = FUN_00106920(&local_58,&local_60,0,psVar18 + 2);
    pcVar25 = local_60;
    if (cVar4 == '\0') goto LAB_00105eeb;
    goto LAB_00105d12;
  }
  if (cVar4 == ':') {
    local_60 = local_60 + 1;
  }
  else {
    if (cVar4 == '\0') {
      psVar18 = DAT_00128328;
      if (DAT_00128328 != (size_t *)0x0) {
        while (psVar21 = psVar18, psVar18 = (size_t *)psVar21[5], psVar18 != (size_t *)0x0) {
          bVar2 = 0;
          psVar27 = psVar18;
          do {
            sVar17 = *psVar27;
            if ((sVar17 != 0xffffffffffffffff) && (sVar17 == *psVar21)) {
              pvVar13 = (void *)psVar27[1];
              __s1 = (void *)psVar21[1];
              iVar9 = memcmp(__s1,pvVar13,sVar17);
              if (iVar9 == 0) {
                *psVar27 = 0xffffffffffffffff;
              }
              else {
                iVar9 = FUN_0010f3c0(__s1,pvVar13,sVar17);
                if (iVar9 == 0) {
                  if ((bVar2 == 0) &&
                     ((psVar21[2] != psVar27[2] ||
                      (iVar9 = memcmp((void *)psVar21[3],(void *)psVar27[3],psVar21[2]), iVar9 != 0)
                      ))) {
                    *(undefined1 *)(psVar21 + 4) = 1;
                    *(undefined1 *)(psVar27 + 4) = 1;
                  }
                  else {
                    *psVar27 = 0xffffffffffffffff;
                    bVar2 = bVar7;
                  }
                }
              }
            }
            psVar27 = (size_t *)psVar27[5];
          } while (psVar27 != (size_t *)0x0);
        }
      }
      goto LAB_001063ca;
    }
    cVar1 = local_60[1];
    pcVar25 = local_60 + 1;
    if ((cVar1 == '\0') || (pcVar25 = local_60 + 3, local_60[2] != '=')) goto LAB_00105eeb;
    lVar26 = 0;
    while ((local_60 = pcVar25,
           cVar4 != "lcrcecrsnofidilnpisobdcdmiorexdosusgstowtwcamhcl"[lVar26 * 2] ||
           (cVar1 != "lcrcecrsnofidilnpisobdcdmiorexdosusgstowtwcamhcl"[lVar26 * 2 + 1]))) {
      lVar26 = lVar26 + 1;
      if (lVar26 == 0x18) goto LAB_00105eab;
    }
    (&PTR_DAT_00127068)[(long)(int)lVar26 * 2] = local_58;
    cVar6 = FUN_00106920(&local_58,&local_60,0);
    if (cVar6 == '\0') goto LAB_00105eab;
  }
  goto LAB_00105d12;
LAB_001062c5:
  if ((char *)0x15ef < pcVar22 + -0x11b900) goto LAB_0010656a;
  iVar9 = strncmp(pcVar22,"TERM ",5);
  if ((iVar9 == 0) && (iVar9 = fnmatch(pcVar22 + 5,pcVar25,0), iVar9 == 0)) goto LAB_00106215;
  sVar17 = strlen(pcVar22);
  pcVar22 = pcVar22 + sVar17 + 1;
  goto LAB_001062c5;
LAB_0010656a:
  DAT_00128332 = 0;
  goto LAB_00106215;
code_r0x00105a64:
  local_8c = 3;
  goto LAB_00104e16;
LAB_00105eab:
  local_42 = 0;
  local_44 = cVar4;
  local_43 = cVar1;
  uVar14 = FUN_00118c20(&local_44);
  uVar15 = dcgettext(0,"unrecognized prefix: %s",5);
  error(0,0,uVar15,uVar14);
  pcVar25 = local_60;
LAB_00105eeb:
  local_60 = pcVar25;
  uVar14 = dcgettext(0,"unparsable value for LS_COLORS environment variable",5);
  error(0,0,uVar14);
  free(DAT_00128320);
  psVar18 = DAT_00128328;
  while (psVar18 != (size_t *)0x0) {
    psVar21 = (size_t *)psVar18[5];
    free(psVar18);
    psVar18 = psVar21;
  }
  DAT_00128332 = 0;
LAB_001063ca:
  if ((DAT_001270d0 == 6) && (iVar9 = strncmp(PTR_DAT_001270d8,"target",6), iVar9 == 0)) {
    DAT_001283b0 = '\x01';
  }
LAB_00106215:
  if (DAT_00128332 == 0) {
LAB_00104f82:
    if (DAT_00128314 != 0) goto LAB_00104f8b;
  }
  else {
    DAT_001282e0 = (undefined *)0x0;
    if ((((DAT_00128314 != 0) || (cVar4 = FUN_001068c0(0xd), cVar4 != '\0')) ||
        ((cVar4 = FUN_001068c0(0xe), cVar4 != '\0' && (DAT_001283b0 != '\0')))) ||
       ((cVar4 = FUN_001068c0(0xc), cVar4 != '\0' && (DAT_0012835c == 0)))) {
LAB_00104f8b:
      DAT_0012831d = 1;
    }
  }
  lVar26 = (long)iVar8;
  if ((((DAT_00128318 == 0) && (DAT_00128318 = 1, DAT_00128315 == '\0')) && (DAT_00128334 != 3)) &&
     (DAT_0012835c != 0)) {
    DAT_00128318 = 3;
  }
  if (DAT_00128316 != 0) {
    DAT_001283e8 = FUN_00111e30(0x1e,0,FUN_00106880,FUN_00106890,free);
    if (DAT_001283e8 == 0) {
                    // WARNING: Subroutine does not return
      FUN_0011a1c0();
    }
    FUN_001161c0(&DAT_00128100,0,0,malloc,free);
  }
  pcVar25 = getenv("TZ");
  DAT_001282c8 = FUN_00119090(pcVar25);
  DAT_001282c2 = DAT_0012834c | DAT_00128331 | DAT_00128389 | DAT_0012835c == 0 |
                 (DAT_00128350 - 3U & 0xfffffffd) == 0;
  DAT_001282c1 = (DAT_00128389 | DAT_00128316 | DAT_00128332 | DAT_00128314 | DAT_00128334 != 0) &
                 (DAT_001282c2 ^ 1);
  uVar5 = 0;
  if (DAT_00128332 != 0) {
    uVar5 = FUN_001068c0(0x15);
  }
  DAT_001282c0 = uVar5;
  if (DAT_00128338 != 0) {
    FUN_001161c0(&DAT_001281c0,0,0,malloc,free);
    FUN_001161c0(&DAT_00128160,0,0,malloc,free);
  }
  if (DAT_00128331 != 0) {
    uVar16 = 0;
    do {
      while (iVar9 = (int)uVar16, uVar16 < 0x5b) {
        if (((uVar16 < 0x41) && (9 < iVar9 - 0x30U)) && (1 < iVar9 - 0x2dU)) {
          uVar16 = uVar16 + 1;
        }
        else {
          (&DAT_00128000)[uVar16] = (&DAT_00128000)[uVar16] | 1;
          uVar16 = uVar16 + 1;
        }
      }
      bVar28 = true;
      if ((0x19 < iVar9 - 0x61U) && (uVar16 != 0x7e)) {
        bVar28 = iVar9 == 0x5f;
      }
      (&DAT_00128000)[uVar16] = (&DAT_00128000)[uVar16] | bVar28;
      uVar16 = uVar16 + 1;
    } while (uVar16 != 0x100);
    DAT_001283a8 = (undefined *)FUN_0011a360();
    if (DAT_001283a8 == (undefined *)0x0) {
      DAT_001283a8 = &DAT_0011cf4c;
    }
  }
  DAT_001283d8 = 100;
  DAT_001283e0 = FUN_00119d00(0x5140);
  iVar8 = param_1 - iVar8;
  DAT_001283d0 = 0;
  FUN_001087c0();
  if (iVar8 < 1) {
    if (DAT_00128315 == '\0') {
      FUN_001071c0(&DAT_0011d277,0,1);
    }
    else {
      FUN_0010ca80(&DAT_0011d277,3,1,0);
    }
    if (DAT_001283d0 != 0) goto LAB_00105fba;
LAB_00105a9f:
    if (DAT_001283a0 == (long *)0x0) goto LAB_00105194;
    __ptr = DAT_001283a0;
    if (DAT_001283a0[3] == 0) {
      DAT_001282d8 = 0;
    }
  }
  else {
    do {
      lVar11 = lVar26 * 2;
      lVar26 = lVar26 + 1;
      FUN_0010ca80(*(undefined8 *)(&param_2->_flags + lVar11),0,1,0);
    } while ((int)lVar26 < (int)param_1);
    if (DAT_001283d0 == 0) {
LAB_00105129:
      if (1 < iVar8) goto LAB_00105188;
      goto LAB_00105a9f;
    }
LAB_00105fba:
    FUN_00108e30();
    if (DAT_00128315 == '\0') {
      FUN_00109530(0,1);
    }
    if (DAT_001283d0 == 0) goto LAB_00105129;
    FUN_0010c650();
    if (DAT_001283a0 == (long *)0x0) goto LAB_00105194;
    DAT_00128218 = DAT_00128218 + 1;
    pcVar25 = stdout->_IO_write_ptr;
    if (stdout->_IO_write_end <= pcVar25) {
      __overflow(stdout,10);
      goto LAB_00105188;
    }
    stdout->_IO_write_ptr = pcVar25 + 1;
    *pcVar25 = '\n';
    __ptr = DAT_001283a0;
  }
  do {
    DAT_001283a0 = (long *)__ptr[3];
    if ((DAT_001283e8 == 0) || (*__ptr != 0)) {
      FUN_0010dc80(*__ptr,__ptr[1],(char)__ptr[2]);
      free((void *)*__ptr);
      free((void *)__ptr[1]);
      free(__ptr);
      DAT_001282d8 = 1;
    }
    else {
      if ((ulong)(DAT_00128118 - _DAT_00128110) < 0x10) {
                    // WARNING: Subroutine does not return
        __assert_fail("dev_ino_size <= __extension__ ({ struct obstack const *__o = (&dev_ino_obstack); (size_t) (__o->next_free - __o->object_base); })"
                      ,"src/ls.c",0x442,"dev_ino_pop");
      }
      local_58 = *(undefined **)(DAT_00128118 + -0x10);
      uStack_50 = *(undefined8 *)(DAT_00128118 + -8);
      DAT_00128118 = DAT_00128118 + -0x10;
      pvVar13 = (void *)FUN_00112530(DAT_001283e8,&local_58);
      if (pvVar13 == (void *)0x0) {
                    // WARNING: Subroutine does not return
        __assert_fail("found","src/ls.c",0x73d,"main");
      }
      free(pvVar13);
      free((void *)*__ptr);
      free((void *)__ptr[1]);
      free(__ptr);
    }
LAB_00105188:
    __ptr = DAT_001283a0;
  } while (DAT_001283a0 != (long *)0x0);
LAB_00105194:
  if ((DAT_00128332 != 0) && (DAT_00128330 != '\0')) {
    if ((DAT_00127060 != 2) ||
       (((*(short *)PTR_DAT_00127068 != 0x5b1b || (DAT_00127070 != 1)) || (*PTR_DAT_00127078 != 'm')
        ))) {
      FUN_00107990(&DAT_00127060);
      FUN_00107990(&DAT_00127070);
    }
    fflush_unlocked(stdout);
    FUN_001077e0(0);
    for (iVar8 = DAT_00128234; iVar8 != 0; iVar8 = iVar8 + -1) {
      raise(0x13);
    }
    if (DAT_00128238 != 0) {
      raise(DAT_00128238);
    }
  }
  if (DAT_00128338 != 0) {
    FUN_00107670("//DIRED//",&DAT_001281c0);
    FUN_00107670("//SUBDIRED//",&DAT_00128160);
    uVar10 = FUN_00118140(DAT_001282f0);
    __printf_chk(1,"//DIRED-OPTIONS// --quoting-style=%s\n",(&PTR_s_literal_001269a0)[uVar10]);
  }
  lVar26 = DAT_001283e8;
  if (DAT_001283e8 != 0) {
    lVar11 = FUN_00111900(DAT_001283e8);
    if (lVar11 != 0) {
                    // WARNING: Subroutine does not return
      __assert_fail("hash_get_n_entries (active_dir_set) == 0","src/ls.c",0x771,"main");
    }
    FUN_00111ff0(lVar26);
  }
  if (local_40 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return DAT_00128230;
}



void processEntry entry(undefined8 param_1,undefined8 param_2)

{
  undefined1 auStack_8 [8];
  
  __libc_start_main(FUN_00104c00,param_2,&stack0x00000008,0,0,param_1,auStack_8);
  do {
                    // WARNING: Do nothing block with infinite loop
  } while( true );
}



// WARNING: Removing unreachable block (ram,0x001067a3)
// WARNING: Removing unreachable block (ram,0x001067af)

void FUN_00106790(void)

{
  return;
}



// WARNING: Removing unreachable block (ram,0x001067e4)
// WARNING: Removing unreachable block (ram,0x001067f0)

void FUN_001067c0(void)

{
  return;
}



void _FINI_0(void)

{
  if (DAT_001272c8 != '\0') {
    return;
  }
  __cxa_finalize(PTR_LOOP_00127008);
  FUN_00106790();
  DAT_001272c8 = 1;
  return;
}



void _INIT_0(void)

{
  FUN_001067c0();
  return;
}



ulong FUN_00106880(ulong *param_1,ulong param_2)

{
  return *param_1 % param_2;
}



undefined8 FUN_00106890(ulong *param_1,ulong *param_2)

{
  ulong uVar1;
  
  uVar1 = *param_1 ^ *param_2 | param_1[1] ^ param_2[1];
  return CONCAT71((int7)(uVar1 >> 8),uVar1 == 0);
}



uint FUN_001068c0(uint param_1)

{
  ulong uVar1;
  char *pcVar2;
  uint uVar3;
  
  uVar3 = 0;
  uVar1 = (&DAT_00127060)[(ulong)param_1 * 2];
  if (uVar1 != 0) {
    if (uVar1 < 3) {
      pcVar2 = (&PTR_DAT_00127068)[(ulong)param_1 * 2];
      return (uint)(pcVar2[uVar1 - 1] != '0') |
             (uint)CONCAT71((int7)((ulong)pcVar2 >> 8),*pcVar2 != '0');
    }
    uVar3 = 1;
  }
  return uVar3;
}



void FUN_00106900(int param_1)

{
  if (DAT_00128238 == 0) {
    DAT_00128238 = param_1;
  }
  return;
}



undefined4 FUN_00106920(undefined8 *param_1,long *param_2,undefined4 param_3,long *param_4)

{
  byte *pbVar1;
  byte bVar2;
  long lVar3;
  byte bVar4;
  byte *pbVar5;
  byte *pbVar6;
  
  lVar3 = 0;
  bVar2 = *(byte *)*param_2;
  pbVar5 = (byte *)*param_2;
  pbVar6 = (byte *)*param_1;
LAB_00106960:
  while (bVar2 != 0x5c) {
    if ((char)bVar2 < ']') {
      pbVar1 = pbVar5;
      if (bVar2 == 0x3d) {
        if ((char)param_3 != '\0') goto LAB_00106985;
      }
      else if (((char)bVar2 < '>') && ((bVar2 == 0 || (bVar2 == 0x3a)))) {
        param_3 = 1;
        goto LAB_00106985;
      }
LAB_001069f5:
      *pbVar6 = bVar2;
      lVar3 = lVar3 + 1;
      bVar2 = pbVar5[1];
      pbVar5 = pbVar5 + 1;
      pbVar6 = pbVar6 + 1;
    }
    else {
      if (bVar2 != 0x5e) goto LAB_001069f5;
      bVar2 = pbVar5[1];
      if ((byte)(bVar2 - 0x40) < 0x3f) {
        lVar3 = lVar3 + 1;
        *pbVar6 = bVar2 & 0x1f;
        bVar2 = pbVar5[2];
        pbVar5 = pbVar5 + 2;
        pbVar6 = pbVar6 + 1;
      }
      else {
        pbVar1 = pbVar5 + 1;
        if (bVar2 != 0x3f) {
          param_3 = 0;
LAB_00106985:
          *param_1 = pbVar6;
          *param_2 = (long)pbVar1;
          *param_4 = lVar3;
          return param_3;
        }
        *pbVar6 = 0x7f;
        lVar3 = lVar3 + 1;
        bVar2 = pbVar5[1];
        pbVar5 = pbVar1;
        pbVar6 = pbVar6 + 1;
      }
    }
  }
  bVar2 = pbVar5[1];
  if (bVar2 == 0) {
    pbVar1 = pbVar5 + 2;
    param_3 = 0;
    goto LAB_00106985;
  }
  bVar4 = bVar2 - 0x30;
  switch(bVar4) {
  case 0:
  case 1:
  case 2:
  case 3:
  case 4:
  case 5:
  case 6:
  case 7:
    pbVar1 = pbVar5 + 2;
    pbVar5 = pbVar5 + 2;
    bVar2 = *pbVar1;
    while ((byte)(bVar2 - 0x30) < 8) {
      pbVar5 = pbVar5 + 1;
      bVar4 = (bVar2 - 0x30) + bVar4 * '\b';
      bVar2 = *pbVar5;
    }
    *pbVar6 = bVar4;
    lVar3 = lVar3 + 1;
    bVar2 = *pbVar5;
    pbVar6 = pbVar6 + 1;
    goto LAB_00106960;
  case 0xf:
    bVar2 = 0x7f;
    break;
  case 0x28:
  case 0x48:
    bVar4 = pbVar5[2];
    bVar2 = 0;
    pbVar5 = pbVar5 + 2;
    while( true ) {
      while ((char)bVar4 < 'G') {
        if ((char)bVar4 < 'A') {
          if (9 < (byte)(bVar4 - 0x30)) goto LAB_00106b60;
          bVar2 = (bVar4 - 0x30) + bVar2 * '\x10';
          bVar4 = pbVar5[1];
          pbVar5 = pbVar5 + 1;
        }
        else {
          pbVar5 = pbVar5 + 1;
          bVar2 = (bVar4 - 0x37) + bVar2 * '\x10';
          bVar4 = *pbVar5;
        }
      }
      if (5 < (byte)(bVar4 + 0x9f)) break;
      pbVar5 = pbVar5 + 1;
      bVar2 = bVar4 + 0xa9 + bVar2 * '\x10';
      bVar4 = *pbVar5;
    }
LAB_00106b60:
    *pbVar6 = bVar2;
    pbVar6 = pbVar6 + 1;
    bVar2 = *pbVar5;
    lVar3 = lVar3 + 1;
    goto LAB_00106960;
  case 0x2f:
    bVar2 = 0x20;
    break;
  case 0x31:
    bVar2 = 7;
    break;
  case 0x32:
    bVar2 = 8;
    break;
  case 0x35:
    bVar2 = 0x1b;
    break;
  case 0x36:
    bVar2 = 0xc;
    break;
  case 0x3e:
    bVar2 = 10;
    break;
  case 0x42:
    bVar2 = 0xd;
    break;
  case 0x44:
    bVar2 = 9;
    break;
  case 0x46:
    bVar2 = 0xb;
  }
  *pbVar6 = bVar2;
  pbVar6 = pbVar6 + 1;
  bVar2 = pbVar5[2];
  lVar3 = lVar3 + 1;
  pbVar5 = pbVar5 + 2;
  goto LAB_00106960;
}



byte FUN_00106bc0(char param_1,uint param_2,int param_3)

{
  byte bVar1;
  uint uVar2;
  
  if (param_1 == '\0') {
    if (param_3 != 5) {
      if ((param_3 == 3) || (param_3 == 9)) {
        return 0x2f;
      }
      if (DAT_00128334 == 1) {
        return 0;
      }
      if (param_3 != 6) {
        if (param_3 != 1) {
          bVar1 = 0x3d;
          if (param_3 != 7) {
            bVar1 = 0;
          }
          return bVar1;
        }
        return 0x7c;
      }
      return 0x40;
    }
  }
  else {
    uVar2 = param_2 & 0xf000;
    if (uVar2 == 0x8000) {
      if (DAT_00128334 == 3) {
        return -((param_2 & 0x49) != 0) & 0x2a;
      }
    }
    else {
      if (uVar2 == 0x4000) {
        return 0x2f;
      }
      if (DAT_00128334 != 1) {
        if (uVar2 == 0xa000) {
          return 0x40;
        }
        if (uVar2 != 0x1000) {
          bVar1 = 0x3d;
          if (uVar2 != 0xc000) {
            bVar1 = 0;
          }
          return bVar1;
        }
        return 0x7c;
      }
    }
  }
  return 0;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

void free(void *__ptr)

{
  free(__ptr);
  return;
}



void FUN_00106ce0(undefined8 param_1)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)FUN_00119d00(0x10);
  uVar1 = DAT_00128308;
  DAT_00128308 = puVar2;
  *puVar2 = param_1;
  puVar2[1] = uVar1;
  return;
}



uint FUN_00106d10(void)

{
  uint uVar1;
  
  if (DAT_0012831c == '\0') {
    uVar1 = (uint)DAT_0012834c << 10 | 2;
  }
  else {
    uVar1 = (uint)DAT_0012834c << 10 | 0x102;
  }
  if (DAT_0012835c == 0) {
    if ((DAT_00127029 == '\0') && (DAT_0012834e == '\0')) {
      uVar1 = uVar1 | *(uint *)(&DAT_0011b5d0 + (ulong)DAT_00128358 * 4) | 0x204;
    }
    else {
      uVar1 = uVar1 | *(uint *)(&DAT_0011b5d0 + (ulong)DAT_00128358 * 4) | 0x20c;
    }
    uVar1 = (uint)DAT_00127028 << 4 | uVar1;
  }
  switch(DAT_00128350) {
  case 0:
  case 1:
  case 2:
  case 4:
  case 6:
    return uVar1;
  case 3:
    return uVar1 | 0x200;
  case 5:
    return uVar1 | *(uint *)(&DAT_0011b5d0 + (ulong)DAT_00128358 * 4);
  default:
                    // WARNING: Subroutine does not return
    __assert_fail("sort_type != sort_version","src/ls.c",0x1017,"sort_files");
  }
}



long FUN_00106de0(undefined8 param_1)

{
  uint uVar1;
  long lVar2;
  long in_FS_OFFSET;
  long local_18;
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  uVar1 = FUN_0011a540(param_1,0,0,&local_18,&DAT_0011cf4c);
  lVar2 = 0;
  if (((uVar1 != 1) && (lVar2 = -1, uVar1 < 2)) && (lVar2 = local_18, local_18 < 0)) {
    lVar2 = 0;
  }
  if (local_10 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return lVar2;
}



uint FUN_00106e50(void)

{
  uint uVar1;
  
  if (-1 < (char)DAT_00127018) {
    return DAT_00127018 & 1;
  }
  uVar1 = isatty(1);
  DAT_00127018 = (char)uVar1;
  return uVar1 & 1;
}



void FUN_00106e80(void)

{
  char cVar1;
  undefined *puVar2;
  long lVar3;
  int iVar4;
  uint uVar5;
  char *pcVar6;
  size_t sVar7;
  char *pcVar8;
  char cVar9;
  int iVar10;
  long lVar11;
  int iVar12;
  long in_FS_OFFSET;
  bool bVar13;
  long local_6b8 [2];
  int local_6a8 [12];
  int local_678 [12];
  char local_648 [1536];
  char local_48 [8];
  long local_40;
  
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  lVar11 = 0;
  do {
    pcVar6 = *(char **)((long)&PTR_DAT_00127040 + lVar11);
    cVar9 = *pcVar6;
joined_r0x00106eb9:
    if (cVar9 != '\0') {
      do {
        cVar1 = pcVar6[1];
        bVar13 = cVar9 == '%';
        cVar9 = cVar1;
        if (bVar13) {
          if (cVar1 != '%') goto code_r0x00106edd;
          pcVar8 = pcVar6 + 2;
          pcVar6 = pcVar6 + 1;
          cVar9 = *pcVar8;
        }
        pcVar6 = pcVar6 + 1;
        if (cVar9 == '\0') break;
      } while( true );
    }
LAB_00106f00:
    pcVar6 = (char *)0x0;
LAB_00106f02:
    *(char **)((long)local_6b8 + lVar11) = pcVar6;
    if (lVar11 == 8) goto code_r0x00106f10;
    lVar11 = 8;
  } while( true );
code_r0x00106edd:
  if (cVar1 == 'b') goto LAB_00106f02;
  if (cVar1 == '\0') goto LAB_00106f00;
  cVar9 = pcVar6[2];
  pcVar6 = pcVar6 + 2;
  goto joined_r0x00106eb9;
code_r0x00106f10:
  if ((local_6b8[0] != 0) || (local_6b8[1] != 0)) {
    lVar11 = 0;
    iVar12 = 0;
    do {
      pcVar6 = nl_langinfo((int)lVar11 + 0x2000e);
      sVar7 = strnlen(pcVar6,0x80);
      local_678[lVar11] = (int)sVar7;
      if ((sVar7 == 0x80) || (pcVar8 = strchr(pcVar6,0x25), pcVar8 != (char *)0x0))
      goto LAB_00107140;
      pcVar6 = strcpy(local_648 + lVar11 * 0x80,pcVar6);
      iVar4 = FUN_00113da0(pcVar6,3);
      local_6a8[lVar11] = iVar4;
      if (iVar4 < 0) goto LAB_00107140;
      if (iVar12 < iVar4) {
        iVar12 = iVar4;
      }
      lVar11 = lVar11 + 1;
    } while (lVar11 != 0xc);
    lVar11 = 0;
    pcVar6 = local_648;
    do {
      iVar4 = *(int *)((long)local_678 + lVar11);
      iVar10 = iVar12 - *(int *)((long)local_6a8 + lVar11);
      if (0x80 - iVar4 <= iVar10) goto LAB_00107140;
      if ((int)*pcVar6 - 0x30U < 10) {
        memmove(local_648 + lVar11 * 0x20 + (long)iVar10,pcVar6,(long)iVar4);
        pcVar8 = pcVar6;
      }
      else {
        pcVar8 = local_648 + lVar11 * 0x20 + (long)iVar4;
      }
      lVar11 = lVar11 + 4;
      memset(pcVar8,0x20,(long)iVar10);
      pcVar6[iVar10 + iVar4] = '\0';
      pcVar6 = pcVar6 + 0x80;
    } while (lVar11 != 0x30);
    lVar11 = 0;
    do {
      puVar2 = (&PTR_DAT_00127040)[lVar11];
      lVar3 = local_6b8[lVar11];
      pcVar8 = &DAT_00127400 + (-(int)lVar11 & 0x600);
      pcVar6 = local_648;
      if (lVar3 == 0) {
        do {
          uVar5 = snprintf(pcVar8,0x80,"%s",puVar2);
          if (0x7f < uVar5) goto LAB_00107140;
          pcVar6 = pcVar6 + 0x80;
          pcVar8 = pcVar8 + 0x80;
        } while (pcVar6 != local_48);
      }
      else {
        do {
          if ((0x80 < lVar3 - (long)puVar2) ||
             (uVar5 = __snprintf_chk(pcVar8,0x80,1,0xffffffffffffffff,"%.*s%s%s",
                                     lVar3 - (long)puVar2 & 0xffffffff,puVar2,pcVar6,lVar3 + 2),
             0x7f < uVar5)) goto LAB_00107140;
          pcVar6 = pcVar6 + 0x80;
          pcVar8 = pcVar8 + 0x80;
        } while (pcVar6 != local_48);
      }
      bVar13 = lVar11 != 1;
      lVar11 = 1;
    } while (bVar13);
    DAT_001273e8 = 1;
  }
LAB_00107140:
  if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
    return;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_001071c0(long param_1,long param_2,undefined1 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  puVar1 = (undefined8 *)FUN_00119d00(0x20);
  uVar2 = 0;
  if (param_2 != 0) {
    uVar2 = FUN_0011a180(param_2);
  }
  puVar1[1] = uVar2;
  uVar2 = 0;
  if (param_1 != 0) {
    uVar2 = FUN_0011a180(param_1);
  }
  *puVar1 = uVar2;
  *(undefined1 *)(puVar1 + 2) = param_3;
  puVar1[3] = DAT_001283a0;
  DAT_001283a0 = puVar1;
  return;
}



void FUN_00107230(undefined8 param_1,undefined8 param_2,ulong *param_3,uint param_4,uint param_5)

{
  int iVar1;
  long in_FS_OFFSET;
  undefined1 auVar2 [16];
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 uStack_128;
  byte local_127;
  undefined4 local_124;
  uint local_118;
  undefined4 local_114;
  undefined4 local_110;
  ushort local_10c;
  ulong local_108;
  undefined8 local_100;
  ulong local_f8;
  undefined8 local_e8;
  undefined4 local_e0;
  undefined8 local_d8;
  undefined4 local_d0;
  ulong local_c8;
  uint local_c0;
  undefined8 local_b8;
  undefined4 local_b0;
  uint local_a8;
  uint local_a4;
  uint local_a0;
  uint local_9c;
  long local_20;
  
  local_20 = *(long *)(in_FS_OFFSET + 0x28);
  iVar1 = statx(param_1,param_2,param_4 | 0x800,param_5,&uStack_128);
  if (-1 < iVar1) {
    *param_3 = ((ulong)local_9c & 0xffffff00) << 0xc |
               ((ulong)local_a0 & 0xfffff000) << 0x20 | (ulong)((local_a0 & 0xfff) << 8) |
               (ulong)(byte)local_9c;
    param_3[1] = local_108;
    param_3[2] = (ulong)local_118;
    param_3[3] = CONCAT44(local_114,(uint)local_10c);
    *(undefined4 *)(param_3 + 4) = local_110;
    auVar2._8_4_ = local_124;
    auVar2._0_8_ = local_100;
    auVar2._12_4_ = 0;
    *(undefined1 (*) [16])(param_3 + 6) = auVar2;
    param_3[5] = ((ulong)local_a4 & 0xffffff00) << 0xc |
                 ((ulong)local_a8 & 0xfffff000) << 0x20 | (ulong)((local_a8 & 0xfff) << 8) |
                 (ulong)(byte)local_a4;
    auVar3._8_4_ = local_b0;
    auVar3._0_8_ = local_b8;
    auVar3._12_4_ = 0;
    param_3[0xe] = (ulong)local_c0;
    param_3[8] = local_f8;
    auVar5._8_4_ = local_e0;
    auVar5._0_8_ = local_e8;
    auVar5._12_4_ = 0;
    *(undefined1 (*) [16])(param_3 + 0xb) = auVar3;
    param_3[0xd] = local_c8;
    *(undefined1 (*) [16])(param_3 + 9) = auVar5;
    if ((param_5 & 0x800) != 0) {
      if ((local_127 & 8) == 0) {
        *(undefined4 *)(param_3 + 0xb) = 0xffffffff;
        *(undefined4 *)((long)param_3 + 0x5c) = 0xffffffff;
        *(undefined4 *)(param_3 + 0xc) = 0xffffffff;
        *(undefined4 *)((long)param_3 + 100) = 0xffffffff;
      }
      else {
        auVar4._8_4_ = local_d0;
        auVar4._0_8_ = local_d8;
        auVar4._12_4_ = 0;
        *(undefined1 (*) [16])(param_3 + 0xb) = auVar4;
      }
    }
  }
  if (local_20 == *(long *)(in_FS_OFFSET + 0x28)) {
    return;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_001073e0(undefined8 *param_1,undefined8 *param_2)

{
  strcmp((char *)*param_1,(char *)*param_2);
  return;
}



void FUN_001073f0(undefined8 *param_1,undefined8 *param_2)

{
  strcmp((char *)*param_2,(char *)*param_1);
  return;
}



void FUN_00107410(undefined8 *param_1,undefined8 *param_2,code *UNRECOVERED_JUMPTABLE)

{
  int iVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar2 = strrchr((char *)*param_1,0x2e);
  pcVar3 = strrchr((char *)*param_2,0x2e);
  if (pcVar3 == (char *)0x0) {
    pcVar3 = "";
  }
  if (pcVar2 == (char *)0x0) {
    pcVar2 = "";
  }
  iVar1 = (*UNRECOVERED_JUMPTABLE)(pcVar2,pcVar3);
  if (iVar1 == 0) {
                    // WARNING: Could not recover jumptable at 0x00107477. Too many branches
                    // WARNING: Treating indirect jump as call
    (*UNRECOVERED_JUMPTABLE)(*param_1,*param_2);
    return;
  }
  return;
}



void FUN_00107490(undefined8 param_1,undefined8 param_2)

{
  FUN_00107410(param_2,param_1,strcmp);
  return;
}



void FUN_001074b0(undefined8 param_1,undefined8 param_2)

{
  FUN_00107410(param_1,param_2,strcmp);
  return;
}



byte * FUN_001074c0(byte *param_1,char param_2)

{
  byte bVar1;
  byte *pbVar2;
  size_t sVar3;
  byte *pbVar4;
  
  sVar3 = strlen((char *)param_1);
  pbVar4 = (byte *)FUN_00119e00(3,sVar3 + 1);
  bVar1 = *param_1;
  pbVar2 = pbVar4;
  do {
    while( true ) {
      if (bVar1 == 0) {
        *pbVar2 = 0;
        return pbVar4;
      }
      param_1 = param_1 + 1;
      if ((bVar1 != 0x2f) || (param_2 == '\0')) break;
      *pbVar2 = 0x2f;
LAB_0010750f:
      bVar1 = *param_1;
      pbVar2 = pbVar2 + 1;
    }
    if ((&DAT_00128000)[bVar1] != '\0') {
      *pbVar2 = bVar1;
      goto LAB_0010750f;
    }
    __sprintf_chk(pbVar2,1,0xffffffffffffffff,"%%%02x",bVar1);
    bVar1 = *param_1;
    pbVar2 = pbVar2 + 3;
  } while( true );
}



void FUN_00107580(void *param_1,size_t param_2)

{
  DAT_00128218 = DAT_00128218 + param_2;
  fwrite_unlocked(param_1,1,param_2,stdout);
  return;
}



char * FUN_001075a0(ulong param_1,ulong param_2)

{
  ulong uVar1;
  uint uVar2;
  char *in_RAX;
  char *pcVar3;
  ulong uVar5;
  char *pcVar4;
  
  if (param_2 <= param_1) {
    return in_RAX;
  }
  do {
    while( true ) {
      uVar5 = DAT_001282e0;
      uVar1 = param_1 + 1;
      pcVar3 = stdout->_IO_write_ptr;
      if ((DAT_001282e0 == 0) || (param_2 / DAT_001282e0 <= uVar1 / DAT_001282e0)) break;
      if (pcVar3 < stdout->_IO_write_end) {
        stdout->_IO_write_ptr = pcVar3 + 1;
        *pcVar3 = '\t';
      }
      else {
        __overflow(stdout,9);
        uVar5 = DAT_001282e0;
      }
      pcVar3 = (char *)(param_1 / uVar5);
      param_1 = (uVar5 + param_1) - param_1 % uVar5;
      if (param_2 <= param_1) {
        return pcVar3;
      }
    }
    if (pcVar3 < stdout->_IO_write_end) {
      pcVar4 = pcVar3 + 1;
      stdout->_IO_write_ptr = pcVar4;
      *pcVar3 = ' ';
    }
    else {
      uVar2 = __overflow(stdout,0x20);
      pcVar4 = (char *)(ulong)uVar2;
    }
    param_1 = uVar1;
  } while (uVar1 < param_2);
  return pcVar4;
}



void FUN_00107670(char *param_1,long param_2)

{
  long lVar1;
  long lVar2;
  char *pcVar3;
  long lVar4;
  ulong uVar5;
  
  lVar1 = *(long *)(param_2 + 0x18);
  lVar2 = *(long *)(param_2 + 0x10);
  if (7 < (ulong)(lVar1 - lVar2)) {
    if (lVar1 == lVar2) {
      *(byte *)(param_2 + 0x50) = *(byte *)(param_2 + 0x50) | 2;
    }
    lVar4 = lVar1 + (-lVar1 & *(ulong *)(param_2 + 0x30));
    if ((ulong)(*(long *)(param_2 + 0x20) - *(long *)(param_2 + 8)) <
        (ulong)(lVar4 - *(long *)(param_2 + 8))) {
      lVar4 = *(long *)(param_2 + 0x20);
    }
    uVar5 = 0;
    *(long *)(param_2 + 0x10) = lVar4;
    *(long *)(param_2 + 0x18) = lVar4;
    fputs_unlocked(param_1,stdout);
    do {
      lVar4 = uVar5 * 8;
      uVar5 = uVar5 + 1;
      __printf_chk(1,&DAT_0011cf00,*(undefined8 *)(lVar2 + lVar4));
    } while (uVar5 < (ulong)(lVar1 - lVar2) >> 3);
    pcVar3 = stdout->_IO_write_ptr;
    if (stdout->_IO_write_end <= pcVar3) {
      __overflow(stdout,10);
      return;
    }
    stdout->_IO_write_ptr = pcVar3 + 1;
    *pcVar3 = '\n';
  }
  return;
}



void FUN_00107750(void)

{
  if (DAT_00128238 == 0) {
    DAT_00128234 = DAT_00128234 + 1;
  }
  return;
}



void FUN_00107770(char param_1,undefined8 param_2,undefined8 param_3)

{
  undefined8 uVar1;
  int *piVar2;
  
  uVar1 = FUN_00118590(4,param_3);
  piVar2 = __errno_location();
  error(0,*piVar2,param_2,uVar1);
  if (param_1 == '\0') {
    if (DAT_00128230 == 0) {
      DAT_00128230 = 1;
      return;
    }
  }
  else {
    DAT_00128230 = 2;
  }
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_001077e0(char param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  long in_FS_OFFSET;
  _union_1457 local_d8;
  undefined8 local_d0;
  undefined8 uStack_c8;
  undefined8 local_c0;
  undefined8 uStack_b8;
  undefined8 local_b0;
  undefined8 uStack_a8;
  undefined8 local_a0;
  undefined8 uStack_98;
  undefined8 local_90;
  undefined8 uStack_88;
  undefined8 local_80;
  undefined8 uStack_78;
  undefined8 local_70;
  undefined8 uStack_68;
  undefined8 local_60;
  undefined8 uStack_58;
  undefined4 local_50;
  long local_40;
  
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  piVar3 = &DAT_0011b600;
  if (param_1 == '\0') {
    do {
      while( true ) {
        iVar1 = *piVar3;
        iVar2 = sigismember((sigset_t *)&DAT_00128240,iVar1);
        if (iVar2 == 0) break;
        piVar3 = piVar3 + 1;
        signal(iVar1,(__sighandler_t)0x0);
        if (piVar3 == (int *)&DAT_0011b630) goto LAB_0010784b;
      }
      piVar3 = piVar3 + 1;
    } while (piVar3 != (int *)&DAT_0011b630);
  }
  else {
    piVar4 = &DAT_0011b600;
    sigemptyset((sigset_t *)&DAT_00128240);
    do {
      iVar1 = *piVar4;
      sigaction(iVar1,(sigaction *)0x0,(sigaction *)&local_d8);
      if (local_d8.sa_handler != (__sighandler_t)0x1) {
        sigaddset((sigset_t *)&DAT_00128240,iVar1);
      }
      piVar4 = piVar4 + 1;
    } while (piVar4 != (int *)&DAT_0011b630);
    local_50 = 0x10000000;
    local_d0 = _DAT_00128240;
    uStack_c8 = uRam0000000000128248;
    local_c0 = _DAT_00128250;
    uStack_b8 = uRam0000000000128258;
    local_b0 = _DAT_00128260;
    uStack_a8 = uRam0000000000128268;
    local_a0 = _DAT_00128270;
    uStack_98 = uRam0000000000128278;
    local_90 = _DAT_00128280;
    uStack_88 = uRam0000000000128288;
    local_80 = _DAT_00128290;
    uStack_78 = uRam0000000000128298;
    local_70 = _DAT_001282a0;
    uStack_68 = uRam00000000001282a8;
    local_60 = _DAT_001282b0;
    uStack_58 = uRam00000000001282b8;
    do {
      iVar1 = *piVar3;
      iVar2 = sigismember((sigset_t *)&DAT_00128240,iVar1);
      if (iVar2 != 0) {
        local_d8.sa_handler = FUN_00106900;
        if (iVar1 == 0x14) {
          local_d8.sa_handler = FUN_00107750;
        }
        sigaction(iVar1,(sigaction *)&local_d8,(sigaction *)0x0);
      }
      piVar3 = piVar3 + 1;
    } while (piVar3 != (int *)&DAT_0011b630);
  }
LAB_0010784b:
  if (local_40 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return;
}



void FUN_00107990(size_t *param_1)

{
  __pid_t _Var1;
  
  if (DAT_00128330 == '\0') {
    DAT_00128330 = '\x01';
    _Var1 = tcgetpgrp(1);
    if (-1 < _Var1) {
      FUN_001077e0(1);
    }
    if (DAT_00127088 == 0) {
      FUN_00107990(&DAT_00127060);
      FUN_00107990(&DAT_00127090);
      FUN_00107990(&DAT_00127070);
    }
    else {
      FUN_00107990(&DAT_00127080);
    }
  }
  fwrite_unlocked((void *)param_1[1],*param_1,1,stdout);
  return;
}



size_t FUN_00107a30(undefined8 *param_1,byte *param_2,undefined8 param_3,int param_4,size_t *param_5
                   ,byte *param_6)

{
  bool bVar1;
  byte bVar2;
  uint uVar3;
  int iVar4;
  ulong uVar5;
  size_t sVar6;
  ushort **ppuVar7;
  byte *pbVar8;
  long lVar9;
  long lVar10;
  byte *pbVar11;
  byte *pbVar12;
  byte *pbVar13;
  long in_FS_OFFSET;
  byte *local_90;
  bool local_69;
  wchar_t local_4c;
  mbstate_t local_48;
  long local_40;
  
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  local_90 = (byte *)*param_1;
  uVar3 = FUN_00118140(param_3);
  if ((uVar3 < 3 & DAT_001282f8) != 0) {
    if (param_4 != 0) {
      bVar1 = true;
      goto LAB_00107bb6;
    }
    uVar5 = strlen((char *)param_2);
    if (0x1fff < uVar5) {
      local_90 = (byte *)FUN_00119d00(uVar5 + 1);
    }
    memcpy(local_90,param_2,uVar5 + 1);
    local_69 = false;
LAB_00107c10:
    sVar6 = __ctype_get_mb_cur_max();
    pbVar8 = local_90 + uVar5;
    if (sVar6 < 2) {
      sVar6 = uVar5;
      if (local_90 < pbVar8) {
        ppuVar7 = __ctype_b_loc();
        pbVar11 = local_90;
        do {
          if ((*(byte *)((long)*ppuVar7 + (ulong)*pbVar11 * 2 + 1) & 0x40) == 0) {
            *pbVar11 = 0x3f;
          }
          pbVar11 = pbVar11 + 1;
        } while (pbVar11 != pbVar8);
      }
    }
    else if (local_90 < pbVar8) {
      sVar6 = 0;
      pbVar11 = local_90;
      pbVar13 = local_90;
      do {
        bVar2 = *pbVar13;
        pbVar12 = pbVar11 + 1;
        if ((char)bVar2 < '`') {
          if ('@' < (char)bVar2) goto LAB_00107c60;
          if ('#' < (char)bVar2) {
            if (0x1a < (byte)(bVar2 - 0x25)) goto LAB_00107c8c;
            goto LAB_00107c60;
          }
          if ('\x1f' < (char)bVar2) goto LAB_00107c60;
LAB_00107c8c:
          local_48.__count = 0;
          local_48.__value = (_union_27)0x0;
          while (lVar9 = FUN_00113b30(&local_4c,pbVar13,(long)pbVar8 - (long)pbVar13,&local_48),
                lVar9 != -1) {
            if (lVar9 == -2) {
              *pbVar11 = 0x3f;
              sVar6 = sVar6 + 1;
              goto LAB_00107e4a;
            }
            lVar10 = 1;
            if (lVar9 != 0) {
              lVar10 = lVar9;
            }
            iVar4 = wcwidth(local_4c);
            if (iVar4 < 0) {
              *pbVar11 = 0x3f;
              sVar6 = sVar6 + 1;
            }
            else {
              lVar9 = 0;
              do {
                pbVar11[lVar9] = pbVar13[lVar9];
                lVar9 = lVar9 + 1;
              } while (lVar10 != lVar9);
              pbVar12 = pbVar11 + lVar10;
              sVar6 = sVar6 + (long)iVar4;
            }
            pbVar13 = pbVar13 + lVar10;
            iVar4 = mbsinit(&local_48);
            if (iVar4 != 0) goto LAB_00107c6d;
            pbVar11 = pbVar12;
            pbVar12 = pbVar12 + 1;
          }
          *pbVar11 = 0x3f;
          pbVar13 = pbVar13 + 1;
          sVar6 = sVar6 + 1;
        }
        else {
          if (0x1d < (byte)(bVar2 + 0x9f)) goto LAB_00107c8c;
LAB_00107c60:
          *pbVar11 = bVar2;
          pbVar13 = pbVar13 + 1;
          sVar6 = sVar6 + 1;
        }
LAB_00107c6d:
        pbVar11 = pbVar12;
      } while (pbVar13 < pbVar8);
LAB_00107e4a:
      uVar5 = (long)pbVar12 - (long)local_90;
    }
    else {
      uVar5 = 0;
      sVar6 = 0;
    }
    bVar2 = 0;
    if ((DAT_001283c8 != '\0') && (bVar2 = 0, DAT_001283c9 != '\0')) {
LAB_00107b17:
      bVar2 = local_69 ^ 1;
    }
    *param_6 = bVar2;
    if (param_5 == (size_t *)0x0) goto LAB_00107b70;
    goto LAB_00107e18;
  }
  bVar1 = false;
  if (param_4 == 0) {
    uVar5 = strlen((char *)param_2);
    local_69 = false;
    local_90 = param_2;
  }
  else {
LAB_00107bb6:
    uVar5 = FUN_00118220(local_90,0x2000,param_2,0xffffffffffffffff,param_3);
    if (0x1fff < uVar5) {
      local_90 = (byte *)FUN_00119d00(uVar5 + 1);
      FUN_00118220(local_90,uVar5 + 1,param_2,0xffffffffffffffff,param_3);
    }
    local_69 = true;
    if (*param_2 == *local_90) {
      sVar6 = strlen((char *)param_2);
      local_69 = uVar5 != sVar6;
    }
    if (bVar1) goto LAB_00107c10;
  }
  if (param_5 == (size_t *)0x0) {
    if ((DAT_001283c8 == '\0') || (DAT_001283c9 == '\0')) {
      *param_6 = 0;
    }
    else {
      *param_6 = local_69 ^ 1;
    }
    goto LAB_00107b70;
  }
  sVar6 = __ctype_get_mb_cur_max();
  if (sVar6 < 2) {
    if (local_90 < local_90 + uVar5) {
      ppuVar7 = __ctype_b_loc();
      sVar6 = 0;
      pbVar8 = local_90;
      do {
        sVar6 = (sVar6 + 1) - (ulong)(((*ppuVar7)[*pbVar8] & 0x4000) == 0);
        pbVar8 = pbVar8 + 1;
      } while (local_90 + uVar5 != pbVar8);
      if ((DAT_001283c8 != '\0') && (DAT_001283c9 != '\0')) goto LAB_00107b17;
LAB_00107e10:
      *param_6 = 0;
    }
    else if ((DAT_001283c8 == '\0') || (DAT_001283c9 == '\0')) {
      sVar6 = 0;
      *param_6 = 0;
    }
    else {
      sVar6 = 0;
      *param_6 = local_69 ^ 1;
    }
  }
  else {
    iVar4 = FUN_00113c00(local_90,uVar5,3);
    sVar6 = (size_t)iVar4;
    if ((DAT_001283c8 == '\0') || (DAT_001283c9 == '\0')) goto LAB_00107e10;
    *param_6 = local_69 ^ 1;
  }
LAB_00107e18:
  *param_5 = sVar6;
LAB_00107b70:
  *param_1 = local_90;
  if (local_40 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return uVar5;
}



long FUN_00107f50(undefined1 *param_1,undefined8 param_2,undefined4 param_3)

{
  long in_FS_OFFSET;
  byte local_2039;
  undefined1 *local_2038;
  long local_2030;
  undefined1 local_2028 [8200];
  long local_20;
  
  local_20 = *(long *)(in_FS_OFFSET + 0x28);
  local_2038 = local_2028;
  FUN_00107a30(&local_2038,param_1,param_2,param_3,&local_2030,&local_2039);
  if ((local_2038 != param_1) && (local_2038 != local_2028)) {
    free(local_2038);
  }
  if (local_20 == *(long *)(in_FS_OFFSET + 0x28)) {
    return (ulong)local_2039 + local_2030;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



long FUN_00107ff0(undefined8 *param_1)

{
  char cVar1;
  long lVar2;
  size_t sVar3;
  char *pcVar4;
  long lVar5;
  long in_FS_OFFSET;
  undefined1 auStack_2b8 [664];
  long local_20;
  
  local_20 = *(long *)(in_FS_OFFSET + 0x28);
  if (DAT_0012831c == '\0') {
    lVar5 = 0;
LAB_001080c2:
    if (DAT_0012834c != '\0') {
      if (DAT_0012835c != 4) goto LAB_0010803f;
      lVar2 = 2;
      if (*(char *)(param_1 + 0x17) != '\0') {
        pcVar4 = (char *)FUN_00112780(param_1[0xb],auStack_2b8,DAT_00128348,0x200,DAT_00128340);
        sVar3 = strlen(pcVar4);
        lVar2 = sVar3 + 1;
      }
LAB_0010804a:
      lVar5 = lVar5 + lVar2;
    }
    if (DAT_00128389 != '\0') {
      if (DAT_0012835c == 4) {
        sVar3 = strlen((char *)param_1[0x16]);
      }
      else {
LAB_00108129:
        sVar3 = (size_t)DAT_00128378;
      }
      lVar5 = lVar5 + sVar3 + 1;
      lVar2 = param_1[0x19];
      goto joined_r0x00108141;
    }
  }
  else {
    if (DAT_0012835c == 4) {
      pcVar4 = (char *)FUN_00113ac0(param_1[4],auStack_2b8);
      sVar3 = strlen(pcVar4);
      lVar5 = sVar3 + 1;
      goto LAB_001080c2;
    }
    lVar5 = (long)DAT_00128384 + 1;
    if (DAT_0012834c != '\0') {
LAB_0010803f:
      lVar2 = (long)DAT_00128380 + 1;
      goto LAB_0010804a;
    }
    if (DAT_00128389 != '\0') goto LAB_00108129;
  }
  lVar2 = param_1[0x19];
joined_r0x00108141:
  if (lVar2 == 0) {
    lVar2 = FUN_00107f50(*param_1,DAT_001282f0,*(undefined4 *)((long)param_1 + 0xc4));
  }
  lVar5 = lVar5 + lVar2;
  if (DAT_00128334 != 0) {
    cVar1 = FUN_00106bc0(*(undefined1 *)(param_1 + 0x17),*(undefined4 *)(param_1 + 6),
                         *(undefined4 *)(param_1 + 0x15));
    lVar5 = (lVar5 + 1) - (ulong)(cVar1 == '\0');
  }
  if (local_20 == *(long *)(in_FS_OFFSET + 0x28)) {
    return lVar5;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



ulong FUN_001081c0(char param_1)

{
  undefined8 *puVar1;
  ulong *puVar2;
  undefined8 *puVar3;
  long lVar4;
  ulong uVar5;
  ulong uVar6;
  long lVar7;
  ulong uVar8;
  long lVar9;
  long lVar10;
  ulong uVar11;
  ulong uVar12;
  ulong uVar13;
  char *pcVar14;
  
  lVar7 = DAT_001272e0;
  uVar12 = DAT_001283d0;
  if (DAT_00128220 <= DAT_001283d0) {
    uVar12 = DAT_00128220;
  }
  if (DAT_00128220 == 0) {
    uVar12 = DAT_001283d0;
  }
  if (DAT_001272e0 < (long)uVar12) {
    lVar4 = DAT_001272e0 + 1;
    DAT_00128228 = (char *)FUN_00119f30(DAT_00128228,&DAT_001272e0,uVar12 - DAT_001272e0,
                                        0xffffffffffffffff,0x18);
    lVar9 = DAT_001272e0 - lVar7;
    if ((SCARRY8(DAT_001272e0,lVar4)) ||
       (lVar10 = lVar9 * (DAT_001272e0 + lVar4),
       SEXT816(lVar10) != SEXT816(lVar9) * SEXT816(DAT_001272e0 + lVar4))) {
                    // WARNING: Subroutine does not return
      FUN_0011a1c0();
    }
    lVar9 = FUN_00119e30(lVar10 >> 1);
    pcVar14 = DAT_00128228;
    if (lVar7 < DAT_001272e0) {
      lVar4 = lVar4 * 8;
      lVar7 = DAT_001272e0 * 8;
      do {
        *(long *)(pcVar14 + lVar4 * 3 + -8) = lVar9;
        lVar9 = lVar9 + lVar4;
        lVar4 = lVar4 + 8;
      } while (lVar4 != lVar7 + 8);
    }
    if (0 < (long)uVar12) goto LAB_00108205;
LAB_00108445:
    if ((long)DAT_001283d0 < 1) {
      return uVar12;
    }
  }
  else {
    if ((long)uVar12 < 1) goto LAB_00108445;
LAB_00108205:
    uVar11 = DAT_001283d0;
    pcVar14 = DAT_00128228;
    uVar13 = 0;
    lVar7 = 3;
    do {
      puVar3 = *(undefined8 **)(pcVar14 + lVar7 * 8 + -8);
      uVar13 = uVar13 + 8;
      pcVar14[lVar7 * 8 + -0x18] = '\x01';
      *(long *)(pcVar14 + lVar7 * 8 + -0x10) = lVar7;
      puVar1 = (undefined8 *)((long)puVar3 + uVar13);
      if ((uVar13 & 8) == 0) goto LAB_00108260;
      *puVar3 = 3;
      for (puVar3 = puVar3 + 1; puVar1 != puVar3; puVar3 = puVar3 + 2) {
LAB_00108260:
        *puVar3 = 3;
        puVar3[1] = 3;
      }
      lVar7 = lVar7 + 3;
    } while (lVar7 != uVar12 * 3 + 3);
    if ((long)uVar11 < 1) goto LAB_0010834d;
  }
  lVar7 = 0;
  do {
    lVar4 = FUN_00107ff0(*(undefined8 *)(DAT_001283c0 + lVar7 * 8));
    uVar13 = DAT_001283d0;
    uVar11 = DAT_001282d0;
    if (0 < (long)uVar12) {
      uVar5 = 0;
      pcVar14 = DAT_00128228;
      do {
        uVar6 = uVar5 + 1;
        if (*pcVar14 != '\0') {
          if (param_1 == '\0') {
            uVar8 = lVar7 % (long)uVar6;
          }
          else {
            uVar8 = lVar7 / ((long)(uVar5 + uVar13) / (long)uVar6);
          }
          puVar2 = (ulong *)(*(long *)(pcVar14 + 0x10) + uVar8 * 8);
          uVar5 = lVar4 + (ulong)(uVar8 != uVar5) * 2;
          uVar8 = *puVar2;
          if (uVar8 < uVar5) {
            *(ulong *)(pcVar14 + 8) = *(long *)(pcVar14 + 8) + (uVar5 - uVar8);
            *puVar2 = uVar5;
            *pcVar14 = *(ulong *)(pcVar14 + 8) < uVar11;
          }
        }
        pcVar14 = pcVar14 + 0x18;
        uVar5 = uVar6;
      } while (uVar12 != uVar6);
    }
    lVar7 = lVar7 + 1;
  } while (lVar7 < (long)uVar13);
LAB_0010834d:
  if (1 < (long)uVar12) {
    pcVar14 = DAT_00128228 + uVar12 * 0x18 + -0x18;
    uVar11 = uVar12;
    do {
      if (*pcVar14 != '\0') {
        return uVar11;
      }
      uVar11 = uVar11 - 1;
      pcVar14 = pcVar14 + -0x18;
      uVar12 = 1;
    } while (uVar11 != 1);
  }
  return uVar12;
}



void FUN_00108460(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int iVar1;
  
  __s1 = (char *)*param_1;
  __s2 = (char *)*param_2;
  iVar1 = FUN_00111250(__s1,__s2);
  if (iVar1 == 0) {
    strcmp(__s1,__s2);
    return;
  }
  return;
}



void FUN_001084a0(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int iVar1;
  
  __s1 = (char *)*param_2;
  __s2 = (char *)*param_1;
  iVar1 = FUN_00111250(__s1,__s2);
  if (iVar1 == 0) {
    strcmp(__s1,__s2);
    return;
  }
  return;
}



void FUN_001084e0(undefined8 *param_1,undefined8 *param_2)

{
  if ((long)param_2[9] < (long)param_1[9] == (long)param_1[9] < (long)param_2[9]) {
    strcmp((char *)*param_2,(char *)*param_1);
    return;
  }
  return;
}



void FUN_00108520(undefined8 *param_1,undefined8 *param_2)

{
  if (((uint)((long)param_2[0x11] < (long)param_1[0x11]) -
      (uint)((long)param_1[0x11] < (long)param_2[0x11])) +
      ((uint)((long)param_2[0x10] < (long)param_1[0x10]) -
      (uint)((long)param_1[0x10] < (long)param_2[0x10])) * 2 == 0) {
    strcmp((char *)*param_2,(char *)*param_1);
    return;
  }
  return;
}



void FUN_00108580(undefined8 *param_1,undefined8 *param_2)

{
  if (((uint)((long)param_2[0xf] < (long)param_1[0xf]) -
      (uint)((long)param_1[0xf] < (long)param_2[0xf])) +
      ((uint)((long)param_2[0xe] < (long)param_1[0xe]) -
      (uint)((long)param_1[0xe] < (long)param_2[0xe])) * 2 == 0) {
    strcmp((char *)*param_2,(char *)*param_1);
    return;
  }
  return;
}



void FUN_001085d0(undefined8 *param_1,undefined8 *param_2)

{
  if (((uint)((long)param_2[0xd] < (long)param_1[0xd]) -
      (uint)((long)param_1[0xd] < (long)param_2[0xd])) +
      ((uint)((long)param_2[0xc] < (long)param_1[0xc]) -
      (uint)((long)param_1[0xc] < (long)param_2[0xc])) * 2 == 0) {
    strcmp((char *)*param_2,(char *)*param_1);
    return;
  }
  return;
}



void FUN_00108620(undefined8 *param_1,undefined8 *param_2)

{
  if (((uint)((long)param_2[0xf] < (long)param_1[0xf]) -
      (uint)((long)param_1[0xf] < (long)param_2[0xf])) +
      ((uint)((long)param_2[0xe] < (long)param_1[0xe]) -
      (uint)((long)param_1[0xe] < (long)param_2[0xe])) * 2 == 0) {
    strcmp((char *)*param_2,(char *)*param_1);
    return;
  }
  return;
}



void FUN_00108670(void)

{
  int __sig;
  long in_FS_OFFSET;
  sigset_t sStack_b8;
  long local_30;
  
  local_30 = *(long *)(in_FS_OFFSET + 0x28);
  while ((DAT_00128238 != 0 || (DAT_00128234 != 0))) {
    if (DAT_00128330 != '\0') {
      FUN_00107990(&DAT_00127060);
      FUN_00107990(&DAT_00127070);
    }
    fflush_unlocked(stdout);
    sigprocmask(0,(sigset_t *)&DAT_00128240,&sStack_b8);
    __sig = DAT_00128238;
    if (DAT_00128234 == 0) {
      signal(DAT_00128238,(__sighandler_t)0x0);
    }
    else {
      DAT_00128234 = DAT_00128234 + -1;
      __sig = 0x13;
    }
    raise(__sig);
    sigprocmask(2,&sStack_b8,(sigset_t *)0x0);
  }
  if (local_30 == *(long *)(in_FS_OFFSET + 0x28)) {
    return;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_00108770(undefined4 param_1)

{
  long lVar1;
  
  if (DAT_0012834d == '\0') {
    lVar1 = FUN_00113660();
    if (lVar1 != 0) {
      FUN_00113da0(lVar1,3);
      return;
    }
  }
  __snprintf_chk(0,0,1,0xffffffffffffffff,&DAT_0011cf05,param_1);
  return;
}



void FUN_001087c0(void)

{
  undefined8 *puVar1;
  long lVar2;
  
  if (0 < DAT_001283d0) {
    lVar2 = 0;
    do {
      puVar1 = *(undefined8 **)(DAT_001283c0 + lVar2 * 8);
      free((void *)*puVar1);
      free((void *)puVar1[1]);
      free((void *)puVar1[2]);
      if ((undefined *)puVar1[0x16] != &DAT_0012702a) {
        FUN_00110030();
      }
      lVar2 = lVar2 + 1;
    } while (lVar2 < DAT_001283d0);
  }
  DAT_001283c9 = 0;
  DAT_001283d0 = 0;
  DAT_00128388 = 0;
  DAT_00128384 = 0;
  DAT_00128380 = 0;
  DAT_0012837c = 0;
  DAT_00128374 = 0;
  DAT_00128370 = 0;
  DAT_0012836c = 0;
  DAT_00128378 = 0;
  DAT_00128368 = 0;
  DAT_00128364 = 0;
  DAT_00128360 = 0;
  return;
}



void FUN_001088b0(undefined8 *param_1,undefined8 *param_2)

{
  char *__s2;
  char *__s1;
  int *piVar1;
  
  __s2 = (char *)*param_2;
  __s1 = (char *)*param_1;
  piVar1 = __errno_location();
  *piVar1 = 0;
  strcoll(__s1,__s2);
  return;
}



void FUN_001088e0(undefined8 *param_1,undefined8 *param_2)

{
  char *__s2;
  char *__s1;
  int *piVar1;
  
  __s2 = (char *)*param_1;
  __s1 = (char *)*param_2;
  piVar1 = __errno_location();
  *piVar1 = 0;
  strcoll(__s1,__s2);
  return;
}



void FUN_00108910(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int *piVar1;
  
  if ((long)param_1[9] < (long)param_2[9] == (long)param_2[9] < (long)param_1[9]) {
    __s1 = (char *)*param_1;
    __s2 = (char *)*param_2;
    piVar1 = __errno_location();
    *piVar1 = 0;
    strcoll(__s1,__s2);
    return;
  }
  return;
}



void FUN_00108960(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int *piVar1;
  
  if ((long)param_2[9] < (long)param_1[9] == (long)param_1[9] < (long)param_2[9]) {
    __s1 = (char *)*param_2;
    __s2 = (char *)*param_1;
    piVar1 = __errno_location();
    *piVar1 = 0;
    strcoll(__s1,__s2);
    return;
  }
  return;
}



void FUN_001089b0(undefined8 *param_1,undefined8 *param_2)

{
  if ((long)param_1[9] < (long)param_2[9] == (long)param_2[9] < (long)param_1[9]) {
    strcmp((char *)*param_1,(char *)*param_2);
    return;
  }
  return;
}



int FUN_001089f0(undefined8 *param_1,undefined8 *param_2)

{
  long lVar1;
  int iVar2;
  int iVar3;
  
  if (param_1[0x19] == 0) {
    iVar2 = FUN_00107f50(*param_1,DAT_001282f0,*(undefined4 *)((long)param_1 + 0xc4));
    lVar1 = param_2[0x19];
  }
  else {
    lVar1 = param_2[0x19];
    iVar2 = (int)param_1[0x19];
  }
  iVar3 = (int)lVar1;
  if (lVar1 == 0) {
    iVar3 = FUN_00107f50(*param_2,DAT_001282f0,*(undefined4 *)((long)param_2 + 0xc4));
  }
  if (iVar2 - iVar3 != 0) {
    return iVar2 - iVar3;
  }
  iVar2 = strcmp((char *)*param_1,(char *)*param_2);
  return iVar2;
}



void FUN_00108a90(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int *piVar1;
  
  if (((uint)((long)param_1[0x11] < (long)param_2[0x11]) -
      (uint)((long)param_2[0x11] < (long)param_1[0x11])) +
      ((uint)((long)param_1[0x10] < (long)param_2[0x10]) -
      (uint)((long)param_2[0x10] < (long)param_1[0x10])) * 2 == 0) {
    __s1 = (char *)*param_1;
    __s2 = (char *)*param_2;
    piVar1 = __errno_location();
    *piVar1 = 0;
    strcoll(__s1,__s2);
    return;
  }
  return;
}



void FUN_00108b10(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int *piVar1;
  
  if (((uint)((long)param_2[0x11] < (long)param_1[0x11]) -
      (uint)((long)param_1[0x11] < (long)param_2[0x11])) +
      ((uint)((long)param_2[0x10] < (long)param_1[0x10]) -
      (uint)((long)param_1[0x10] < (long)param_2[0x10])) * 2 == 0) {
    __s1 = (char *)*param_2;
    __s2 = (char *)*param_1;
    piVar1 = __errno_location();
    *piVar1 = 0;
    strcoll(__s1,__s2);
    return;
  }
  return;
}



void FUN_00108b90(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int *piVar1;
  
  if (((uint)((long)param_1[0xf] < (long)param_2[0xf]) -
      (uint)((long)param_2[0xf] < (long)param_1[0xf])) +
      ((uint)((long)param_1[0xe] < (long)param_2[0xe]) -
      (uint)((long)param_2[0xe] < (long)param_1[0xe])) * 2 == 0) {
    __s1 = (char *)*param_1;
    __s2 = (char *)*param_2;
    piVar1 = __errno_location();
    *piVar1 = 0;
    strcoll(__s1,__s2);
    return;
  }
  return;
}



void FUN_00108c00(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int *piVar1;
  
  if (((uint)((long)param_2[0xf] < (long)param_1[0xf]) -
      (uint)((long)param_1[0xf] < (long)param_2[0xf])) +
      ((uint)((long)param_2[0xe] < (long)param_1[0xe]) -
      (uint)((long)param_1[0xe] < (long)param_2[0xe])) * 2 == 0) {
    __s1 = (char *)*param_2;
    __s2 = (char *)*param_1;
    piVar1 = __errno_location();
    *piVar1 = 0;
    strcoll(__s1,__s2);
    return;
  }
  return;
}



void FUN_00108c70(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int *piVar1;
  
  if (((uint)((long)param_1[0xd] < (long)param_2[0xd]) -
      (uint)((long)param_2[0xd] < (long)param_1[0xd])) +
      ((uint)((long)param_1[0xc] < (long)param_2[0xc]) -
      (uint)((long)param_2[0xc] < (long)param_1[0xc])) * 2 == 0) {
    __s1 = (char *)*param_1;
    __s2 = (char *)*param_2;
    piVar1 = __errno_location();
    *piVar1 = 0;
    strcoll(__s1,__s2);
    return;
  }
  return;
}



void FUN_00108ce0(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int *piVar1;
  
  if (((uint)((long)param_2[0xd] < (long)param_1[0xd]) -
      (uint)((long)param_1[0xd] < (long)param_2[0xd])) +
      ((uint)((long)param_2[0xc] < (long)param_1[0xc]) -
      (uint)((long)param_1[0xc] < (long)param_2[0xc])) * 2 == 0) {
    __s1 = (char *)*param_2;
    __s2 = (char *)*param_1;
    piVar1 = __errno_location();
    *piVar1 = 0;
    strcoll(__s1,__s2);
    return;
  }
  return;
}



void FUN_00108d50(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int *piVar1;
  
  if (((uint)((long)param_1[0xf] < (long)param_2[0xf]) -
      (uint)((long)param_2[0xf] < (long)param_1[0xf])) +
      ((uint)((long)param_1[0xe] < (long)param_2[0xe]) -
      (uint)((long)param_2[0xe] < (long)param_1[0xe])) * 2 == 0) {
    __s1 = (char *)*param_1;
    __s2 = (char *)*param_2;
    piVar1 = __errno_location();
    *piVar1 = 0;
    strcoll(__s1,__s2);
    return;
  }
  return;
}



void FUN_00108dc0(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int *piVar1;
  
  if (((uint)((long)param_2[0xf] < (long)param_1[0xf]) -
      (uint)((long)param_1[0xf] < (long)param_2[0xf])) +
      ((uint)((long)param_2[0xe] < (long)param_1[0xe]) -
      (uint)((long)param_1[0xe] < (long)param_2[0xe])) * 2 == 0) {
    __s1 = (char *)*param_2;
    __s2 = (char *)*param_1;
    piVar1 = __errno_location();
    *piVar1 = 0;
    strcoll(__s1,__s2);
    return;
  }
  return;
}



void FUN_00108e30(void)

{
  uint uVar1;
  long *plVar2;
  undefined8 *puVar3;
  long lVar4;
  int iVar5;
  long *plVar6;
  long *plVar7;
  long lVar8;
  long lVar9;
  
  lVar8 = DAT_001283d0;
  if (DAT_001283b8 < (ulong)((DAT_001283d0 >> 1) + DAT_001283d0)) {
    free(DAT_001283c0);
    DAT_001283c0 = (long *)FUN_00119e30(lVar8,0x18);
    DAT_001283b8 = DAT_001283d0 * 3;
  }
  if (DAT_001283d0 < 1) {
    if (DAT_00128350 == 2) goto LAB_00108ed9;
  }
  else {
    plVar2 = DAT_001283c0 + DAT_001283d0;
    plVar6 = DAT_001283c0;
    lVar8 = DAT_001283e0;
    do {
      *plVar6 = lVar8;
      plVar6 = plVar6 + 1;
      lVar8 = lVar8 + 0xd0;
    } while (plVar6 != plVar2);
    if ((DAT_00128350 == 2) || ((DAT_001282d0 != 0 && (DAT_0012835c - 2U < 2)))) {
      lVar8 = 0;
      do {
        puVar3 = (undefined8 *)DAT_001283c0[lVar8];
        lVar9 = puVar3[0x19];
        if (lVar9 == 0) {
          lVar9 = FUN_00107f50(*puVar3,DAT_001282f0,*(undefined4 *)((long)puVar3 + 0xc4));
        }
        lVar4 = DAT_001283d0;
        lVar8 = lVar8 + 1;
        puVar3[0x19] = lVar9;
      } while (lVar8 < lVar4);
    }
  }
  if (DAT_00128350 == 6) {
    return;
  }
LAB_00108ed9:
  iVar5 = _setjmp((__jmp_buf_tag *)&DAT_00127320);
  lVar8 = DAT_001283d0;
  plVar2 = DAT_001283c0;
  uVar1 = DAT_00128350;
  if (iVar5 == 0) {
    iVar5 = 0;
  }
  else {
    if (DAT_00128350 == 4) {
                    // WARNING: Subroutine does not return
      __assert_fail("sort_type != sort_version","src/ls.c",0x1017,"sort_files");
    }
    if (0 < DAT_001283d0) {
      plVar6 = DAT_001283c0 + DAT_001283d0;
      plVar7 = DAT_001283c0;
      lVar9 = DAT_001283e0;
      do {
        *plVar7 = lVar9;
        plVar7 = plVar7 + 1;
        lVar9 = lVar9 + 0xd0;
      } while (plVar6 != plVar7);
    }
    iVar5 = 1;
  }
  if (uVar1 == 5) {
    uVar1 = DAT_00128358 + 5;
  }
  FUN_001140d0(plVar2,lVar8,
               (&PTR_FUN_00125fc0)
               [(ulong)DAT_00128314 +
                ((ulong)DAT_0012834f + ((long)iVar5 + (ulong)uVar1 * 2) * 2) * 2]);
  return;
}



void FUN_00109030(undefined8 *param_1,undefined8 *param_2)

{
  if (((uint)((long)param_1[0x11] < (long)param_2[0x11]) -
      (uint)((long)param_2[0x11] < (long)param_1[0x11])) +
      ((uint)((long)param_1[0x10] < (long)param_2[0x10]) -
      (uint)((long)param_2[0x10] < (long)param_1[0x10])) * 2 == 0) {
    strcmp((char *)*param_1,(char *)*param_2);
    return;
  }
  return;
}



void FUN_00109090(undefined8 *param_1,undefined8 *param_2)

{
  if (((uint)((long)param_1[0xf] < (long)param_2[0xf]) -
      (uint)((long)param_2[0xf] < (long)param_1[0xf])) +
      ((uint)((long)param_1[0xe] < (long)param_2[0xe]) -
      (uint)((long)param_2[0xe] < (long)param_1[0xe])) * 2 == 0) {
    strcmp((char *)*param_1,(char *)*param_2);
    return;
  }
  return;
}



void FUN_001090e0(undefined8 *param_1,undefined8 *param_2)

{
  if (((uint)((long)param_1[0xd] < (long)param_2[0xd]) -
      (uint)((long)param_2[0xd] < (long)param_1[0xd])) +
      ((uint)((long)param_1[0xc] < (long)param_2[0xc]) -
      (uint)((long)param_2[0xc] < (long)param_1[0xc])) * 2 == 0) {
    strcmp((char *)*param_1,(char *)*param_2);
    return;
  }
  return;
}



void FUN_00109130(undefined8 *param_1,undefined8 *param_2)

{
  if (((uint)((long)param_1[0xf] < (long)param_2[0xf]) -
      (uint)((long)param_2[0xf] < (long)param_1[0xf])) +
      ((uint)((long)param_1[0xe] < (long)param_2[0xe]) -
      (uint)((long)param_2[0xe] < (long)param_1[0xe])) * 2 == 0) {
    strcmp((char *)*param_1,(char *)*param_2);
    return;
  }
  return;
}



int FUN_00109180(undefined8 *param_1,undefined8 *param_2)

{
  long lVar1;
  char *__s1;
  char *__s2;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_2[0x19] == 0) {
    iVar2 = FUN_00107f50(*param_2,DAT_001282f0,*(undefined4 *)((long)param_2 + 0xc4));
    lVar1 = param_1[0x19];
  }
  else {
    lVar1 = param_1[0x19];
    iVar2 = (int)param_2[0x19];
  }
  iVar3 = (int)lVar1;
  if (lVar1 == 0) {
    iVar3 = FUN_00107f50(*param_1,DAT_001282f0,*(undefined4 *)((long)param_1 + 0xc4));
  }
  if (iVar2 - iVar3 != 0) {
    return iVar2 - iVar3;
  }
  piVar4 = __errno_location();
  __s1 = (char *)*param_2;
  __s2 = (char *)*param_1;
  *piVar4 = 0;
  iVar2 = strcoll(__s1,__s2);
  return iVar2;
}



int FUN_00109220(undefined8 *param_1,undefined8 *param_2)

{
  long lVar1;
  char *__s1;
  char *__s2;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_1[0x19] == 0) {
    iVar2 = FUN_00107f50(*param_1,DAT_001282f0,*(undefined4 *)((long)param_1 + 0xc4));
    lVar1 = param_2[0x19];
  }
  else {
    lVar1 = param_2[0x19];
    iVar2 = (int)param_1[0x19];
  }
  iVar3 = (int)lVar1;
  if (lVar1 == 0) {
    iVar3 = FUN_00107f50(*param_2,DAT_001282f0,*(undefined4 *)((long)param_2 + 0xc4));
  }
  if (iVar2 - iVar3 != 0) {
    return iVar2 - iVar3;
  }
  piVar4 = __errno_location();
  __s1 = (char *)*param_1;
  __s2 = (char *)*param_2;
  *piVar4 = 0;
  iVar2 = strcoll(__s1,__s2);
  return iVar2;
}



void FUN_001092c0(char *param_1,undefined8 param_2,undefined8 param_3)

{
  char *pcVar1;
  int iVar2;
  size_t sVar3;
  int iVar4;
  bool bVar5;
  
  if (param_1 != (char *)0x0) {
    iVar2 = FUN_00113da0(param_1,3);
    iVar4 = 0;
    if (-1 < iVar2) {
      iVar2 = (int)param_3 - iVar2;
      iVar4 = 0;
      if (-1 < iVar2) {
        iVar4 = iVar2;
      }
    }
    sVar3 = strlen(param_1);
    FUN_00107580(param_1,sVar3);
    do {
      DAT_00128218 = DAT_00128218 + 1;
      pcVar1 = stdout->_IO_write_ptr;
      if (pcVar1 < stdout->_IO_write_end) {
        stdout->_IO_write_ptr = pcVar1 + 1;
        *pcVar1 = ' ';
      }
      else {
        __overflow(stdout,0x20);
      }
      bVar5 = iVar4 != 0;
      iVar4 = iVar4 + -1;
    } while (bVar5);
    return;
  }
  iVar4 = __printf_chk(1,"%*ju ",param_3,param_2);
  DAT_00128218 = DAT_00128218 + iVar4;
  return;
}



void FUN_00109370(undefined8 *param_1,undefined8 *param_2)

{
  char *__s;
  char *__s_00;
  int iVar1;
  char *__s1;
  char *__s2;
  int *piVar2;
  
  __s = (char *)*param_2;
  __s1 = strrchr(__s,0x2e);
  __s_00 = (char *)*param_1;
  __s2 = strrchr(__s_00,0x2e);
  if (__s2 == (char *)0x0) {
    __s2 = "";
  }
  if (__s1 == (char *)0x0) {
    __s1 = "";
  }
  piVar2 = __errno_location();
  *piVar2 = 0;
  iVar1 = strcoll(__s1,__s2);
  if (iVar1 == 0) {
    strcoll(__s,__s_00);
    return;
  }
  return;
}



void FUN_00109400(undefined8 *param_1,undefined8 *param_2)

{
  char *__s;
  char *__s_00;
  int iVar1;
  char *__s1;
  char *__s2;
  int *piVar2;
  
  __s = (char *)*param_1;
  __s1 = strrchr(__s,0x2e);
  __s_00 = (char *)*param_2;
  __s2 = strrchr(__s_00,0x2e);
  if (__s2 == (char *)0x0) {
    __s2 = "";
  }
  if (__s1 == (char *)0x0) {
    __s1 = "";
  }
  piVar2 = __errno_location();
  *piVar2 = 0;
  iVar1 = strcoll(__s1,__s2);
  if (iVar1 == 0) {
    strcoll(__s,__s_00);
    return;
  }
  return;
}



int FUN_00109490(undefined8 *param_1,undefined8 *param_2)

{
  long lVar1;
  int iVar2;
  int iVar3;
  
  if (param_2[0x19] == 0) {
    iVar2 = FUN_00107f50(*param_2,DAT_001282f0,*(undefined4 *)((long)param_2 + 0xc4));
    lVar1 = param_1[0x19];
  }
  else {
    lVar1 = param_1[0x19];
    iVar2 = (int)param_2[0x19];
  }
  iVar3 = (int)lVar1;
  if (lVar1 == 0) {
    iVar3 = FUN_00107f50(*param_1,DAT_001282f0,*(undefined4 *)((long)param_1 + 0xc4));
  }
  if (iVar2 - iVar3 != 0) {
    return iVar2 - iVar3;
  }
  iVar2 = strcmp((char *)*param_2,(char *)*param_1);
  return iVar2;
}



void FUN_00109530(long param_1,undefined1 param_2)

{
  long *plVar1;
  int iVar2;
  char *pcVar3;
  long *plVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  char *pcVar7;
  void *__ptr;
  long *plVar8;
  long lVar9;
  long lVar10;
  
  if ((param_1 != 0) && (DAT_001283e8 != 0)) {
    puVar5 = (undefined8 *)FUN_00119d00(0x20);
    uVar6 = FUN_0011a180(param_1);
    *puVar5 = 0;
    puVar5[1] = uVar6;
    *(undefined1 *)(puVar5 + 2) = 0;
    puVar5[3] = DAT_001283a0;
    DAT_001283a0 = puVar5;
  }
  lVar10 = DAT_001283d0;
  if (0 < DAT_001283d0) {
    do {
      while( true ) {
        lVar10 = lVar10 + -1;
        puVar5 = (undefined8 *)DAT_001283c0[lVar10];
        if ((*(int *)(puVar5 + 0x15) == 3) || (*(int *)(puVar5 + 0x15) == 9)) break;
LAB_001095a0:
        if (lVar10 == 0) goto LAB_00109670;
      }
      pcVar3 = (char *)*puVar5;
      if (param_1 == 0) {
LAB_001096e0:
        FUN_001071c0(pcVar3,puVar5[1],param_2);
      }
      else {
        pcVar7 = (char *)thunk_FUN_0010f314(pcVar3);
        if (*pcVar7 == '.') {
          lVar9 = 1;
          if (pcVar7[1] == '.') {
            lVar9 = 2;
          }
          if ((pcVar7[lVar9] == '\0') || (pcVar7[lVar9] == '/')) goto LAB_001095a0;
        }
        if (*pcVar3 == '/') goto LAB_001096e0;
        __ptr = (void *)FUN_00110a70(param_1,pcVar3,0);
        FUN_001071c0(__ptr,puVar5[1],param_2);
        free(__ptr);
      }
      if (*(int *)(puVar5 + 0x15) != 9) goto LAB_001095a0;
      free((void *)*puVar5);
      free((void *)puVar5[1]);
      free((void *)puVar5[2]);
      if ((undefined *)puVar5[0x16] == &DAT_0012702a) goto LAB_001095a0;
      FUN_00110030();
    } while (lVar10 != 0);
LAB_00109670:
    plVar4 = DAT_001283c0;
    if (0 < DAT_001283d0) {
      plVar1 = DAT_001283c0 + DAT_001283d0;
      plVar8 = DAT_001283c0;
      do {
        iVar2 = *(int *)(*plVar8 + 0xa8);
        plVar4[lVar10] = *plVar8;
        plVar8 = plVar8 + 1;
        lVar10 = lVar10 + (ulong)(iVar2 != 9);
      } while (plVar1 != plVar8);
      DAT_001283d0 = lVar10;
      return;
    }
  }
  DAT_001283d0 = 0;
  return;
}



ulong FUN_00109730(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_001097a5;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_001097a5:
  uVar3 = FUN_00108a90();
  return uVar3;
}



int FUN_001097c0(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_0010983f;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_0010983f:
  iVar1 = ((uint)((long)param_1[0x11] < (long)param_2[0x11]) -
          (uint)((long)param_2[0x11] < (long)param_1[0x11])) +
          ((uint)((long)param_1[0x10] < (long)param_2[0x10]) -
          (uint)((long)param_2[0x10] < (long)param_1[0x10])) * 2;
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = strcmp((char *)*param_1,(char *)*param_2);
  return iVar1;
}



ulong FUN_001098a0(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_00109915;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_00109915:
  uVar3 = FUN_00108b10();
  return uVar3;
}



int FUN_00109930(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_001099af;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_001099af:
  iVar1 = ((uint)((long)param_2[0x11] < (long)param_1[0x11]) -
          (uint)((long)param_1[0x11] < (long)param_2[0x11])) +
          ((uint)((long)param_2[0x10] < (long)param_1[0x10]) -
          (uint)((long)param_1[0x10] < (long)param_2[0x10])) * 2;
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = strcmp((char *)*param_2,(char *)*param_1);
  return iVar1;
}



ulong FUN_00109a10(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_00109a85;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_00109a85:
  uVar3 = FUN_00108b90();
  return uVar3;
}



int FUN_00109aa0(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_00109b17;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_00109b17:
  iVar1 = ((uint)((long)param_1[0xf] < (long)param_2[0xf]) -
          (uint)((long)param_2[0xf] < (long)param_1[0xf])) +
          ((uint)((long)param_1[0xe] < (long)param_2[0xe]) -
          (uint)((long)param_2[0xe] < (long)param_1[0xe])) * 2;
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = strcmp((char *)*param_1,(char *)*param_2);
  return iVar1;
}



ulong FUN_00109b70(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_00109be5;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_00109be5:
  uVar3 = FUN_00108c00();
  return uVar3;
}



int FUN_00109c00(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_00109c77;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_00109c77:
  iVar1 = ((uint)((long)param_2[0xf] < (long)param_1[0xf]) -
          (uint)((long)param_1[0xf] < (long)param_2[0xf])) +
          ((uint)((long)param_2[0xe] < (long)param_1[0xe]) -
          (uint)((long)param_1[0xe] < (long)param_2[0xe])) * 2;
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = strcmp((char *)*param_2,(char *)*param_1);
  return iVar1;
}



ulong FUN_00109cd0(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_00109d45;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_00109d45:
  uVar3 = FUN_00108c70();
  return uVar3;
}



int FUN_00109d60(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_00109dd7;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_00109dd7:
  iVar1 = ((uint)((long)param_1[0xd] < (long)param_2[0xd]) -
          (uint)((long)param_2[0xd] < (long)param_1[0xd])) +
          ((uint)((long)param_1[0xc] < (long)param_2[0xc]) -
          (uint)((long)param_2[0xc] < (long)param_1[0xc])) * 2;
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = strcmp((char *)*param_1,(char *)*param_2);
  return iVar1;
}



ulong FUN_00109e30(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_00109ea5;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_00109ea5:
  uVar3 = FUN_00108ce0();
  return uVar3;
}



int FUN_00109ec0(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_00109f37;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_00109f37:
  iVar1 = ((uint)((long)param_2[0xd] < (long)param_1[0xd]) -
          (uint)((long)param_1[0xd] < (long)param_2[0xd])) +
          ((uint)((long)param_2[0xc] < (long)param_1[0xc]) -
          (uint)((long)param_1[0xc] < (long)param_2[0xc])) * 2;
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = strcmp((char *)*param_2,(char *)*param_1);
  return iVar1;
}



ulong FUN_00109f90(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_0010a005;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_0010a005:
  uVar3 = FUN_00108d50();
  return uVar3;
}



int FUN_0010a020(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_0010a097;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_0010a097:
  iVar1 = ((uint)((long)param_1[0xf] < (long)param_2[0xf]) -
          (uint)((long)param_2[0xf] < (long)param_1[0xf])) +
          ((uint)((long)param_1[0xe] < (long)param_2[0xe]) -
          (uint)((long)param_2[0xe] < (long)param_1[0xe])) * 2;
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = strcmp((char *)*param_1,(char *)*param_2);
  return iVar1;
}



ulong FUN_0010a0f0(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_0010a165;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_0010a165:
  uVar3 = FUN_00108dc0();
  return uVar3;
}



int FUN_0010a180(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_0010a1f7;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_0010a1f7:
  iVar1 = ((uint)((long)param_2[0xf] < (long)param_1[0xf]) -
          (uint)((long)param_1[0xf] < (long)param_2[0xf])) +
          ((uint)((long)param_2[0xe] < (long)param_1[0xe]) -
          (uint)((long)param_1[0xe] < (long)param_2[0xe])) * 2;
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = strcmp((char *)*param_2,(char *)*param_1);
  return iVar1;
}



int FUN_0010a250(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int iVar1;
  int *piVar2;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_0010a2c5;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_0010a2c5:
  iVar1 = (uint)((long)param_1[9] < (long)param_2[9]) - (uint)((long)param_2[9] < (long)param_1[9]);
  if (iVar1 != 0) {
    return iVar1;
  }
  __s1 = (char *)*param_1;
  __s2 = (char *)*param_2;
  piVar2 = __errno_location();
  *piVar2 = 0;
  iVar1 = strcoll(__s1,__s2);
  return iVar1;
}



int FUN_0010a310(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_0010a385;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_0010a385:
  iVar1 = (uint)((long)param_1[9] < (long)param_2[9]) - (uint)((long)param_2[9] < (long)param_1[9]);
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = strcmp((char *)*param_1,(char *)*param_2);
  return iVar1;
}



int FUN_0010a3c0(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int iVar1;
  int *piVar2;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_0010a435;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_0010a435:
  iVar1 = (uint)((long)param_2[9] < (long)param_1[9]) - (uint)((long)param_1[9] < (long)param_2[9]);
  if (iVar1 != 0) {
    return iVar1;
  }
  __s1 = (char *)*param_2;
  __s2 = (char *)*param_1;
  piVar2 = __errno_location();
  *piVar2 = 0;
  iVar1 = strcoll(__s1,__s2);
  return iVar1;
}



int FUN_0010a480(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_0010a4f5;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_0010a4f5:
  iVar1 = (uint)((long)param_2[9] < (long)param_1[9]) - (uint)((long)param_1[9] < (long)param_2[9]);
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = strcmp((char *)*param_2,(char *)*param_1);
  return iVar1;
}



int FUN_0010a530(undefined8 *param_1,undefined8 *param_2)

{
  char *__s2;
  char *__s1;
  int iVar1;
  int *piVar2;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 3 || iVar1 == 9) goto LAB_0010a5a5;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 3 || iVar1 == 9) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_0010a5a5:
  __s2 = (char *)*param_2;
  __s1 = (char *)*param_1;
  piVar2 = __errno_location();
  *piVar2 = 0;
  iVar1 = strcoll(__s1,__s2);
  return iVar1;
}



int FUN_0010a5e0(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_0010a655;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_0010a655:
  iVar1 = strcmp((char *)*param_1,(char *)*param_2);
  return iVar1;
}



int FUN_0010a670(undefined8 *param_1,undefined8 *param_2)

{
  char *__s2;
  char *__s1;
  int iVar1;
  int *piVar2;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 3 || iVar1 == 9) goto LAB_0010a6e5;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 3 || iVar1 == 9) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_0010a6e5:
  __s2 = (char *)*param_1;
  __s1 = (char *)*param_2;
  piVar2 = __errno_location();
  *piVar2 = 0;
  iVar1 = strcoll(__s1,__s2);
  return iVar1;
}



int FUN_0010a720(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_0010a795;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_0010a795:
  iVar1 = strcmp((char *)*param_2,(char *)*param_1);
  return iVar1;
}



ulong FUN_0010a7b0(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_0010a825;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_0010a825:
  uVar3 = FUN_00109400();
  return uVar3;
}



ulong FUN_0010a840(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 9 || iVar2 == 3) goto LAB_0010a8b5;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 9 || iVar2 == 3) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_0010a8b5:
  uVar3 = FUN_00107410(param_1,param_2,strcmp);
  return uVar3;
}



ulong FUN_0010a8d0(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_0010a945;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_0010a945:
  uVar3 = FUN_00109370();
  return uVar3;
}



ulong FUN_0010a960(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 9 || iVar2 == 3) goto LAB_0010a9d5;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 9 || iVar2 == 3) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_0010a9d5:
  uVar3 = FUN_00107410(param_2,param_1,strcmp);
  return uVar3;
}



ulong FUN_0010a9f0(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_0010aa65;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_0010aa65:
  uVar3 = FUN_00109220();
  return uVar3;
}



ulong FUN_0010aa80(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_0010aaf5;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_0010aaf5:
  uVar3 = FUN_001089f0();
  return uVar3;
}



ulong FUN_0010ab10(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_0010ab85;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_0010ab85:
  uVar3 = FUN_00109180();
  return uVar3;
}



ulong FUN_0010aba0(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  ulong uVar3;
  
  iVar2 = *(int *)(param_1 + 0xa8);
  if (((*(int *)(param_2 + 0xa8) == 3) || (*(int *)(param_2 + 0xa8) == 9)) ||
     ((*(uint *)(param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar2 == 3 || iVar2 == 9) goto LAB_0010ac15;
    iVar2 = 1;
  }
  else {
    if (iVar2 == 3 || iVar2 == 9) {
      return 0xffffffff;
    }
    iVar2 = 0;
  }
  uVar1 = iVar2 - (uint)((*(uint *)(param_1 + 0xac) & 0xf000) == 0x4000);
  if (uVar1 != 0) {
    return (ulong)uVar1;
  }
LAB_0010ac15:
  uVar3 = FUN_00109490();
  return uVar3;
}



int FUN_0010ac30(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_0010acb0;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_0010acb0:
  __s1 = (char *)*param_1;
  __s2 = (char *)*param_2;
  iVar1 = FUN_00111250(__s1,__s2);
  if (iVar1 == 0) {
    iVar1 = strcmp(__s1,__s2);
    return iVar1;
  }
  return iVar1;
}



int FUN_0010ad00(undefined8 *param_1,undefined8 *param_2)

{
  char *__s1;
  char *__s2;
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x15);
  if (((*(int *)(param_2 + 0x15) == 3) || (*(int *)(param_2 + 0x15) == 9)) ||
     ((*(uint *)((long)param_2 + 0xac) & 0xf000) == 0x4000)) {
    if (iVar1 == 9 || iVar1 == 3) goto LAB_0010ad80;
    iVar1 = 1;
  }
  else {
    if (iVar1 == 9 || iVar1 == 3) {
      return -1;
    }
    iVar1 = 0;
  }
  iVar1 = iVar1 - (uint)((*(uint *)((long)param_1 + 0xac) & 0xf000) == 0x4000);
  if (iVar1 != 0) {
    return iVar1;
  }
LAB_0010ad80:
  __s1 = (char *)*param_2;
  __s2 = (char *)*param_1;
  iVar1 = FUN_00111250(__s1,__s2);
  if (iVar1 == 0) {
    iVar1 = strcmp(__s1,__s2);
    return iVar1;
  }
  return iVar1;
}



long FUN_0010add0(byte *param_1,undefined8 param_2,undefined4 param_3,long param_4,char param_5,
                 long param_6,long param_7)

{
  byte bVar1;
  byte *pbVar2;
  byte *__ptr;
  size_t sVar3;
  void *__ptr_00;
  char *pcVar4;
  char *pcVar5;
  long *plVar6;
  char cVar7;
  long in_FS_OFFSET;
  size_t local_2078;
  byte *local_2070;
  byte local_2051;
  byte *local_2050;
  byte local_2048 [8200];
  long local_40;
  
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  local_2050 = local_2048;
  sVar3 = FUN_00107a30(&local_2050,param_1,param_2,param_3,0,&local_2051);
  if ((local_2051 != 0) && (param_5 != '\0')) {
    DAT_00128218 = DAT_00128218 + 1;
    pcVar4 = stdout->_IO_write_ptr;
    if (pcVar4 < stdout->_IO_write_end) {
      stdout->_IO_write_ptr = pcVar4 + 1;
      *pcVar4 = ' ';
    }
    else {
      __overflow(stdout,0x20);
    }
  }
  if (param_4 != 0) {
    if ((DAT_001270a0 != 0) &&
       (((2 < DAT_001270a0 || (DAT_001270a8[DAT_001270a0 - 1] != '0')) || (*DAT_001270a8 != '0'))))
    {
      FUN_00107990(&DAT_00127060);
      FUN_00107990(&DAT_00127070);
    }
    FUN_00107990(&DAT_00127060);
    FUN_00107990(param_4);
    FUN_00107990(&DAT_00127070);
  }
  __ptr = local_2050;
  cVar7 = DAT_001283c8;
  local_2070 = local_2050;
  local_2078 = sVar3;
  if (param_7 == 0) {
    cVar7 = '\0';
  }
  else {
    if (DAT_001283c8 == '\0') {
    }
    else if ((DAT_001283c9 == '\x01') && (local_2051 == 0)) {
      bVar1 = *local_2050;
      pbVar2 = (byte *)stdout->_IO_write_ptr;
      if (pbVar2 < stdout->_IO_write_end) {
        stdout->_IO_write_ptr = (char *)(pbVar2 + 1);
        *pbVar2 = bVar1;
      }
      else {
        __overflow(stdout,(uint)bVar1);
      }
      local_2078 = sVar3 - 2;
      local_2070 = __ptr + 1;
    }
    else {
      cVar7 = '\0';
    }
    __ptr_00 = (void *)FUN_001074c0(DAT_001283a8,0);
    pcVar4 = (char *)FUN_001074c0(param_7,1);
    pcVar5 = "/";
    if (*pcVar4 == '/') {
      pcVar5 = "";
    }
    __printf_chk(1,&DAT_0011cf32,__ptr_00,pcVar5);
    free(__ptr_00);
    free(pcVar4);
  }
  if (param_6 == 0) {
    fwrite_unlocked(local_2070,1,local_2078,stdout);
    DAT_00128218 = DAT_00128218 + sVar3;
  }
  else {
    if (DAT_00128338 != '\0') {
      plVar6 = *(long **)(param_6 + 0x18);
      if ((ulong)(*(long *)(param_6 + 0x20) - (long)plVar6) < 8) {
        FUN_00116220(param_6,8);
        plVar6 = *(long **)(param_6 + 0x18);
      }
      *plVar6 = DAT_00128218;
      *(long *)(param_6 + 0x18) = *(long *)(param_6 + 0x18) + 8;
    }
    fwrite_unlocked(local_2070,1,local_2078,stdout);
    DAT_00128218 = DAT_00128218 + sVar3;
    if (DAT_00128338 != '\0') {
      plVar6 = *(long **)(param_6 + 0x18);
      if ((ulong)(*(long *)(param_6 + 0x20) - (long)plVar6) < 8) {
        FUN_00116220(param_6,8);
        plVar6 = *(long **)(param_6 + 0x18);
      }
      *plVar6 = DAT_00128218;
      *(long *)(param_6 + 0x18) = *(long *)(param_6 + 0x18) + 8;
    }
  }
  if (param_7 != 0) {
    fwrite_unlocked(&DAT_0011cf46,1,6,stdout);
    if (cVar7 != '\0') {
      bVar1 = __ptr[sVar3 - 1];
      pbVar2 = (byte *)stdout->_IO_write_ptr;
      if (pbVar2 < stdout->_IO_write_end) {
        stdout->_IO_write_ptr = (char *)(pbVar2 + 1);
        *pbVar2 = bVar1;
      }
      else {
        __overflow(stdout,(uint)bVar1);
      }
    }
  }
  if ((__ptr != local_2048) && (param_1 != __ptr)) {
    free(__ptr);
  }
  if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
    return local_2051 + sVar3;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



long FUN_0010b1e0(undefined8 *param_1,byte param_2,undefined8 param_3,ulong param_4)

{
  ulong uVar1;
  char cVar2;
  char cVar3;
  size_t __n;
  uint uVar4;
  int iVar5;
  long lVar6;
  size_t sVar7;
  size_t *psVar8;
  undefined4 uVar9;
  uint uVar10;
  uint uVar11;
  char *__s;
  
  if (param_2 == 0) {
    __s = (char *)*param_1;
    if (DAT_00128332 != '\0') {
      uVar4 = (uint)*(byte *)((long)param_1 + 0xb9);
      if ((DAT_001283b0 == '\0') || (*(byte *)((long)param_1 + 0xb9) == 0)) {
        uVar10 = *(uint *)(param_1 + 6);
      }
      else {
        uVar10 = *(uint *)((long)param_1 + 0xac);
      }
LAB_0010b27f:
      if (*(char *)(param_1 + 0x17) == '\0') goto LAB_0010b28d;
LAB_0010b390:
      uVar11 = uVar10 & 0xf000;
      if (uVar11 == 0x8000) {
        if ((((uVar10 & 0x800) == 0) || (DAT_00127160 == 0)) ||
           ((DAT_00127160 < 3 &&
            ((PTR_DAT_00127168[DAT_00127160 - 1] == '0' && (*PTR_DAT_00127168 == '0')))))) {
          if (((uVar10 & 0x400) == 0) ||
             ((DAT_00127170 == 0 ||
              (((DAT_00127170 < 3 && (PTR_DAT_00127178[DAT_00127170 - 1] == '0')) &&
               (*PTR_DAT_00127178 == '0')))))) {
            if (*(char *)(param_1 + 0x18) == '\0') {
              if ((((uVar10 & 0x49) == 0) || (DAT_00127140 == 0)) ||
                 ((DAT_00127140 < 3 &&
                  ((PTR_DAT_00127148[DAT_00127140 - 1] == '0' && (*PTR_DAT_00127148 == '0')))))) {
                if (((ulong)param_1[5] < 2) ||
                   ((DAT_001271c0 == 0 ||
                    (((DAT_001271c0 < 3 && (DAT_001271c8[DAT_001271c0 - 1] == '0')) &&
                     (*DAT_001271c8 == '0')))))) goto LAB_0010b550;
                lVar6 = 0x160;
              }
              else {
                lVar6 = 0xe0;
              }
            }
            else {
              lVar6 = 0x150;
            }
          }
          else {
            lVar6 = 0x110;
          }
        }
        else {
          lVar6 = 0x100;
        }
      }
      else if (uVar11 == 0x4000) {
        if ((~uVar10 & 0x202) == 0) {
          if (DAT_001271a0 == 0) {
LAB_0010b7b6:
            if (DAT_00127190 != 0) goto LAB_0010b7c6;
LAB_0010b706:
            lVar6 = 0x60;
            if (((DAT_00127180 != 0) && (lVar6 = 0x120, DAT_00127180 < 3)) &&
               ((PTR_DAT_00127188[DAT_00127180 - 1] != '0' ||
                (lVar6 = 0x60, *PTR_DAT_00127188 != '0')))) {
              lVar6 = 0x120;
            }
          }
          else {
            lVar6 = 0x140;
            if (DAT_001271a0 < 3) {
              if ((PTR_DAT_001271a8[DAT_001271a0 - 1] == '0') && (*PTR_DAT_001271a8 == '0'))
              goto LAB_0010b7b6;
              lVar6 = 0x140;
            }
          }
        }
        else if (((uVar10 & 2) == 0) || (DAT_00127190 == 0)) {
LAB_0010b6f8:
          lVar6 = 0x60;
          if ((uVar10 & 0x200) != 0) goto LAB_0010b706;
        }
        else {
LAB_0010b7c6:
          lVar6 = 0x130;
          if (DAT_00127190 < 3) {
            if ((PTR_DAT_00127198[DAT_00127190 - 1] == '0') && (*PTR_DAT_00127198 == '0'))
            goto LAB_0010b6f8;
            lVar6 = 0x130;
          }
        }
      }
      else if (uVar11 == 0xa000) {
        lVar6 = 0x70;
        if (uVar4 == 0) goto LAB_0010b2b8;
      }
      else {
        lVar6 = 0x80;
        if ((((uVar11 != 0x1000) && (lVar6 = 0x90, uVar11 != 0xc000)) &&
            (lVar6 = 0xa0, uVar11 != 0x6000)) && (lVar6 = 0xd0, uVar11 == 0x2000)) {
          lVar6 = 0xb0;
        }
      }
LAB_0010b410:
      psVar8 = (size_t *)((long)&DAT_00127060 + lVar6);
LAB_0010b41a:
      uVar9 = *(undefined4 *)((long)param_1 + 0xc4);
      if (psVar8[1] == 0) {
        if (DAT_001270a0 == 0) goto LAB_0010b222;
        if (DAT_001270a0 < 3) {
          cVar2 = DAT_001270a8[DAT_001270a0 - 1];
          cVar3 = *DAT_001270a8;
          lVar6 = FUN_0010add0(__s,DAT_001282f0,uVar9,0,param_2 ^ 1,param_3,param_1[2]);
          FUN_00108670();
          if (cVar2 == '0' && cVar3 == '0') {
            return lVar6;
          }
          goto LAB_0010b45c;
        }
        psVar8 = (size_t *)0x0;
      }
      lVar6 = FUN_0010add0(__s,DAT_001282f0,uVar9,psVar8,param_2 ^ 1,param_3,param_1[2]);
      FUN_00108670();
LAB_0010b45c:
      if (DAT_00127088 == 0) {
        FUN_00107990(&DAT_00127060);
        FUN_00107990(&DAT_00127090);
        FUN_00107990(&DAT_00127070);
      }
      else {
        FUN_00107990(&DAT_00127080);
      }
      if (DAT_001282d0 == 0) {
        return lVar6;
      }
      uVar1 = lVar6 + -1 + param_4;
      if (param_4 / DAT_001282d0 == uVar1 / DAT_001282d0) {
        return lVar6;
      }
      FUN_00107990(&DAT_001271d0,param_4 / DAT_001282d0,uVar1 % DAT_001282d0);
      return lVar6;
    }
  }
  else {
    __s = (char *)param_1[1];
    if (DAT_00128332 != '\0') {
      uVar10 = *(uint *)((long)param_1 + 0xac);
      if (*(char *)((long)param_1 + 0xb9) == '\0') {
        if ((DAT_00127120 == 0) ||
           (((DAT_00127120 < 3 && (DAT_00127128[DAT_00127120 - 1] == '0')) && (*DAT_00127128 == '0')
            ))) {
          uVar4 = 0xffffffff;
          goto LAB_0010b27f;
        }
        lVar6 = 0xc0;
        goto LAB_0010b410;
      }
      uVar4 = 0;
      if (*(char *)(param_1 + 0x17) != '\0') goto LAB_0010b390;
LAB_0010b28d:
      uVar10 = *(uint *)(&DAT_0011b640 + (ulong)*(uint *)(param_1 + 0x15) * 4);
      if (uVar10 == 5) {
LAB_0010b550:
        sVar7 = strlen(__s);
        for (psVar8 = DAT_00128328; psVar8 != (size_t *)0x0; psVar8 = (size_t *)psVar8[5]) {
          __n = *psVar8;
          if (__n <= sVar7) {
            if ((char)psVar8[4] == '\0') {
              iVar5 = FUN_0010f3c0();
            }
            else {
              iVar5 = strncmp(__s + (sVar7 - __n),(char *)psVar8[1],__n);
            }
            if (iVar5 == 0) {
              psVar8 = psVar8 + 2;
              goto LAB_0010b41a;
            }
          }
        }
        lVar6 = 0x50;
      }
      else if ((uVar10 == 7) && (uVar4 == 0)) {
LAB_0010b2b8:
        lVar6 = 0xd0;
        if (((DAT_001283b0 == '\0') && (lVar6 = 0x70, DAT_00127130 != 0)) &&
           ((lVar6 = 0xd0, DAT_00127130 < 3 &&
            ((DAT_00127138[DAT_00127130 - 1] != '0' || (lVar6 = 0x70, *DAT_00127138 != '0')))))) {
          lVar6 = 0xd0;
        }
      }
      else {
        lVar6 = (ulong)uVar10 << 4;
      }
      goto LAB_0010b410;
    }
  }
  uVar9 = *(undefined4 *)((long)param_1 + 0xc4);
LAB_0010b222:
  lVar6 = FUN_0010add0(__s,DAT_001282f0,uVar9,0,param_2 ^ 1,param_3,param_1[2]);
  FUN_00108670();
  return lVar6;
}



void FUN_0010b820(long param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  long lVar7;
  long lVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined *puVar11;
  char *pcVar12;
  char *pcVar13;
  undefined1 *puVar14;
  int iVar15;
  char *pcVar16;
  long in_FS_OFFSET;
  bool bVar17;
  undefined8 local_1340;
  ulong local_1338;
  ulong uStack_1330;
  undefined1 local_1328 [16];
  int local_1318;
  undefined1 local_12e8 [16];
  int local_12d8;
  char local_12a4;
  undefined8 local_12a3;
  undefined2 local_129b;
  undefined1 local_1299;
  undefined1 local_1298 [32];
  undefined1 local_1278 [1008];
  char local_e88 [3656];
  long local_40;
  
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  if (*(char *)(param_1 + 0xb8) == '\0') {
    local_1299 = 0;
    local_129b = 0x3f3f;
    local_12a4 = "?pcdb-lswd"[*(uint *)(param_1 + 0xa8)];
    local_12a3 = 0x3f3f3f3f3f3f3f3f;
    if (DAT_00128388 == '\0') goto LAB_0010b87f;
LAB_0010bbf6:
    iVar4 = *(int *)(param_1 + 0xbc);
    if (iVar4 == 2) {
      local_129b = CONCAT11(0x2e,(undefined1)local_129b);
    }
    else if (iVar4 == 3) {
      local_129b = CONCAT11(0x2b,(undefined1)local_129b);
    }
    else if (iVar4 == 1) {
      local_129b = CONCAT11(0x3f,(undefined1)local_129b);
    }
  }
  else {
    FUN_00110a60(param_1 + 0x18,&local_12a4);
    if (DAT_00128388 != '\0') goto LAB_0010bbf6;
LAB_0010b87f:
    local_129b = local_129b & 0xff;
  }
  if (DAT_00128358 == 2) {
    local_1338 = *(ulong *)(param_1 + 0x60);
    uStack_1330 = *(ulong *)(param_1 + 0x68);
LAB_0010b8a9:
    bVar17 = true;
  }
  else {
    if (DAT_00128358 < 3) {
      if (DAT_00128358 == 0) {
        local_1338 = *(ulong *)(param_1 + 0x70);
        uStack_1330 = *(ulong *)(param_1 + 0x78);
      }
      else {
        local_1338 = *(ulong *)(param_1 + 0x80);
        uStack_1330 = *(ulong *)(param_1 + 0x88);
      }
      goto LAB_0010b8a9;
    }
    local_1338 = *(ulong *)(param_1 + 0x70);
    uStack_1330 = *(ulong *)(param_1 + 0x78);
    bVar17 = (local_1338 & uStack_1330) != 0xffffffffffffffff;
  }
  if (DAT_0012831c == '\0') {
    pcVar12 = local_e88;
  }
  else {
    puVar14 = &DAT_0011cf4d;
    if ((*(char *)(param_1 + 0xb8) != '\0') && (*(long *)(param_1 + 0x20) != 0)) {
      puVar14 = (undefined1 *)FUN_00113ac0(*(long *)(param_1 + 0x20),local_1278);
    }
    iVar4 = __sprintf_chk(local_e88,1,0xe3b,&DAT_0011cf5f,DAT_00128384,puVar14);
    pcVar12 = local_e88 + iVar4;
  }
  if (DAT_0012834c != '\0') {
    pcVar16 = "?";
    if (*(char *)(param_1 + 0xb8) != '\0') {
      pcVar16 = (char *)FUN_00112780(*(undefined8 *)(param_1 + 0x58),local_1278,DAT_00128348,0x200,
                                     DAT_00128340);
    }
    iVar4 = FUN_00113da0(pcVar16,3);
    if ((-1 < iVar4) && (iVar4 = DAT_00128380 - iVar4, 0 < iVar4)) {
      memset(pcVar12,0x20,(long)iVar4);
      pcVar12 = pcVar12 + (long)(iVar4 + -1) + 1;
    }
    do {
      pcVar13 = pcVar12;
      cVar3 = *pcVar16;
      pcVar16 = pcVar16 + 1;
      pcVar12 = pcVar13 + 1;
      *pcVar13 = cVar3;
    } while (cVar3 != '\0');
    *pcVar13 = ' ';
  }
  puVar14 = &DAT_0011cf4d;
  if (*(char *)(param_1 + 0xb8) != '\0') {
    puVar14 = (undefined1 *)FUN_00113ac0(*(undefined8 *)(param_1 + 0x28),local_1278);
  }
  iVar4 = __sprintf_chk(pcVar12,1,0xffffffffffffffff,"%s %*s ",&local_12a4,DAT_0012837c,puVar14);
  if (DAT_00128338 != '\0') {
    FUN_00107580(&DAT_0011cf57,2);
  }
  if ((((DAT_00127029 != '\0') || (DAT_00127028 != '\0')) || (DAT_0012834e != '\0')) ||
     (pcVar16 = pcVar12 + iVar4, DAT_00128389 != '\0')) {
    FUN_00107580(local_e88,(long)(pcVar12 + iVar4) - (long)local_e88);
    uVar1 = DAT_00128374;
    if (DAT_00127029 != '\0') {
      puVar14 = &DAT_0011cf4d;
      uVar2 = *(undefined4 *)(param_1 + 0x34);
      if ((*(char *)(param_1 + 0xb8) != '\0') && (puVar14 = (undefined1 *)0x0, DAT_0012834d == '\0')
         ) {
        puVar14 = (undefined1 *)FUN_00113660(uVar2);
      }
      FUN_001092c0(puVar14,uVar2,uVar1);
    }
    uVar2 = DAT_00128370;
    uVar1 = DAT_0012836c;
    if (DAT_00127028 != '\0') {
      puVar14 = &DAT_0011cf4d;
      uVar1 = *(undefined4 *)(param_1 + 0x38);
      if ((*(char *)(param_1 + 0xb8) != '\0') && (puVar14 = (undefined1 *)0x0, DAT_0012834d == '\0')
         ) {
        puVar14 = (undefined1 *)FUN_00113810(uVar1);
      }
      FUN_001092c0(puVar14,uVar1,uVar2);
      uVar1 = DAT_0012836c;
    }
    DAT_0012836c = uVar1;
    if (DAT_0012834e != '\0') {
      puVar14 = &DAT_0011cf4d;
      uVar2 = *(undefined4 *)(param_1 + 0x34);
      if ((*(char *)(param_1 + 0xb8) != '\0') && (puVar14 = (undefined1 *)0x0, DAT_0012834d == '\0')
         ) {
        puVar14 = (undefined1 *)FUN_00113660(uVar2);
      }
      FUN_001092c0(puVar14,uVar2,uVar1);
    }
    pcVar16 = local_e88;
    if (DAT_00128389 != '\0') {
      FUN_001092c0(*(undefined8 *)(param_1 + 0xb0),0,DAT_00128378);
    }
  }
  if (*(char *)(param_1 + 0xb8) == '\0') {
    pcVar12 = "?";
LAB_0010ba8b:
    iVar4 = FUN_00113da0(pcVar12,3);
    if ((-1 < iVar4) && (iVar4 = DAT_00128360 - iVar4, 0 < iVar4)) {
      memset(pcVar16,0x20,(long)iVar4);
      pcVar16 = pcVar16 + (long)(iVar4 + -1) + 1;
    }
    do {
      pcVar13 = pcVar16;
      cVar3 = *pcVar12;
      pcVar12 = pcVar12 + 1;
      pcVar16 = pcVar13 + 1;
      *pcVar13 = cVar3;
    } while (cVar3 != '\0');
    *pcVar13 = ' ';
  }
  else {
    if ((*(uint *)(param_1 + 0x30) & 0xb000) != 0x2000) {
      pcVar12 = (char *)FUN_00112780(*(undefined8 *)(param_1 + 0x48),local_1278,DAT_0012833c,1,
                                     DAT_00127020);
      goto LAB_0010ba8b;
    }
    iVar15 = DAT_00128360 - (DAT_00128368 + 2 + DAT_00128364);
    uVar9 = FUN_00113ac0((uint)((*(ulong *)(param_1 + 0x40) >> 0x14) << 8) |
                         (uint)*(ulong *)(param_1 + 0x40) & 0xff,local_1278);
    iVar4 = DAT_00128364;
    uVar10 = FUN_00113ac0((uint)((ulong)*(undefined8 *)(param_1 + 0x40) >> 0x20) & 0xfffff000 |
                          (uint)((ulong)*(undefined8 *)(param_1 + 0x40) >> 8) & 0xfff,local_1298);
    iVar5 = 0;
    if (-1 < iVar15) {
      iVar5 = iVar15;
    }
    iVar4 = __sprintf_chk(pcVar16,1,0xffffffffffffffff,&DAT_0011cf5a,iVar5 + DAT_00128368,uVar10,
                          iVar4,uVar9);
    pcVar16 = pcVar16 + iVar4;
  }
  *pcVar16 = '\x01';
  if ((*(char *)(param_1 + 0xb8) == '\0') || (!bVar17)) {
LAB_0010baf5:
    puVar14 = &DAT_0011cf4d;
LAB_0010bafc:
    if (DAT_00127014 < 0) {
      local_1340 = 0;
      lVar7 = FUN_001193b0(DAT_001282c8,&local_1340,local_12e8);
      if (lVar7 != 0) {
        puVar11 = PTR_DAT_00127040;
        if (DAT_001273e8 != '\0') {
          puVar11 = &DAT_00127400 + (long)local_12d8 * 0x80;
        }
        lVar7 = FUN_001160b0(local_1278,0x3e9,puVar11,local_12e8,DAT_001282c8,0);
        if (lVar7 != 0) {
          DAT_00127014 = FUN_00113c00(local_1278,lVar7,3);
        }
      }
      if (DAT_00127014 < 0) {
        DAT_00127014 = 0;
      }
    }
    iVar4 = __sprintf_chk(pcVar16,1,0xffffffffffffffff,&DAT_0011cf5f,DAT_00127014,puVar14);
    pcVar16 = pcVar16 + iVar4;
  }
  else {
    lVar7 = FUN_001193b0(DAT_001282c8,&local_1338,local_1328);
    if (lVar7 == 0) {
LAB_0010c1b0:
      if (*pcVar16 != '\0') {
        if (*(char *)(param_1 + 0xb8) == '\0') goto LAB_0010baf5;
        puVar14 = (undefined1 *)FUN_001139c0(local_1338,local_1298);
        goto LAB_0010bafc;
      }
    }
    else {
      bVar17 = (long)uStack_1330 < DAT_00128398;
      uVar6 = (uint)(DAT_00128398 < (long)uStack_1330);
      iVar4 = (uint)bVar17 - (uint)(DAT_00128398 < (long)uStack_1330);
      if ((int)(iVar4 + ((uint)((long)local_1338 < DAT_00128390) -
                        (uint)(DAT_00128390 < (long)local_1338)) * 2) < 0) {
        FUN_00111280(&DAT_00128390);
        bVar17 = (long)uStack_1330 < DAT_00128398;
        uVar6 = (uint)(DAT_00128398 < (long)uStack_1330);
        iVar4 = bVar17 - uVar6;
      }
      uVar6 = ((uVar6 - bVar17) +
               ((uint)(DAT_00128390 < (long)local_1338) - (uint)((long)local_1338 < DAT_00128390)) *
               2 & iVar4 + ((uint)((long)local_1338 < DAT_00128390 + -0xf0c2ac) -
                           (uint)(DAT_00128390 + -0xf0c2ac < (long)local_1338)) * 2) >> 0x1f;
      if (DAT_001273e8 == '\0') {
        puVar11 = (&PTR_DAT_00127040)[uVar6];
      }
      else {
        puVar11 = &DAT_00127400 +
                  ((ulong)((uint)((long)((ulong)uVar6 << 0x3f) >> 0x3f) & 0xc) + (long)local_1318) *
                  0x80;
      }
      lVar7 = FUN_001160b0(pcVar16,0x3e9,puVar11,local_1328,DAT_001282c8);
      if (lVar7 == 0) goto LAB_0010c1b0;
      pcVar16 = pcVar16 + lVar7;
    }
    *pcVar16 = ' ';
    pcVar16 = pcVar16 + 1;
  }
  lVar7 = (long)pcVar16 - (long)local_e88;
  FUN_00107580(local_e88,lVar7);
  lVar8 = FUN_0010b1e0(param_1,0,&DAT_001281c0,lVar7);
  if (*(int *)(param_1 + 0xa8) == 6) {
    if (*(long *)(param_1 + 8) == 0) goto LAB_0010bb76;
    FUN_00107580(&DAT_0011cf64,4);
    FUN_0010b1e0(param_1,1,0,lVar7 + 4 + lVar8);
    if (DAT_00128334 == 0) goto LAB_0010bb76;
    cVar3 = FUN_00106bc0(1,*(undefined4 *)(param_1 + 0xac),0);
  }
  else {
    if (DAT_00128334 == 0) goto LAB_0010bb76;
    cVar3 = FUN_00106bc0(*(undefined1 *)(param_1 + 0xb8),*(undefined4 *)(param_1 + 0x30));
  }
  if (cVar3 != '\0') {
    DAT_00128218 = DAT_00128218 + 1;
    pcVar12 = stdout->_IO_write_ptr;
    if (pcVar12 < stdout->_IO_write_end) {
      stdout->_IO_write_ptr = pcVar12 + 1;
      *pcVar12 = cVar3;
    }
    else {
      __overflow(stdout,(int)cVar3);
    }
  }
LAB_0010bb76:
  if (local_40 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return;
}



void FUN_0010c260(long param_1,undefined8 param_2,char *param_3)

{
  char *pcVar1;
  char cVar2;
  undefined1 *puVar3;
  undefined4 uVar4;
  char *extraout_RDX;
  long in_FS_OFFSET;
  undefined1 auStack_2b8 [664];
  long local_20;
  
  local_20 = *(long *)(in_FS_OFFSET + 0x28);
  if (((DAT_00128332 != '\0') && (DAT_001270a0 != 0)) &&
     ((2 < DAT_001270a0 ||
      ((DAT_001270a8[DAT_001270a0 - 1] != '0' || (param_3 = DAT_001270a8, *DAT_001270a8 != '0'))))))
  {
    FUN_00107990(&DAT_00127060);
    FUN_00107990(&DAT_001270a0);
    FUN_00107990(&DAT_00127070);
    param_3 = extraout_RDX;
  }
  if (DAT_0012831c != '\0') {
    puVar3 = &DAT_0011cf4d;
    if ((*(char *)(param_1 + 0xb8) != '\0') && (*(long *)(param_1 + 0x20) != 0)) {
      puVar3 = (undefined1 *)
               FUN_00113ac0(*(long *)(param_1 + 0x20),auStack_2b8,param_3,&DAT_0011cf4d);
    }
    uVar4 = 0;
    if (DAT_0012835c != 4) {
      uVar4 = DAT_00128384;
    }
    __printf_chk(1,&DAT_0011cf5f,uVar4,puVar3);
  }
  if (DAT_0012834c != '\0') {
    puVar3 = &DAT_0011cf4d;
    if (*(char *)(param_1 + 0xb8) != '\0') {
      puVar3 = (undefined1 *)
               FUN_00112780(*(undefined8 *)(param_1 + 0x58),auStack_2b8,DAT_00128348,0x200,
                            DAT_00128340);
    }
    uVar4 = 0;
    if (DAT_0012835c != 4) {
      uVar4 = DAT_00128380;
    }
    __printf_chk(1,&DAT_0011cf5f,uVar4,puVar3);
  }
  if (DAT_00128389 != '\0') {
    uVar4 = 0;
    if (DAT_0012835c != 4) {
      uVar4 = DAT_00128378;
    }
    __printf_chk(1,&DAT_0011cf5f,uVar4,*(undefined8 *)(param_1 + 0xb0));
  }
  FUN_0010b1e0(param_1,0,0,param_2);
  if ((DAT_00128334 != 0) &&
     (cVar2 = FUN_00106bc0(*(undefined1 *)(param_1 + 0xb8),*(undefined4 *)(param_1 + 0x30),
                           *(undefined4 *)(param_1 + 0xa8)), cVar2 != '\0')) {
    DAT_00128218 = DAT_00128218 + 1;
    pcVar1 = stdout->_IO_write_ptr;
    if (pcVar1 < stdout->_IO_write_end) {
      stdout->_IO_write_ptr = pcVar1 + 1;
      *pcVar1 = cVar2;
    }
    else {
      __overflow(stdout,(int)cVar2);
    }
  }
  if (local_20 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return;
}



void FUN_0010c4a0(char param_1)

{
  ulong uVar1;
  char *pcVar2;
  byte *pbVar3;
  ulong uVar4;
  ulong uVar5;
  uint uVar6;
  long lVar7;
  long lVar8;
  undefined8 uVar9;
  byte bVar10;
  
  if (0 < DAT_001283d0) {
    uVar9 = *DAT_001283c0;
    uVar4 = 0;
    if (DAT_001282d0 != 0) {
      uVar4 = FUN_00107ff0(uVar9);
    }
    lVar7 = 0;
    lVar8 = 0;
    while( true ) {
      lVar7 = lVar7 + 1;
      FUN_0010c260(uVar9,lVar8);
      if (DAT_001283d0 <= lVar7) break;
      uVar9 = DAT_001283c0[lVar7];
      if (DAT_001282d0 == 0) {
        uVar1 = uVar4 + 2;
LAB_0010c51c:
        uVar5 = uVar1;
        lVar8 = uVar4 + 2;
        uVar6 = 0x20;
        bVar10 = 0x20;
      }
      else {
        uVar5 = FUN_00107ff0(uVar9);
        uVar1 = uVar4 + 2 + uVar5;
        if ((DAT_001282d0 == 0) || ((uVar1 < DAT_001282d0 && (uVar4 <= -uVar5 - 3))))
        goto LAB_0010c51c;
        uVar6 = (uint)(char)DAT_00127019;
        lVar8 = 0;
        bVar10 = DAT_00127019;
      }
      pcVar2 = stdout->_IO_write_ptr;
      if (pcVar2 < stdout->_IO_write_end) {
        stdout->_IO_write_ptr = pcVar2 + 1;
        *pcVar2 = param_1;
      }
      else {
        __overflow(stdout,(int)param_1);
      }
      pbVar3 = (byte *)stdout->_IO_write_ptr;
      uVar4 = uVar5;
      if (pbVar3 < stdout->_IO_write_end) {
        stdout->_IO_write_ptr = (char *)(pbVar3 + 1);
        *pbVar3 = bVar10;
      }
      else {
        __overflow(stdout,uVar6 & 0xff);
      }
    }
  }
  bVar10 = DAT_00127019;
  pbVar3 = (byte *)stdout->_IO_write_ptr;
  if (stdout->_IO_write_end <= pbVar3) {
    __overflow(stdout,(uint)DAT_00127019);
    return;
  }
  stdout->_IO_write_ptr = (char *)(pbVar3 + 1);
  *pbVar3 = bVar10;
  return;
}



void FUN_0010c650(void)

{
  byte *pbVar1;
  byte bVar2;
  long lVar3;
  long lVar4;
  long lVar5;
  long lVar6;
  long lVar7;
  long lVar8;
  undefined8 uVar9;
  long lVar10;
  long lVar11;
  long local_40;
  
  switch(DAT_0012835c) {
  case 0:
    lVar8 = 0;
    if (DAT_001283d0 < 1) {
      return;
    }
    do {
      if (((DAT_00128332 != '\0') && (DAT_001270a0 != 0)) &&
         ((2 < DAT_001270a0 || ((DAT_001270a8[DAT_001270a0 - 1] != '0' || (*DAT_001270a8 != '0')))))
         ) {
        FUN_00107990(&DAT_00127060);
        FUN_00107990(&DAT_001270a0);
        FUN_00107990(&DAT_00127070);
      }
      FUN_0010b820(DAT_001283c0[lVar8]);
      bVar2 = DAT_00127019;
      DAT_00128218 = DAT_00128218 + 1;
      pbVar1 = (byte *)stdout->_IO_write_ptr;
      if (pbVar1 < stdout->_IO_write_end) {
        stdout->_IO_write_ptr = (char *)(pbVar1 + 1);
        *pbVar1 = bVar2;
      }
      else {
        __overflow(stdout,(uint)DAT_00127019);
      }
      lVar8 = lVar8 + 1;
    } while (lVar8 < DAT_001283d0);
    return;
  case 1:
    lVar8 = 0;
    if (0 < DAT_001283d0) {
      do {
        FUN_0010c260(DAT_001283c0[lVar8],0);
        bVar2 = DAT_00127019;
        pbVar1 = (byte *)stdout->_IO_write_ptr;
        if (pbVar1 < stdout->_IO_write_end) {
          stdout->_IO_write_ptr = (char *)(pbVar1 + 1);
          *pbVar1 = bVar2;
        }
        else {
          __overflow(stdout,(uint)DAT_00127019);
        }
        lVar8 = lVar8 + 1;
      } while (lVar8 < DAT_001283d0);
    }
    return;
  case 2:
    if (DAT_001282d0 != 0) {
      lVar5 = FUN_001081c0(1);
      local_40 = 0;
      lVar8 = DAT_00128228 + lVar5 * 0x18;
      lVar5 = (DAT_001283d0 / lVar5 + 1) - (ulong)(DAT_001283d0 % lVar5 == 0);
      if (lVar5 < 1) {
        return;
      }
      do {
        lVar11 = 0;
        lVar3 = local_40;
        lVar4 = 0;
        while( true ) {
          uVar9 = DAT_001283c0[lVar3];
          lVar6 = FUN_00107ff0();
          lVar7 = *(long *)(*(long *)(lVar8 + -8) + lVar11);
          lVar11 = lVar11 + 8;
          FUN_0010c260(uVar9,lVar4);
          bVar2 = DAT_00127019;
          if (DAT_001283d0 - lVar5 <= lVar3) break;
          lVar7 = lVar7 + lVar4;
          lVar3 = lVar3 + lVar5;
          FUN_001075a0(lVar6 + lVar4,lVar7);
          lVar4 = lVar7;
        }
        pbVar1 = (byte *)stdout->_IO_write_ptr;
        if (pbVar1 < stdout->_IO_write_end) {
          stdout->_IO_write_ptr = (char *)(pbVar1 + 1);
          *pbVar1 = bVar2;
        }
        else {
          __overflow(stdout,(uint)DAT_00127019);
        }
        local_40 = local_40 + 1;
      } while (lVar5 != local_40);
      return;
    }
    break;
  case 3:
    if (DAT_001282d0 != 0) {
      lVar3 = FUN_001081c0(0);
      lVar8 = DAT_00128228 + -0x18 + lVar3 * 0x18;
      uVar9 = *DAT_001283c0;
      lVar4 = FUN_00107ff0(uVar9);
      lVar5 = **(long **)(lVar8 + 0x10);
      FUN_0010c260(uVar9,0);
      if (1 < DAT_001283d0) {
        lVar7 = 1;
        lVar11 = 0;
        do {
          bVar2 = DAT_00127019;
          lVar6 = lVar7 % lVar3;
          if (lVar6 == 0) {
            pbVar1 = (byte *)stdout->_IO_write_ptr;
            if (pbVar1 < stdout->_IO_write_end) {
              stdout->_IO_write_ptr = (char *)(pbVar1 + 1);
              *pbVar1 = bVar2;
            }
            else {
              __overflow(stdout,(uint)DAT_00127019);
            }
            lVar10 = 0;
          }
          else {
            lVar10 = lVar5 + lVar11;
            FUN_001075a0(lVar11 + lVar4,lVar10);
          }
          uVar9 = DAT_001283c0[lVar7];
          lVar7 = lVar7 + 1;
          FUN_0010c260(uVar9,lVar10);
          lVar4 = FUN_00107ff0(uVar9);
          lVar5 = *(long *)(*(long *)(lVar8 + 0x10) + lVar6 * 8);
          lVar11 = lVar10;
        } while (lVar7 < DAT_001283d0);
      }
      bVar2 = DAT_00127019;
      pbVar1 = (byte *)stdout->_IO_write_ptr;
      if (pbVar1 < stdout->_IO_write_end) {
        stdout->_IO_write_ptr = (char *)(pbVar1 + 1);
        *pbVar1 = bVar2;
        return;
      }
      __overflow(stdout,(uint)DAT_00127019);
      return;
    }
    break;
  case 4:
    uVar9 = 0x2c;
    goto LAB_0010c7ad;
  default:
    return;
  }
  uVar9 = 0x20;
LAB_0010c7ad:
  FUN_0010c4a0(uVar9);
  return;
}



undefined8
FUN_0010ca80(char *param_1,uint param_2,byte param_3,char *param_4,undefined8 param_5,
            undefined8 param_6)

{
  undefined8 *puVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  size_t sVar6;
  char *pcVar7;
  char *pcVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  size_t sVar11;
  long lVar12;
  int *piVar13;
  uint uVar14;
  uint uVar15;
  ulong uVar16;
  uint uVar17;
  char *pcVar18;
  char *pcVar19;
  undefined1 *puVar20;
  undefined1 *puVar22;
  undefined1 *puVar23;
  undefined1 *puVar24;
  byte bVar25;
  undefined8 *puVar26;
  byte bVar27;
  long in_FS_OFFSET;
  bool bVar28;
  byte bVar29;
  char cVar30;
  undefined1 auStack_3f8 [12];
  uint local_3ec;
  uint local_3e8;
  uint local_3e4;
  int *local_3e0;
  uint local_3d8;
  bool local_3d1;
  char *local_3d0;
  char *local_3c8;
  char *local_3c0;
  undefined1 *local_3b8;
  undefined8 local_3b0;
  undefined8 local_3a8;
  uint local_3a0;
  undefined1 local_39c [164];
  undefined1 local_2f8 [32];
  char local_2d8 [664];
  long local_40;
  undefined1 *puVar21;
  
  bVar29 = 0;
  puVar23 = auStack_3f8;
  puVar22 = auStack_3f8;
  puVar24 = auStack_3f8;
  puVar21 = auStack_3f8;
  puVar20 = auStack_3f8;
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  local_3c0 = param_1;
  if (DAT_001283d0 == DAT_001283d8) {
    DAT_001283e0 = FUN_00119f30(DAT_001283e0,&DAT_001283d8,1,0xffffffffffffffff,0xd0);
  }
  puVar1 = (undefined8 *)(DAT_001283e0 + DAT_001283d0 * 0xd0);
  *puVar1 = 0;
  puVar1[0x19] = 0;
  puVar26 = (undefined8 *)((ulong)(puVar1 + 1) & 0xfffffffffffffff8);
  for (uVar16 = (ulong)(((int)puVar1 - (int)(undefined8 *)((ulong)(puVar1 + 1) & 0xfffffffffffffff8)
                        ) + 0xd0U >> 3); uVar16 != 0; uVar16 = uVar16 - 1) {
    *puVar26 = 0;
    puVar26 = puVar26 + (ulong)bVar29 * -2 + 1;
  }
  *(uint *)(puVar1 + 0x15) = param_2;
  puVar1[0x16] = &DAT_0012702a;
  bVar28 = DAT_001283c9 == '\0';
  *(undefined4 *)((long)puVar1 + 0xc4) = 0xffffffff;
  if ((bVar28) && (DAT_001283c8 != '\0')) {
    sVar6 = FUN_00118220(local_2d8,2,local_3c0,0xffffffffffffffff,DAT_001282f0);
    if ((*local_3c0 == local_2d8[0]) && (sVar11 = strlen(local_3c0), sVar6 == sVar11)) {
      *(undefined4 *)((long)puVar1 + 0xc4) = 0;
    }
    else {
      *(undefined4 *)((long)puVar1 + 0xc4) = 1;
      DAT_001283c9 = '\x01';
    }
  }
  if (param_3 != 0) {
    if ((*local_3c0 != '/') && (param_4 != (char *)0x0)) {
      bVar28 = true;
      goto LAB_0010cb70;
    }
    local_3c8 = local_3c0;
    puVar23 = auStack_3f8;
LAB_0010d9ed:
    if (DAT_00128331 != '\0') {
LAB_0010ccfe:
      pcVar8 = local_3c8;
      *(undefined8 *)(puVar23 + -8) = 0x10cd0f;
      lVar12 = FUN_0010f460(pcVar8,2);
      puVar1[2] = lVar12;
      if (lVar12 == 0) {
        *(undefined8 *)(puVar23 + -8) = 0x10dc63;
        uVar10 = dcgettext(0,"error canonicalizing %s",5);
        pcVar8 = local_3c8;
        *(undefined8 *)(puVar23 + -8) = 0x10dc78;
        FUN_00107770(param_3,uVar10,pcVar8);
      }
    }
    uVar14 = DAT_00128318;
    puVar24 = puVar23;
    if (DAT_00128318 < 4) {
      if ((DAT_00128318 < 2) || (param_3 == 0)) goto LAB_0010cedd;
      *(undefined8 *)(puVar23 + -8) = 0x10cd46;
      uVar3 = FUN_00106d10();
      pcVar8 = local_3c8;
      *(undefined8 *)(puVar23 + -8) = 0x10cd64;
      iVar4 = FUN_00107230(0xffffff9c,pcVar8,puVar1 + 3,0,uVar3);
      if (uVar14 == 2) {
LAB_0010cd89:
        bVar29 = param_3;
        if (iVar4 == 0) goto LAB_0010cf09;
      }
      else {
        if (-1 < iVar4) {
          if ((*(uint *)(puVar1 + 6) & 0xf000) != 0x4000) goto LAB_0010cedd;
          goto LAB_0010cd89;
        }
        *(undefined8 *)(puVar23 + -8) = 0x10db95;
        piVar13 = __errno_location();
        if ((*piVar13 == 2) || (*piVar13 == 0x28)) {
LAB_0010cedd:
          *(undefined8 *)(puVar23 + -8) = 0x10cee2;
          uVar3 = FUN_00106d10();
          pcVar8 = local_3c8;
          bVar29 = 0;
          *(undefined8 *)(puVar23 + -8) = 0x10cf01;
          iVar4 = FUN_00107230(0xffffff9c,pcVar8,puVar1 + 3,0x100,uVar3);
          goto LAB_0010cf01;
        }
      }
      *(undefined8 *)(puVar23 + -8) = 0x10cda7;
      uVar10 = dcgettext(0,"cannot access %s",5);
      pcVar8 = local_3c8;
      *(undefined8 *)(puVar23 + -8) = 0x10cdbb;
      FUN_00107770(1,uVar10,pcVar8);
    }
    else {
LAB_0010d69e:
      *(undefined8 *)(puVar24 + -8) = 0x10d6a3;
      uVar3 = FUN_00106d10();
      pcVar8 = local_3c8;
      bVar29 = 1;
      *(undefined8 *)(puVar24 + -8) = 0x10d6c4;
      iVar4 = FUN_00107230(0xffffff9c,pcVar8,puVar1 + 3,0,uVar3);
      puVar23 = puVar24;
LAB_0010cf01:
      if (iVar4 == 0) {
LAB_0010cf09:
        *(undefined1 *)(puVar1 + 0x17) = 1;
        bVar27 = DAT_001282c0;
        uVar14 = (uint)DAT_00128389;
        param_2 = (uint)(char)(&DAT_0011b7e0)[*(uint *)(puVar1 + 6) >> 0xc & 0xf];
        *(uint *)(puVar1 + 0x15) = param_2;
        puVar22 = puVar23;
        if (param_3 != 0) goto LAB_0010cf50;
        goto LAB_0010cca5;
      }
      *(undefined8 *)(puVar23 + -8) = 0x10d793;
      uVar10 = dcgettext(0,"cannot access %s",5);
      pcVar8 = local_3c8;
      *(undefined8 *)(puVar23 + -8) = 0x10d7a6;
      FUN_00107770(param_3,uVar10,pcVar8);
      pcVar8 = local_3c0;
      if (param_3 == 0) {
        *(undefined8 *)(puVar23 + -8) = 0x10d7bb;
        uVar10 = FUN_0011a180(pcVar8);
        DAT_001283d0 = DAT_001283d0 + 1;
        *puVar1 = uVar10;
      }
    }
    uVar10 = 0;
    goto LAB_0010d1fa;
  }
  if (DAT_00128331 != '\0') {
    if ((*local_3c0 != '/') && (bVar28 = true, param_4 != (char *)0x0)) goto LAB_0010cb70;
    local_3c8 = local_3c0;
    puVar23 = auStack_3f8;
    goto LAB_0010ccfe;
  }
  if (((DAT_001282c2 != '\0') || ((bVar28 = param_2 == 0, DAT_001282c1 != '\0' && (bVar28)))) ||
     ((((param_2 == 3 || (bVar28)) && (DAT_00128332 != '\0')) &&
      ((((DAT_00127190 != 0 &&
         (((2 < DAT_00127190 || (PTR_DAT_00127198[DAT_00127190 - 1] != '0')) ||
          (*PTR_DAT_00127198 != '0')))) ||
        ((DAT_00127180 != 0 &&
         (((2 < DAT_00127180 || (PTR_DAT_00127188[DAT_00127180 - 1] != '0')) ||
          (*PTR_DAT_00127188 != '0')))))) ||
       ((DAT_001271a0 != 0 &&
        (((2 < DAT_001271a0 || (PTR_DAT_001271a8[DAT_001271a0 - 1] != '0')) ||
         (*PTR_DAT_001271a8 != '0')))))))))) {
LAB_0010cea0:
    if ((*local_3c0 == '/') || (bVar28 = true, param_4 == (char *)0x0)) {
      if (DAT_00128318 < 4) {
        local_3c8 = local_3c0;
        puVar23 = auStack_3f8;
        goto LAB_0010cedd;
      }
LAB_0010d690:
      local_3c8 = local_3c0;
      goto LAB_0010d69e;
    }
LAB_0010cb70:
    local_3c8 = (char *)strlen(local_3c0);
    sVar6 = strlen(param_4);
    uVar16 = (long)local_3c8 + 0x19U + sVar6;
    puVar23 = auStack_3f8;
    while (puVar21 != auStack_3f8 + -(uVar16 & 0xfffffffffffff000)) {
      puVar20 = puVar23 + -0x1000;
      *(undefined8 *)(puVar23 + -8) = *(undefined8 *)(puVar23 + -8);
      puVar21 = puVar23 + -0x1000;
      puVar23 = puVar23 + -0x1000;
    }
    uVar16 = (ulong)((uint)uVar16 & 0xff0);
    lVar12 = -uVar16;
    if (uVar16 != 0) {
      *(undefined8 *)(puVar20 + -8) = *(undefined8 *)(puVar20 + -8);
    }
    cVar2 = *param_4;
    local_3c8 = (char *)((ulong)(puVar20 + lVar12 + 0xf) & 0xfffffffffffffff0);
    cVar30 = cVar2;
    if (cVar2 == '.') {
      cVar30 = param_4[1];
    }
    pcVar8 = local_3c8;
    pcVar19 = param_4;
    if (cVar30 != '\0') {
      do {
        pcVar18 = pcVar19;
        pcVar7 = pcVar8;
        pcVar19 = pcVar18 + 1;
        pcVar8 = pcVar7 + 1;
        *pcVar7 = cVar2;
        cVar2 = *pcVar19;
      } while (cVar2 != '\0');
      if ((param_4 < pcVar19) && (*pcVar18 != '/')) {
        *pcVar8 = '/';
        pcVar8 = pcVar7 + 2;
      }
    }
    cVar2 = *local_3c0;
    pcVar19 = local_3c0;
    while (cVar2 != '\0') {
      pcVar19 = pcVar19 + 1;
      *pcVar8 = cVar2;
      pcVar8 = pcVar8 + 1;
      cVar2 = *pcVar19;
    }
    *pcVar8 = '\0';
    puVar23 = puVar20 + lVar12;
    if (bVar28) goto LAB_0010d9ed;
    uVar14 = (uint)DAT_00128389;
    bVar29 = DAT_00128318 == 4;
    puVar23 = puVar20 + lVar12;
    puVar22 = puVar20 + lVar12;
    bVar27 = DAT_001282c0;
    if (param_3 == 0) goto LAB_0010cca5;
LAB_0010cf50:
    puVar22 = puVar23;
    if (param_2 != 3) goto LAB_0010cca5;
    if (DAT_00128315 == '\0') {
      local_3d1 = false;
      param_2 = 9;
      *(undefined4 *)(puVar1 + 0x15) = 9;
      bVar27 = 0;
    }
    else {
      local_3d1 = false;
      bVar27 = 0;
      param_2 = 3;
    }
  }
  else {
    if (DAT_0012831c != '\0') {
      if ((param_2 == 6) || (bVar28)) goto LAB_0010ce22;
      goto LAB_0010cea0;
    }
    if ((DAT_001282c1 != '\0') && (param_2 == 6)) {
LAB_0010ce22:
      if (DAT_00128318 != 4) {
        if (((DAT_001283b0 == '\0') && (DAT_0012831d == '\0')) && (DAT_0012831c == '\0'))
        goto LAB_0010da80;
        if ((*local_3c0 != '/') && (bVar28 = true, param_4 != (char *)0x0)) goto LAB_0010cb70;
        local_3c8 = local_3c0;
        goto LAB_0010cedd;
      }
      if ((*local_3c0 == '/') || (bVar28 = true, param_4 == (char *)0x0)) goto LAB_0010d690;
      goto LAB_0010cb70;
    }
LAB_0010da80:
    if (((param_2 == 5) || (bVar28)) &&
       ((DAT_00128334 == 3 ||
        ((DAT_00128332 != '\0' &&
         ((((DAT_00127140 != 0 &&
            (((2 < DAT_00127140 || (PTR_DAT_00127148[DAT_00127140 - 1] != '0')) ||
             (*PTR_DAT_00127148 != '0')))) ||
           ((DAT_00127160 != 0 &&
            (((2 < DAT_00127160 || (PTR_DAT_00127168[DAT_00127160 - 1] != '0')) ||
             (*PTR_DAT_00127168 != '0')))))) ||
          ((DAT_00127170 != 0 &&
           (((2 < DAT_00127170 || (PTR_DAT_00127178[DAT_00127170 - 1] != '0')) ||
            (*PTR_DAT_00127178 != '0')))))))))))) goto LAB_0010cea0;
    uVar14 = (uint)DAT_00128389;
    if (DAT_00128389 == 0 && DAT_001282c0 == 0) {
      bVar29 = DAT_00128318 == 4;
      local_3c8 = local_3c0;
      uVar14 = 0;
      puVar22 = auStack_3f8;
      bVar27 = 0;
    }
    else {
      if ((*local_3c0 != '/') && (bVar28 = false, param_4 != (char *)0x0)) goto LAB_0010cb70;
      bVar29 = DAT_00128318 == 4;
      local_3c8 = local_3c0;
      bVar27 = DAT_001282c0;
    }
LAB_0010cca5:
    bVar27 = param_2 == 5 & bVar27;
    local_3d1 = param_2 == 6;
    puVar23 = puVar22;
  }
  local_3d8 = DAT_0012835c;
  uVar14 = DAT_0012835c == 0 | uVar14;
  bVar25 = (byte)uVar14 | bVar27;
  local_3d0 = (char *)CONCAT71(local_3d0._1_7_,bVar25);
  if (bVar25 == 0) {
    if ((DAT_0012831d != '\0') && (local_3d1 != false)) goto LAB_0010d104;
    uVar10 = puVar1[0xb];
LAB_0010d196:
    if (DAT_0012834c != '\0') goto LAB_0010d2b0;
LAB_0010d1a3:
    if (DAT_00128389 != 0) {
LAB_0010d1ac:
      pcVar8 = (char *)puVar1[0x16];
      *(undefined8 *)(puVar23 + -8) = 0x10d1b9;
      sVar6 = strlen(pcVar8);
      if (DAT_00128378 < (int)sVar6) {
        DAT_00128378 = (int)sVar6;
      }
      if (DAT_0012835c == 0) goto LAB_0010d33c;
    }
  }
  else {
    local_3e4 = (uint)bVar29 << 0x11 | uVar14 << 0x10 | (uint)(byte)(&DAT_0011b8e0)[param_2];
    cVar2 = *(char *)(puVar1 + 0x17);
    *(undefined8 *)(puVar23 + -8) = 0x10cfdc;
    local_3e0 = __errno_location();
    pcVar8 = local_3c8;
    uVar17 = local_3e4;
    uVar15 = DAT_001272f8;
    uVar14 = DAT_001272f4;
    if (((cVar2 == '\0') || (DAT_00127310 == '\0')) || (puVar1[3] != DAT_00127308)) {
      *local_3e0 = 0;
      *(undefined8 *)(puVar23 + -8) = 0x10d032;
      uVar14 = FUN_00110730(pcVar8,&local_3b8,uVar17);
      uVar17 = DAT_0012835c;
      uVar15 = local_3a0;
      if (*(char *)(puVar1 + 0x17) == '\0') goto LAB_0010d4a0;
      uVar5 = 3;
      bVar28 = false;
      if ((int)uVar14 < 1) {
        local_3ec = DAT_0012835c;
        local_3e8 = local_3a0;
        local_3d8 = uVar14;
        *(undefined8 *)(puVar23 + -8) = 0x10d480;
        cVar2 = FUN_0010ec90();
        uVar15 = local_3e8;
        uVar14 = local_3d8;
        uVar17 = local_3ec;
        if (cVar2 == '\0') {
          if ((local_3e4 & 0x10000) != 0) {
            local_3e8 = local_3ec;
            local_3e4 = local_3d8;
            local_3d8 = uVar15;
            *(undefined8 *)(puVar23 + -8) = 0x10d872;
            cVar2 = FUN_0010ec90();
            uVar14 = local_3e4;
            uVar17 = local_3e8;
            uVar15 = local_3d8;
            if (cVar2 != '\0') goto LAB_0010d4a0;
          }
          DAT_001272f8 = uVar15;
          DAT_00127300 = local_3a8;
          DAT_00127310 = '\x01';
          DAT_00127308 = puVar1[3];
          DAT_001272f4 = uVar14;
          uVar15 = DAT_001272f8;
        }
        goto LAB_0010d4a0;
      }
    }
    else {
      local_3b8 = local_39c;
      local_3a0 = DAT_001272f8;
      local_3b0 = 0;
      local_3a8 = DAT_00127300;
      *local_3e0 = 0x5f;
      uVar17 = local_3d8;
LAB_0010d4a0:
      bVar28 = false;
      uVar5 = 0;
      if ((int)uVar14 < 0) {
        bVar28 = *local_3e0 == 0xd || *local_3e0 == 2;
        uVar5 = (uint)bVar28;
      }
      if ((uVar15 == 0) || ((int)uVar14 >= 1)) {
        uVar5 = 3 - ((uint)CONCAT71((int7)((ulong)param_6 >> 8),(int)uVar14 < 1) &
                    (uint)(uVar15 == 0));
      }
      else {
        local_3d0 = (char *)CONCAT71(local_3d0._1_7_,(char)uVar5);
      }
    }
    pcVar8 = local_3c8;
    *(uint *)((long)puVar1 + 0xbc) = uVar5;
    DAT_00128388 = DAT_00128388 | (byte)local_3d0;
    if (((uVar17 != 0) || (-1 < (int)uVar14)) || (bVar28)) {
      if ((((uVar15 != 0 && uVar15 != 0x5f) & DAT_00128389) != 0) && (uVar15 != 0x3d)) {
        *(undefined8 *)(puVar23 + -8) = 0x10dc32;
        uVar10 = FUN_001188d0(0,3,pcVar8);
        uVar14 = local_3a0;
        *(undefined8 *)(puVar23 + -8) = 0x10dc4b;
        error(0,uVar14,&DAT_0011d505,uVar10);
      }
    }
    else {
      *(undefined8 *)(puVar23 + -8) = 0x10dbfe;
      uVar10 = FUN_001188d0(0,3,pcVar8);
      iVar4 = *local_3e0;
      *(undefined8 *)(puVar23 + -8) = 0x10dc1a;
      error(0,iVar4,&DAT_0011d505,uVar10);
    }
    if (bVar27 != 0) {
      *(undefined8 *)(puVar23 + -8) = 0x10d0b6;
      cVar2 = FUN_0010fec0(&local_3b8,"security.capability");
      pcVar8 = local_3c8;
      if (cVar2 != '\0') {
        if (((*(char *)(puVar1 + 0x17) == '\0') || (DAT_001272f0 == '\0')) ||
           (puVar1[3] != DAT_001272e8)) {
          *(undefined8 *)(puVar23 + -8) = 0x10d714;
          lVar12 = cap_get_file(pcVar8);
          if (lVar12 == 0) {
LAB_0010d9a0:
            if (*(char *)(puVar1 + 0x17) != '\0') {
LAB_0010d9af:
              iVar4 = *local_3e0;
              *(undefined8 *)(puVar23 + -8) = 0x10d9bd;
              cVar2 = FUN_0010ec90(iVar4);
              if (cVar2 == '\0') {
                DAT_001272e8 = puVar1[3];
                DAT_001272f0 = '\x01';
                cVar30 = '\0';
                goto LAB_0010d76c;
              }
            }
            goto LAB_0010d700;
          }
          *(undefined8 *)(puVar23 + -8) = 0x10d72a;
          local_3d0 = (char *)cap_to_text(lVar12,0);
          *(undefined8 *)(puVar23 + -8) = 0x10d739;
          cap_free(lVar12);
          pcVar8 = local_3d0;
          if (local_3d0 == (char *)0x0) goto LAB_0010d9a0;
          cVar2 = *local_3d0;
          *(undefined8 *)(puVar23 + -8) = 0x10d755;
          cap_free(pcVar8);
          cVar30 = *(char *)(puVar1 + 0x17);
          if (cVar30 != '\0') {
            if (cVar2 != '\0') goto LAB_0010d76c;
            goto LAB_0010d9af;
          }
          cVar30 = cVar2 != '\0';
        }
        else {
          *local_3e0 = 0x5f;
LAB_0010d700:
          cVar30 = '\0';
        }
LAB_0010d76c:
        *(char *)(puVar1 + 0x18) = cVar30;
      }
    }
    puVar1[0x16] = local_3a8;
    local_3a8 = 0;
    *(undefined8 *)(puVar23 + -8) = 0x10d0e0;
    FUN_00110060(&local_3b8);
    if ((DAT_0012835c == 0 || DAT_0012831d != '\0') && (local_3d1 != false)) {
LAB_0010d104:
      pcVar8 = local_3c8;
      uVar10 = puVar1[9];
      *(undefined8 *)(puVar23 + -8) = 0x10d115;
      pcVar8 = (char *)FUN_0010ecd0(pcVar8,uVar10);
      puVar1[1] = pcVar8;
      if (pcVar8 == (char *)0x0) {
        *(undefined8 *)(puVar23 + -8) = 0x10d63b;
        uVar10 = dcgettext(0,"cannot read symbolic link %s",5);
        pcVar8 = local_3c8;
        *(undefined8 *)(puVar23 + -8) = 0x10d64e;
        FUN_00107770(param_3,uVar10,pcVar8);
        pcVar8 = (char *)puVar1[1];
        if (pcVar8 == (char *)0x0) goto LAB_0010d189;
      }
      if (*(int *)((long)puVar1 + 0xc4) == 0) {
        *(undefined8 *)(puVar23 + -8) = 0x10d7f2;
        sVar6 = FUN_00118220(local_2d8,2,pcVar8,0xffffffffffffffff,DAT_001282f0);
        if (*pcVar8 == local_2d8[0]) {
          *(undefined8 *)(puVar23 + -8) = 0x10d8d8;
          sVar11 = strlen(pcVar8);
          if (sVar6 != sVar11) goto LAB_0010d805;
        }
        else {
LAB_0010d805:
          *(undefined4 *)((long)puVar1 + 0xc4) = 0xffffffff;
        }
        if (puVar1[1] == 0) goto LAB_0010d189;
      }
      pcVar8 = local_3c8;
      if ((1 < DAT_00128334) || (DAT_0012831d != '\0')) {
        *(undefined8 *)(puVar23 + -8) = 0x10d168;
        iVar4 = FUN_00107230(0xffffff9c,pcVar8,&local_3b8,0,2);
        if (iVar4 == 0) {
          *(undefined1 *)((long)puVar1 + 0xb9) = 1;
          *(uint *)((long)puVar1 + 0xac) = local_3a0;
        }
      }
    }
LAB_0010d189:
    uVar10 = puVar1[0xb];
    if (DAT_0012835c != 0) goto LAB_0010d196;
LAB_0010d2b0:
    *(undefined8 *)(puVar23 + -8) = 0x10d2d1;
    uVar9 = FUN_00112780(uVar10,local_2d8,DAT_00128348,0x200,DAT_00128340);
    *(undefined8 *)(puVar23 + -8) = 0x10d2de;
    iVar4 = FUN_00113da0(uVar9,3);
    if (DAT_00128380 < iVar4) {
      DAT_00128380 = iVar4;
    }
    if (DAT_0012835c != 0) goto LAB_0010d1a3;
    if (DAT_00127029 != '\0') {
      uVar3 = *(undefined4 *)((long)puVar1 + 0x34);
      *(undefined8 *)(puVar23 + -8) = 0x10d5e2;
      iVar4 = FUN_00108770(uVar3);
      if (DAT_00128374 < iVar4) {
        DAT_00128374 = iVar4;
      }
    }
    if (DAT_00127028 != '\0') {
      uVar3 = *(undefined4 *)(puVar1 + 7);
      if (DAT_0012834d == '\0') {
        *(undefined8 *)(puVar23 + -8) = 0x10da08;
        lVar12 = FUN_00113810(uVar3);
        if (lVar12 == 0) goto LAB_0010d59a;
        *(undefined8 *)(puVar23 + -8) = 0x10da1e;
        iVar4 = FUN_00113da0(lVar12,3);
      }
      else {
LAB_0010d59a:
        *(undefined8 *)(puVar23 + -8) = 0x10d5bb;
        iVar4 = __snprintf_chk(0,0,1,0xffffffffffffffff,&DAT_0011cf05,uVar3);
      }
      if (DAT_00128370 < iVar4) {
        DAT_00128370 = iVar4;
      }
    }
    if (DAT_0012834e != '\0') {
      uVar3 = *(undefined4 *)((long)puVar1 + 0x34);
      *(undefined8 *)(puVar23 + -8) = 0x10d60a;
      iVar4 = FUN_00108770(uVar3);
      if (DAT_0012836c < iVar4) {
        DAT_0012836c = iVar4;
      }
    }
    if (DAT_00128389 != 0) goto LAB_0010d1ac;
    if (DAT_0012835c != 0) goto joined_r0x0010d1dc;
LAB_0010d33c:
    uVar9 = puVar1[5];
    *(undefined8 *)(puVar23 + -8) = 0x10d34d;
    pcVar8 = (char *)FUN_00113ac0(uVar9,local_2f8);
    *(undefined8 *)(puVar23 + -8) = 0x10d355;
    sVar6 = strlen(pcVar8);
    if (DAT_0012837c < (int)sVar6) {
      DAT_0012837c = (int)sVar6;
    }
    if ((param_2 - 2 & 0xfffffffd) == 0) {
      uVar9 = puVar1[8];
      *(undefined8 *)(puVar23 + -8) = 0x10d39b;
      pcVar8 = (char *)FUN_00113ac0((uint)((ulong)uVar9 >> 0x20) & 0xfffff000 |
                                    (uint)((ulong)uVar9 >> 8) & 0xfff,local_2d8);
      *(undefined8 *)(puVar23 + -8) = 0x10d3a3;
      sVar6 = strlen(pcVar8);
      if (DAT_00128368 < (int)sVar6) {
        DAT_00128368 = (int)sVar6;
      }
      uVar16 = puVar1[8];
      *(undefined8 *)(puVar23 + -8) = 0x10d3cb;
      pcVar8 = (char *)FUN_00113ac0((uint)((uVar16 >> 0x14) << 8) | (uint)uVar16 & 0xff,local_2d8);
      *(undefined8 *)(puVar23 + -8) = 0x10d3d3;
      sVar6 = strlen(pcVar8);
      if (DAT_00128364 < (int)sVar6) {
        DAT_00128364 = (int)sVar6;
      }
      iVar4 = DAT_00128364 + 2 + DAT_00128368;
      if (DAT_00128360 < iVar4) {
LAB_0010d3fb:
        DAT_00128360 = iVar4;
      }
    }
    else {
      uVar9 = puVar1[9];
      *(undefined8 *)(puVar23 + -8) = 0x10d563;
      uVar9 = FUN_00112780(uVar9,local_2d8,DAT_0012833c,1,DAT_00127020);
      *(undefined8 *)(puVar23 + -8) = 0x10d570;
      iVar4 = FUN_00113da0(uVar9,3);
      if (DAT_00128360 < iVar4) goto LAB_0010d3fb;
    }
  }
joined_r0x0010d1dc:
  if (DAT_0012831c != '\0') {
    uVar9 = puVar1[4];
    *(undefined8 *)(puVar23 + -8) = 0x10d421;
    pcVar8 = (char *)FUN_00113ac0(uVar9,local_2d8);
    *(undefined8 *)(puVar23 + -8) = 0x10d429;
    sVar6 = strlen(pcVar8);
    if (DAT_00128384 < (int)sVar6) {
      DAT_00128384 = (int)sVar6;
    }
  }
  pcVar8 = local_3c0;
  *(undefined8 *)(puVar23 + -8) = 0x10d1ee;
  uVar9 = FUN_0011a180(pcVar8);
  DAT_001283d0 = DAT_001283d0 + 1;
  *puVar1 = uVar9;
LAB_0010d1fa:
  if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
    return uVar10;
  }
                    // WARNING: Subroutine does not return
  *(undefined8 *)(puVar23 + -8) = 0x10dbeb;
  __stack_chk_fail();
}



void FUN_0010dc80(char *param_1,char *param_2,undefined1 param_3)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  DIR *__dirp;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  dirent *pdVar8;
  char *pcVar9;
  size_t sVar10;
  char *__s;
  size_t sVar11;
  long lVar12;
  void *__ptr;
  long in_FS_OFFSET;
  bool bVar13;
  long local_378;
  undefined8 local_368;
  undefined8 uStack_360;
  undefined1 local_2d7 [663];
  long local_40;
  
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  piVar3 = __errno_location();
  *piVar3 = 0;
  __dirp = opendir(param_1);
  if (__dirp == (DIR *)0x0) {
    uVar6 = dcgettext(0,"cannot open directory %s",5);
    if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
      FUN_00107770(param_3,uVar6,param_1);
      return;
    }
    goto LAB_0010e34f;
  }
  if (DAT_001283e8 == 0) {
LAB_0010ddda:
    FUN_001087c0();
    cVar1 = DAT_00128338;
    if ((DAT_00128316 != '\0') || (DAT_001282d8 != '\0')) {
      if (DAT_00127010 == '\0') {
        DAT_00128218 = DAT_00128218 + 1;
        pcVar9 = stdout->_IO_write_ptr;
        if (stdout->_IO_write_end <= pcVar9) {
          __overflow(stdout,10);
          goto LAB_0010ddf9;
        }
        DAT_00127010 = '\0';
        stdout->_IO_write_ptr = pcVar9 + 1;
        *pcVar9 = '\n';
      }
      else {
LAB_0010ddf9:
        DAT_00127010 = '\0';
        cVar1 = DAT_00128338;
      }
      if (cVar1 != '\0') {
        FUN_00107580(&DAT_0011cf57,2);
      }
      __ptr = (void *)0x0;
      if ((DAT_00128331 != '\0') && (__ptr = (void *)FUN_0010f460(param_1,2), __ptr == (void *)0x0))
      {
        uVar6 = dcgettext(0,"error canonicalizing %s",5);
        FUN_00107770(param_3,uVar6,param_1);
      }
      if (param_2 == (char *)0x0) {
        param_2 = param_1;
      }
      FUN_0010add0(param_2,DAT_001282e8,0xffffffff,0,1,&DAT_00128160,__ptr);
      free(__ptr);
      FUN_00107580(":\n",2);
    }
    local_378 = 0;
    while( true ) {
      *piVar3 = 0;
      pdVar8 = readdir(__dirp);
      if (pdVar8 == (dirent *)0x0) break;
      pcVar9 = pdVar8->d_name;
      puVar4 = DAT_00128308;
      if (DAT_00128310 == 2) {
joined_r0x0010e0ba:
        for (; puVar4 != (undefined8 *)0x0; puVar4 = (undefined8 *)puVar4[1]) {
          iVar2 = fnmatch((char *)*puVar4,pcVar9,4);
          if (iVar2 == 0) goto LAB_0010df00;
        }
        lVar12 = FUN_0010ca80(pcVar9,(int)(char)(&DAT_0011b7e0)[pdVar8->d_type],0,param_1);
        local_378 = local_378 + lVar12;
        if ((((DAT_0012835c == 1) && (DAT_00128350 == 6)) && (DAT_0012834c == '\0')) &&
           (DAT_00128316 == '\0')) {
          FUN_00108e30();
          FUN_0010c650();
          FUN_001087c0();
        }
      }
      else {
        if (pdVar8->d_name[0] != '.') {
          puVar5 = DAT_00128300;
          if (DAT_00128310 == 0) {
            for (; puVar4 = DAT_00128308, puVar5 != (undefined8 *)0x0;
                puVar5 = (undefined8 *)puVar5[1]) {
              iVar2 = fnmatch((char *)*puVar5,pcVar9,4);
              if (iVar2 == 0) goto LAB_0010df00;
            }
          }
          goto joined_r0x0010e0ba;
        }
        if (DAT_00128310 != 0) {
          lVar12 = 1;
          if (pdVar8->d_name[1] == '.') {
            lVar12 = 2;
          }
          if (pdVar8->d_name[lVar12] != '\0') goto joined_r0x0010e0ba;
        }
      }
LAB_0010df00:
      FUN_00108670();
    }
    iVar2 = *piVar3;
    if (iVar2 != 0) {
      uVar6 = dcgettext(0,"reading directory %s",5);
      FUN_00107770(param_3,uVar6,param_1);
      if (iVar2 == 0x4b) goto LAB_0010df00;
    }
    iVar2 = closedir(__dirp);
    if (iVar2 == 0) {
      FUN_00108e30();
    }
    else {
      uVar6 = dcgettext(0,"closing directory %s",5);
      FUN_00107770(param_3,uVar6,param_1);
      FUN_00108e30();
    }
    if (DAT_00128316 != '\0') {
      FUN_00109530(param_1,0);
    }
    if ((DAT_0012835c == 0) || (DAT_0012834c != '\0')) {
      pcVar9 = (char *)FUN_00112780(local_378,local_2d7,DAT_00128348,0x200,DAT_00128340);
      sVar10 = strlen(pcVar9);
      cVar1 = DAT_00127019;
      pcVar9[-1] = ' ';
      bVar13 = DAT_00128338 != '\0';
      pcVar9[sVar10] = cVar1;
      if (bVar13) {
        FUN_00107580(&DAT_0011cf57,2);
      }
      __s = (char *)dcgettext(0,"total",5);
      sVar11 = strlen(__s);
      FUN_00107580(__s,sVar11);
      FUN_00107580(pcVar9 + -1,pcVar9 + sVar10 + (1 - (long)(pcVar9 + -1)));
    }
    if (DAT_001283d0 != 0) {
      if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
        FUN_0010c650();
        return;
      }
      goto LAB_0010e34f;
    }
  }
  else {
    iVar2 = dirfd(__dirp);
    if (iVar2 < 0) {
      iVar2 = FUN_00107230(0xffffff9c,param_1,&local_368,0,0x100);
      uVar6 = local_368;
      uVar7 = uStack_360;
    }
    else {
      iVar2 = FUN_00107230(iVar2,&DAT_0011cf4c,&local_368,0x1000,0x100);
      uVar6 = local_368;
      uVar7 = uStack_360;
    }
    if (iVar2 < 0) {
      uVar6 = dcgettext(0,"cannot determine device and inode of %s",5);
      FUN_00107770(param_3,uVar6,param_1);
      if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
        closedir(__dirp);
        return;
      }
      goto LAB_0010e34f;
    }
    puVar4 = (undefined8 *)FUN_00119d00(0x10);
    lVar12 = DAT_001283e8;
    *puVar4 = uVar7;
    puVar4[1] = uVar6;
    puVar5 = (undefined8 *)FUN_001124c0(lVar12,puVar4);
    if (puVar5 == (undefined8 *)0x0) {
                    // WARNING: Subroutine does not return
      FUN_0011a1c0();
    }
    if (puVar4 == puVar5) {
      puVar4 = DAT_00128118;
      if ((ulong)(DAT_00128120 - (long)DAT_00128118) < 0x10) {
        FUN_00116220(&DAT_00128100,0x10);
        puVar4 = DAT_00128118;
      }
      DAT_00128118 = puVar4 + 2;
      *puVar4 = uVar7;
      puVar4[1] = uVar6;
      goto LAB_0010ddda;
    }
    free(puVar4);
    uVar6 = FUN_001188d0(0,3,param_1);
    uVar7 = dcgettext(0,"%s: not listing already-listed directory",5);
    error(0,0,uVar7,uVar6);
    closedir(__dirp);
    DAT_00128230 = 2;
  }
  if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
    return;
  }
LAB_0010e34f:
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_0010e360(int param_1)

{
  FILE *pFVar1;
  int iVar2;
  undefined8 uVar3;
  char *pcVar4;
  undefined8 uVar5;
  char *pcVar6;
  undefined **ppuVar7;
  char *__s1;
  char *pcVar8;
  long in_FS_OFFSET;
  undefined *local_b8;
  char *pcStack_b0;
  char *local_a8 [4];
  char *local_88;
  char *pcStack_80;
  char *local_78;
  char *pcStack_70;
  char *local_68;
  char *pcStack_60;
  undefined1 local_58 [16];
  undefined8 local_40;
  
  uVar5 = DAT_00128448;
  ppuVar7 = &local_b8;
  local_40 = *(undefined8 *)(in_FS_OFFSET + 0x28);
  if (param_1 == 0) {
    __s1 = "ls";
    uVar3 = dcgettext(0,"Usage: %s [OPTION]... [FILE]...\n",5);
    __printf_chk(1,uVar3,uVar5);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "List information about the FILEs (the current directory by default).\nSort entries alphabetically if none of -cftuvSUX nor --sort is specified.\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "\nMandatory arguments to long options are mandatory for short options too.\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -a, --all                  do not ignore entries starting with .\n  -A, --almost-all           do not list implied . and ..\n      --author               with -l, print the author of each file\n  -b, --escape               print C-style escapes for nongraphic characters\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "      --block-size=SIZE      with -l, scale sizes by SIZE when printing them;\n                             e.g., \'--block-size=M\'; see SIZE format below\n\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -B, --ignore-backups       do not list implied entries ending with ~\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -c                         with -lt: sort by, and show, ctime (time of last\n                             change of file status information);\n                             with -l: show ctime and sort by name;\n                             otherwise: sort by ctime, newest first\n\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -C                         list entries by columns\n      --color[=WHEN]         color the output WHEN; more info below\n  -d, --directory            list directories themselves, not their contents\n  -D, --dired                generate output designed for Emacs\' dired mode\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -f                         same as -a -U\n  -F, --classify[=WHEN]      append indicator (one of */=>@|) to entries WHEN\n      --file-type            likewise, except do not append \'*\'\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "      --format=WORD          across,horizontal (-x), commas (-m), long (-l),\n                             single-column (-1), verbose (-l), vertical (-C)\n\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,"      --full-time            like -l --time-style=full-iso\n",5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,"  -g                         like -l, but do not list owner\n",5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "      --group-directories-first\n                             group directories before files\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -G, --no-group             in a long listing, don\'t print group names\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -h, --human-readable       with -l and -s, print sizes like 1K 234M 2G etc.\n      --si                   likewise, but use powers of 1000 not 1024\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -H, --dereference-command-line\n                             follow symbolic links listed on the command line\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "      --dereference-command-line-symlink-to-dir\n                             follow each command line symbolic link\n                             that points to a directory\n\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "      --hide=PATTERN         do not list implied entries matching shell PATTERN\n                             (overridden by -a or -A)\n\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,"      --hyperlink[=WHEN]     hyperlink file names WHEN\n",5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "      --indicator-style=WORD\n                             append indicator with style WORD to entry names:\n                             none (default), slash (-p),\n                             file-type (--file-type), classify (-F)\n\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -i, --inode                print the index number of each file\n  -I, --ignore=PATTERN       do not list implied entries matching shell PATTERN\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -k, --kibibytes            default to 1024-byte blocks for file system usage;\n                             used only with -s and per directory totals\n\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,"  -l                         use a long listing format\n",5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -L, --dereference          when showing file information for a symbolic\n                             link, show information for the file the link\n                             references rather than for the link itself\n\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -m                         fill width with a comma separated list of entries\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -n, --numeric-uid-gid      like -l, but list numeric user and group IDs\n  -N, --literal              print entry names without quoting\n  -o                         like -l, but do not list group information\n  -p, --indicator-style=slash\n                             append / indicator to directories\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -q, --hide-control-chars   print ? instead of nongraphic characters\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "      --show-control-chars   show nongraphic characters as-is (the default,\n                             unless program is \'ls\' and output is a terminal)\n\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -Q, --quote-name           enclose entry names in double quotes\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "      --quoting-style=WORD   use quoting style WORD for entry names:\n                             literal, locale, shell, shell-always,\n                             shell-escape, shell-escape-always, c, escape\n                             (overrides QUOTING_STYLE environment variable)\n\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -r, --reverse              reverse order while sorting\n  -R, --recursive            list subdirectories recursively\n  -s, --size                 print the allocated size of each file, in blocks\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,"  -S                         sort by file size, largest first\n",5
                              );
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "      --sort=WORD            change default \'name\' sort to WORD:\n                               none (-U), size (-S), time (-t),\n                               version (-v), extension (-X), name, width\n\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "      --time=WORD            select which timestamp used to display or sort;\n                               access time (-u): atime, access, use;\n                               metadata change time (-c): ctime, status;\n                               modified time (default): mtime, modification;\n                               birth time: birth, creation;\n                             with -l, WORD determines which time to show;\n                             with --sort=time, sort by WORD (newest first)\n\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "      --time-style=TIME_STYLE\n                             time/date format with -l; see TIME_STYLE below\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -t                         sort by time, newest first; see --time\n  -T, --tabsize=COLS         assume tab stops at each COLS instead of 8\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -u                         with -lt: sort by, and show, access time;\n                             with -l: show access time and sort by name;\n                             otherwise: sort by access time, newest first\n\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,"  -U                         do not sort directory entries\n",5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -v                         natural sort of (version) numbers within text\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "  -w, --width=COLS           set output width to COLS.  0 means no limit\n  -x                         list entries by lines instead of by columns\n  -X                         sort alphabetically by entry extension\n  -Z, --context              print any security context of each file\n      --zero                 end each output line with NUL, not newline\n  -1                         list one file per line\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,"      --help        display this help and exit\n",5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,"      --version     output version information and exit\n",5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "\nThe SIZE argument is an integer and optional unit (example: 10K is 10*1024).\nUnits are K,M,G,T,P,E,Z,Y,R,Q (powers of 1024) or KB,MB,... (powers of 1000).\nBinary prefixes can be used, too: KiB=K, MiB=M, and so on.\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "\nThe TIME_STYLE argument can be full-iso, long-iso, iso, locale, or +FORMAT.\nFORMAT is interpreted like in date(1).  If FORMAT is FORMAT1<newline>FORMAT2,\nthen FORMAT1 applies to non-recent files and FORMAT2 to recent files.\nTIME_STYLE prefixed with \'posix-\' takes effect only outside the POSIX locale.\nAlso the TIME_STYLE environment variable sets the default style to use.\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "\nThe WHEN argument defaults to \'always\' and can also be \'auto\' or \'never\'.\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "\nUsing color to distinguish file types is disabled both by default and\nwith --color=never.  With --color=auto, ls emits color codes only when\nstandard output is connected to a terminal.  The LS_COLORS environment\nvariable can change the settings.  Use the dircolors(1) command to set it.\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    pFVar1 = stdout;
    pcVar4 = (char *)dcgettext(0,
                               "\nExit status:\n 0  if OK,\n 1  if minor problems (e.g., cannot access subdirectory),\n 2  if serious trouble (e.g., cannot access command-line argument).\n"
                               ,5);
    fputs_unlocked(pcVar4,pFVar1);
    if ((DAT_001271e0 != 1) && (__s1 = "vdir", DAT_001271e0 == 2)) {
      __s1 = "dir";
    }
    pcVar4 = "[";
    local_b8 = &DAT_0011d011;
    pcStack_b0 = "test invocation";
    local_a8[0] = "coreutils";
    local_a8[1] = "Multi-call invocation";
    local_a8[2] = "sha224sum";
    local_a8[3] = "sha2 utilities";
    local_88 = "sha256sum";
    pcStack_80 = "sha2 utilities";
    local_78 = "sha384sum";
    pcStack_70 = "sha2 utilities";
    local_68 = "sha512sum";
    pcStack_60 = "sha2 utilities";
    local_58 = (undefined1  [16])0x0;
    do {
      iVar2 = strcmp(__s1,pcVar4);
      if (iVar2 == 0) break;
      pcVar4 = *(char **)((long)ppuVar7 + 0x10);
      ppuVar7 = (undefined **)((long)ppuVar7 + 0x10);
    } while (pcVar4 != (char *)0x0);
    pcVar4 = *(char **)((long)ppuVar7 + 8);
    if (*(char **)((long)ppuVar7 + 8) == (char *)0x0) {
      pcVar4 = __s1;
    }
    uVar5 = dcgettext(0,"\n%s online help: <%s>\n",5);
    __printf_chk(1,uVar5,"GNU coreutils","https://www.gnu.org/software/coreutils/");
    pcVar6 = setlocale(5,(char *)0x0);
    if (pcVar6 != (char *)0x0) {
      iVar2 = strncmp(pcVar6,"en_",3);
      pFVar1 = stdout;
      if (iVar2 != 0) {
        pcVar6 = (char *)dcgettext(0,
                                   "Report any translation bugs to <https://translationproject.org/team/>\n"
                                   ,5);
        fputs_unlocked(pcVar6,pFVar1);
      }
    }
    iVar2 = strcmp(__s1,"[");
    pcVar6 = "test";
    if (iVar2 != 0) {
      pcVar6 = __s1;
    }
    uVar5 = dcgettext(0,"Full documentation <%s%s>\n",5);
    pcVar8 = "";
    __printf_chk(1,uVar5,"https://www.gnu.org/software/coreutils/",pcVar6);
    if (__s1 == pcVar4) {
      pcVar8 = " invocation";
    }
    uVar5 = dcgettext(0,"or available locally via: info \'(coreutils) %s%s\'\n",5);
    __printf_chk(1,uVar5,pcVar4,pcVar8);
  }
  else {
    uVar3 = dcgettext(0,"Try \'%s --help\' for more information.\n",5);
    __fprintf_chk(stderr,1,uVar3,uVar5);
  }
                    // WARNING: Subroutine does not return
  exit(param_1);
}



bool FUN_0010ec90(int param_1)

{
  if (param_1 == 0x26) {
    return false;
  }
  if (param_1 < 0x27) {
    return param_1 != 0x16 && param_1 != 0x10;
  }
  return param_1 != 0x5f;
}



char * FUN_0010ecd0(char *param_1,ulong param_2)

{
  ulong uVar1;
  char *__ptr;
  char *pcVar2;
  int *piVar3;
  void *__dest;
  size_t __len;
  long in_FS_OFFSET;
  char local_c8 [136];
  long local_40;
  
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  uVar1 = 0x400;
  if (param_2 < 0x401) {
    uVar1 = param_2;
  }
  __len = 0x80;
  if (param_2 != 0) {
    __len = uVar1 + 1;
  }
  do {
    if (__len != 0x80) goto LAB_0010ed9c;
    if (param_2 != 0) goto LAB_0010ed9c;
    __len = 0x80;
    __ptr = (char *)0x0;
    pcVar2 = local_c8;
LAB_0010ed56:
    uVar1 = readlink(param_1,pcVar2,__len);
    if ((long)uVar1 < 0) {
      free(__ptr);
LAB_0010edc0:
      __ptr = (char *)0x0;
      goto LAB_0010edd0;
    }
    if (uVar1 < __len) {
      pcVar2[uVar1] = '\0';
      uVar1 = uVar1 + 1;
      if (__ptr != (char *)0x0) {
        if ((uVar1 < __len) && (pcVar2 = realloc(__ptr,uVar1), pcVar2 != (char *)0x0)) {
          __ptr = pcVar2;
        }
        goto LAB_0010edd0;
      }
      __dest = malloc(uVar1);
      if (__dest != (void *)0x0) {
        __ptr = memcpy(__dest,pcVar2,uVar1);
        goto LAB_0010edd0;
      }
      goto LAB_0010edc0;
    }
    free(__ptr);
    if (0x3fffffffffffffff < __len) {
      if (__len != 0x7fffffffffffffff) break;
      goto LAB_0010ee30;
    }
    __len = __len * 2;
  } while( true );
  __len = 0x7fffffffffffffff;
LAB_0010ed9c:
  __ptr = malloc(__len);
  pcVar2 = __ptr;
  if (__ptr == (char *)0x0) {
LAB_0010ee30:
    piVar3 = __errno_location();
    *piVar3 = 0xc;
    __ptr = (char *)0x0;
LAB_0010edd0:
    if (local_40 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
      __stack_chk_fail();
    }
    return __ptr;
  }
  goto LAB_0010ed56;
}



void FUN_0010ee70(void)

{
  FUN_0010e360(1);
  return;
}



long FUN_0010ee80(char *param_1,long *param_2,void *param_3,size_t param_4)

{
  bool bVar1;
  long lVar2;
  int iVar3;
  size_t __n;
  size_t sVar4;
  long lVar5;
  void *__s2;
  char *__s1;
  long local_58;
  
  __n = strlen(param_1);
  __s1 = (char *)*param_2;
  if (__s1 == (char *)0x0) {
    local_58 = -1;
    lVar2 = local_58;
  }
  else {
    bVar1 = false;
    local_58 = -1;
    lVar2 = 0;
    __s2 = param_3;
LAB_0010ef0d:
    do {
      lVar5 = lVar2;
      iVar3 = strncmp(__s1,param_1,__n);
      if (iVar3 == 0) {
        sVar4 = strlen(__s1);
        if (sVar4 == __n) {
          return lVar5;
        }
        if (local_58 == -1) {
          __s2 = (void *)((long)__s2 + param_4);
          __s1 = (char *)param_2[lVar5 + 1];
          lVar2 = lVar5 + 1;
          local_58 = lVar5;
          if (__s1 == (char *)0x0) break;
          goto LAB_0010ef0d;
        }
        if (param_3 == (void *)0x0) {
          bVar1 = true;
        }
        else {
          iVar3 = memcmp((void *)(local_58 * param_4 + (long)param_3),__s2,param_4);
          bVar1 = (bool)(bVar1 | iVar3 != 0);
        }
      }
      __s2 = (void *)((long)__s2 + param_4);
      __s1 = (char *)param_2[lVar5 + 1];
      lVar2 = lVar5 + 1;
    } while (__s1 != (char *)0x0);
    lVar2 = -2;
    if (!bVar1) {
      lVar2 = local_58;
    }
  }
  local_58 = lVar2;
  return local_58;
}



long FUN_0010efa0(char *param_1,long *param_2)

{
  int iVar1;
  long lVar2;
  char *__s1;
  
  __s1 = (char *)*param_2;
  if (__s1 != (char *)0x0) {
    lVar2 = 0;
    do {
      iVar1 = strcmp(__s1,param_1);
      if (iVar1 == 0) {
        return lVar2;
      }
      lVar2 = lVar2 + 1;
      __s1 = (char *)param_2[lVar2];
    } while (__s1 != (char *)0x0);
  }
  return -1;
}



void FUN_0010f000(undefined8 param_1,undefined8 param_2,long param_3)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  
  if (param_3 == -1) {
    uVar1 = dcgettext("gnulib","invalid argument %s for %s",5);
  }
  else {
    uVar1 = dcgettext("gnulib","ambiguous argument %s for %s",5);
  }
  uVar2 = FUN_00118c00(1,param_1);
  uVar3 = FUN_001184b0(0,8,param_2);
  error(0,0,uVar1,uVar3,uVar2);
  return;
}



void FUN_0010f090(long *param_1,void *param_2,size_t param_3)

{
  FILE *__stream;
  int iVar1;
  char *pcVar2;
  undefined8 uVar3;
  void *__s1;
  long lVar4;
  long lVar5;
  
  __stream = stderr;
  lVar4 = 0;
  pcVar2 = (char *)dcgettext("gnulib","Valid arguments are:",5);
  fputs_unlocked(pcVar2,__stream);
  lVar5 = *param_1;
  if (lVar5 == 0) {
LAB_0010f180:
    pcVar2 = stderr->_IO_write_ptr;
    if (pcVar2 < stderr->_IO_write_end) {
      stderr->_IO_write_ptr = pcVar2 + 1;
      *pcVar2 = '\n';
      return;
    }
    __overflow(stderr,10);
    return;
  }
  do {
    __s1 = param_2;
    lVar4 = lVar4 + 1;
    uVar3 = FUN_00118c20(lVar5);
    __fprintf_chk(stderr,1,"\n  - %s",uVar3);
    lVar5 = param_1[lVar4];
    param_2 = __s1;
    while( true ) {
      if (lVar5 == 0) goto LAB_0010f180;
      param_2 = (void *)((long)param_2 + param_3);
      iVar1 = memcmp(__s1,param_2,param_3);
      if (iVar1 != 0) break;
      lVar4 = lVar4 + 1;
      uVar3 = FUN_00118c20(lVar5);
      __fprintf_chk(stderr,1,&DAT_0011d503,uVar3);
      lVar5 = param_1[lVar4];
    }
  } while( true );
}



long FUN_0010f1d0(undefined8 param_1,char *param_2,undefined8 *param_3,undefined8 param_4,
                 undefined8 param_5,code *param_6,char param_7)

{
  char *__s1;
  int iVar1;
  long lVar2;
  
  if (param_7 == '\0') {
    lVar2 = 0;
    __s1 = (char *)*param_3;
    while (__s1 != (char *)0x0) {
      iVar1 = strcmp(__s1,param_2);
      if (iVar1 == 0) {
        return lVar2;
      }
      lVar2 = lVar2 + 1;
      __s1 = (char *)param_3[lVar2];
    }
    lVar2 = -1;
  }
  else {
    lVar2 = FUN_0010ee80(param_2,param_3,param_4,param_5);
    if (-1 < lVar2) {
      return lVar2;
    }
  }
  FUN_0010f000(param_1,param_2,lVar2);
  FUN_0010f090(param_3,param_4,param_5);
  (*param_6)();
  return -1;
}



long FUN_0010f2a0(void *param_1,long *param_2,void *param_3,size_t param_4)

{
  long lVar1;
  int iVar2;
  
  lVar1 = *param_2;
  while( true ) {
    if (lVar1 == 0) {
      return 0;
    }
    param_2 = param_2 + 1;
    iVar2 = memcmp(param_1,param_3,param_4);
    if (iVar2 == 0) break;
    lVar1 = *param_2;
    param_3 = (void *)((long)param_3 + param_4);
  }
  return lVar1;
}



void thunk_FUN_0010f314(void)

{
  FUN_0010f314();
  return;
}



char * FUN_0010f314(char *param_1)

{
  char cVar1;
  char *pcVar2;
  bool bVar3;
  
  for (; cVar1 = *param_1, cVar1 == '/'; param_1 = param_1 + 1) {
  }
  if (cVar1 != '\0') {
    bVar3 = false;
    pcVar2 = param_1;
    do {
      if (cVar1 == '/') {
        bVar3 = true;
      }
      else if (bVar3) {
        do {
          param_1 = pcVar2;
          if (param_1[1] == '\0') {
            return param_1;
          }
          pcVar2 = param_1 + 2;
          cVar1 = param_1[2];
          if (param_1[1] != '/') {
            if (cVar1 == '\0') {
              return param_1;
            }
            bVar3 = cVar1 == '/';
            break;
          }
          if (cVar1 == '\0') {
            return param_1;
          }
        } while (cVar1 != '/');
      }
      cVar1 = pcVar2[1];
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
  }
  return param_1;
}



void FUN_0010f390(char *param_1)

{
  long lVar1;
  ulong uVar2;
  
  uVar2 = strlen(param_1);
  do {
    if (uVar2 < 2) {
      return;
    }
    lVar1 = uVar2 - 1;
    uVar2 = uVar2 - 1;
  } while (param_1[lVar1] == '/');
  return;
}



int FUN_0010f3c0(long param_1,long param_2,long param_3)

{
  uint uVar1;
  long lVar2;
  long lVar3;
  byte bVar4;
  uint uVar5;
  
  if ((param_1 == param_2) || (param_3 == 0)) {
    return 0;
  }
  lVar2 = 0;
  do {
    bVar4 = *(byte *)(param_1 + lVar2);
    uVar1 = (uint)bVar4;
    uVar5 = (uint)*(byte *)(param_2 + lVar2);
    lVar3 = param_3 + -1;
    if (uVar1 - 0x41 < 0x1a) {
      uVar1 = uVar1 + 0x20;
      bVar4 = bVar4 + 0x20;
      if (uVar5 - 0x41 < 0x1a) {
        uVar5 = uVar5 + 0x20;
        if (param_3 == 1) break;
      }
      else if (lVar3 == 0) break;
    }
    else {
      if (uVar5 - 0x41 < 0x1a) {
        uVar5 = uVar5 + 0x20;
      }
      if ((lVar3 == 0) || (uVar1 == 0)) break;
    }
    lVar2 = lVar2 + 1;
    param_3 = lVar3;
  } while (bVar4 == (byte)uVar5);
  return uVar1 - uVar5;
}



void * FUN_0010f460(char *param_1,uint param_2)

{
  ulong uVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  char *pcVar5;
  int *piVar6;
  char *pcVar7;
  char *pcVar8;
  void *pvVar9;
  size_t __n;
  char *pcVar10;
  char cVar11;
  char *pcVar12;
  long lVar13;
  char *__file;
  uint uVar14;
  size_t sVar15;
  char *pcVar16;
  long in_FS_OFFSET;
  bool bVar17;
  long local_d58;
  int local_d2c;
  long local_d18;
  stat local_d08;
  char *local_c78;
  size_t local_c70;
  char local_c68;
  char local_c67 [1023];
  char *local_868;
  ulong local_860;
  char local_858 [1024];
  char *local_458;
  long local_450;
  char local_448 [1032];
  long local_40;
  
  uVar14 = param_2 & 3;
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  local_c70 = 0x400;
  local_868 = local_858;
  local_860 = 0x400;
  local_458 = local_448;
  local_450 = 0x400;
  local_c78 = &local_c68;
  if (((uVar14 - 1 & uVar14) != 0) || (param_1 == (char *)0x0)) {
    piVar6 = __errno_location();
    pvVar9 = (void *)0x0;
    *piVar6 = 0x16;
    goto LAB_0010f607;
  }
  if (*param_1 == '\0') {
    piVar6 = __errno_location();
    pvVar9 = (void *)0x0;
    *piVar6 = 2;
    goto LAB_0010f607;
  }
  pcVar16 = &local_c68;
  if (*param_1 == '/') {
    local_c68 = '/';
    pcVar5 = local_c67;
    cVar3 = '/';
LAB_0010f670:
    bVar2 = false;
    local_d2c = 0;
    local_d58 = 0;
joined_r0x0010f6b1:
    pcVar12 = param_1;
    if (cVar3 != '/') goto LAB_0010f700;
LAB_0010f6c0:
    do {
      do {
        cVar3 = param_1[1];
        param_1 = param_1 + 1;
      } while (cVar3 == '/');
      pcVar12 = param_1;
      if (cVar3 == '\0') goto LAB_0010f8c0;
LAB_0010f700:
      do {
        pcVar10 = param_1;
        cVar11 = pcVar10[1];
        param_1 = pcVar10 + 1;
        if (cVar11 == '\0') break;
      } while (cVar11 != '/');
      sVar15 = (long)param_1 - (long)pcVar12;
      if (sVar15 == 0) goto LAB_0010fc55;
      if (sVar15 == 1) {
        if (cVar3 == '.') goto LAB_0010f8b0;
        goto LAB_0010f769;
      }
      if (((cVar3 != '.') || (sVar15 != 2)) || (pcVar12[1] != '.')) goto LAB_0010f769;
      pcVar12 = pcVar16 + 1;
      if ((pcVar12 < pcVar5) && (pcVar5 = pcVar5 + -1, pcVar16 < pcVar5)) goto LAB_0010fa55;
      if (cVar11 == '\0') goto LAB_0010f8d9;
    } while( true );
  }
  pcVar5 = getcwd(&local_c68,0x400);
  while (pcVar5 == (char *)0x0) {
    piVar6 = __errno_location();
    if (*piVar6 == 0xc) goto LAB_0010f7d6;
    if (*piVar6 != 0x22) goto LAB_0010f5e1;
    cVar3 = FUN_001112e0(&local_c78);
    pcVar16 = local_c78;
    if (cVar3 == '\0') goto LAB_0010f7d6;
    pcVar5 = getcwd(local_c78,local_c70);
  }
  pcVar5 = rawmemchr(pcVar16,0);
  cVar3 = *param_1;
  if (cVar3 != '\0') goto LAB_0010f670;
  pcVar12 = pcVar5 + 1;
  if ((pcVar16 + 1 < pcVar5) && (pcVar5[-1] == '/')) goto LAB_0010f5ae;
  goto LAB_0010f904;
LAB_0010f8b0:
  if (cVar11 == '\0') {
LAB_0010f8c0:
    pcVar12 = pcVar16 + 1;
    goto LAB_0010f8d9;
  }
  goto LAB_0010f6c0;
LAB_0010f769:
  if (pcVar5[-1] != '/') {
    *pcVar5 = '/';
    pcVar5 = pcVar5 + 1;
  }
  pcVar7 = pcVar16 + (local_c70 - (long)pcVar5);
  while (pcVar7 < (char *)(sVar15 + 2)) {
    lVar13 = (long)pcVar5 - (long)pcVar16;
    cVar3 = FUN_00111350(&local_c78);
    if (cVar3 == '\0') goto LAB_0010f7d6;
    pcVar5 = local_c78 + lVar13;
    pcVar16 = local_c78;
    pcVar7 = (char *)(local_c70 - lVar13);
  }
  pcVar7 = mempcpy(pcVar5,pcVar12,sVar15);
  *pcVar7 = '\0';
  pcVar5 = pcVar7;
  if ((param_2 & 4) == 0) {
    while (pcVar8 = local_458, sVar15 = local_450 - 1, __n = readlink(pcVar16,local_458,sVar15),
          (long)sVar15 <= (long)__n) {
      cVar3 = FUN_001112e0(&local_458);
      if (cVar3 == '\0') goto LAB_0010f7d6;
    }
    if (-1 < (long)__n) {
      if (local_d2c < 0x14) {
        local_d2c = local_d2c + 1;
      }
      else if (*pcVar12 != '\0') {
        pcVar7[(long)pcVar12 - (long)param_1] = '\0';
        __file = ".";
        if (*pcVar16 != '\0') {
          __file = pcVar16;
        }
        iVar4 = stat(__file,&local_d08);
        if (iVar4 != 0) goto LAB_0010f5c0;
        pcVar7[(long)pcVar12 - (long)param_1] = *pcVar12;
        if ((local_d58 == 0) &&
           (local_d58 = FUN_00111e30(7,0,FUN_001126e0,FUN_00112710,FUN_00112760), local_d58 == 0))
        goto LAB_0010f7d6;
        cVar3 = FUN_00110880(local_d58,pcVar12,&local_d08);
        if (cVar3 != '\0') {
          if (uVar14 == 2) goto LAB_0010f997;
          piVar6 = __errno_location();
          *piVar6 = 0x28;
          goto LAB_0010f5d9;
        }
        FUN_001107f0(local_d58,pcVar12,&local_d08);
      }
      pcVar12 = local_868;
      pcVar8[__n] = '\0';
      sVar15 = strlen(param_1);
      uVar1 = __n + sVar15;
      if (bVar2) {
        local_d18 = (long)param_1 - (long)pcVar12;
        if (local_860 <= uVar1) goto LAB_0010fbc0;
LAB_0010fca9:
        param_1 = pcVar12 + local_d18;
      }
      else if (local_860 <= uVar1) {
LAB_0010fbc0:
        do {
          cVar3 = FUN_00111350(&local_868);
          if (cVar3 == '\0') goto LAB_0010f7d6;
        } while (local_860 <= uVar1);
        pcVar12 = local_868;
        if (bVar2) goto LAB_0010fca9;
      }
      memmove(pcVar12 + __n,param_1,sVar15 + 1);
      pcVar10 = memcpy(pcVar12,pcVar8,__n);
      pcVar5 = pcVar16 + 1;
      param_1 = pcVar12;
      if (*pcVar8 == '/') {
        *pcVar16 = '/';
        cVar11 = *pcVar12;
        bVar2 = true;
      }
      else if (pcVar5 < pcVar7) {
        do {
          pcVar5 = pcVar7 + -1;
          if (pcVar5 == pcVar16) break;
          pcVar12 = pcVar7 + -2;
          pcVar7 = pcVar5;
        } while (*pcVar12 != '/');
        bVar2 = true;
        cVar11 = *pcVar10;
      }
      else {
        bVar2 = true;
        cVar11 = *pcVar12;
        pcVar5 = pcVar7;
      }
      goto LAB_0010f99f;
    }
    if (uVar14 != 2) {
      pcVar12 = param_1;
      if (*param_1 == '/') goto LAB_0010f860;
LAB_0010f942:
      piVar6 = __errno_location();
      bVar17 = *piVar6 != 0x16;
LAB_0010f957:
      if (bVar17) goto LAB_0010f95b;
    }
LAB_0010f997:
    cVar11 = pcVar10[1];
LAB_0010f99f:
    cVar3 = cVar11;
    if (cVar11 == '\0') goto LAB_0010fc55;
    goto joined_r0x0010f6b1;
  }
  if (uVar14 == 2) goto LAB_0010f997;
  pcVar12 = param_1;
  if (*param_1 == '/') {
LAB_0010f860:
    do {
      do {
        pcVar8 = pcVar12;
        cVar3 = pcVar8[1];
        pcVar12 = pcVar8 + 1;
      } while (cVar3 == '/');
      if (cVar3 == '\0') {
LAB_0010fa6e:
        pcVar7[0] = '/';
        pcVar7[1] = '\0';
        iVar4 = faccessat(-100,pcVar16,0,0x200);
        bVar17 = iVar4 != 0;
        goto LAB_0010f957;
      }
      if (cVar3 != '.') break;
      cVar3 = pcVar8[2];
      if (cVar3 == '\0') goto LAB_0010fa6e;
      if (cVar3 == '.') {
        if ((pcVar8[3] == '\0') || (pcVar8[3] == '/')) goto LAB_0010fa6e;
        break;
      }
      pcVar12 = pcVar8 + 2;
    } while (cVar3 == '/');
    if ((param_2 & 4) == 0) goto LAB_0010f942;
  }
  cVar3 = *param_1;
  if (*param_1 != '\0') goto joined_r0x0010f6b1;
  iVar4 = faccessat(-100,pcVar16,0,0x200);
  if (iVar4 == 0) goto LAB_0010f997;
LAB_0010f95b:
  if (((uVar14 == 1) && (piVar6 = __errno_location(), *piVar6 == 2)) &&
     (sVar15 = strspn(param_1,"/"), param_1[sVar15] == '\0')) goto LAB_0010f997;
LAB_0010f5c0:
  if (local_d58 == 0) goto LAB_0010f5e1;
LAB_0010f5d9:
  FUN_00111ff0(local_d58);
LAB_0010f5e1:
  pvVar9 = (void *)0x0;
  goto LAB_0010f5e3;
  while (pcVar5 = pcVar5 + -1, pcVar5 != pcVar16) {
LAB_0010fa55:
    if (pcVar5[-1] == '/') break;
  }
  goto LAB_0010f99f;
LAB_0010fc55:
  pcVar12 = pcVar16 + 1;
LAB_0010f8d9:
  if ((pcVar12 < pcVar5) && (pcVar5[-1] == '/')) {
    if (local_d58 != 0) {
      FUN_00111ff0(local_d58);
    }
LAB_0010f5ae:
    pcVar12 = pcVar5;
    pcVar5 = pcVar12 + -1;
  }
  else {
    pcVar12 = pcVar5 + 1;
    if (local_d58 != 0) {
      FUN_00111ff0(local_d58);
    }
  }
LAB_0010f904:
  *pcVar5 = '\0';
  pvVar9 = malloc((long)pcVar12 - (long)pcVar16);
  if (pvVar9 == (void *)0x0) {
LAB_0010f7d6:
                    // WARNING: Subroutine does not return
    FUN_0011a1c0();
  }
  pvVar9 = memcpy(pvVar9,pcVar16,(long)pcVar12 - (long)pcVar16);
LAB_0010f5e3:
  if (local_458 != local_448) {
    free(local_458);
  }
  if (local_868 != local_858) {
    free(local_868);
  }
LAB_0010f607:
  if (local_c78 != &local_c68) {
    free(local_c78);
  }
  if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
    return pvVar9;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_0010fde0(undefined8 param_1)

{
  DAT_001283f8 = param_1;
  return;
}



void FUN_0010fdf0(undefined1 param_1)

{
  DAT_001283f0 = param_1;
  return;
}



void FUN_0010fe00(void)

{
  int iVar1;
  int *piVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  
  iVar1 = FUN_0011aa70(stdout);
  if (iVar1 == 0) {
LAB_0010fe2c:
    iVar1 = FUN_0011aa70(stderr);
    if (iVar1 == 0) {
      return;
    }
  }
  else {
    if (DAT_001283f0 != '\0') {
      piVar2 = __errno_location();
      if (*piVar2 == 0x20) goto LAB_0010fe2c;
    }
    uVar3 = dcgettext("gnulib","write error",5);
    if (DAT_001283f8 == 0) {
      piVar2 = __errno_location();
      error(0,*piVar2,&DAT_0011d505,uVar3);
    }
    else {
      uVar4 = FUN_001187b0();
      piVar2 = __errno_location();
      error(0,*piVar2,"%s: %s",uVar4,uVar3);
    }
  }
                    // WARNING: Subroutine does not return
  _exit(DAT_001271f8);
}



undefined8 FUN_0010fec0(undefined8 *param_1,char *param_2)

{
  char *pcVar1;
  char cVar2;
  char cVar3;
  size_t sVar4;
  char *pcVar5;
  char *__s;
  
  if ((long)param_1[1] < 1) {
    return 0;
  }
  __s = (char *)*param_1;
  pcVar1 = __s + param_1[1];
  if (__s < pcVar1) {
    cVar2 = *param_2;
    do {
      pcVar5 = param_2;
      cVar3 = cVar2;
      if (cVar2 == *__s) {
        do {
          if (cVar3 == '\0') {
            return 1;
          }
          __s = __s + 1;
          pcVar5 = pcVar5 + 1;
          cVar3 = *pcVar5;
        } while (cVar3 == *__s);
      }
      sVar4 = strlen(__s);
      __s = __s + sVar4 + 1;
    } while (__s < pcVar1);
  }
  return 0;
}



ulong FUN_0010ff50(char *param_1,long param_2,int param_3,undefined8 param_4,uint param_5)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  ulong uVar4;
  undefined8 uVar5;
  code *pcVar6;
  ssize_t sVar7;
  int *piVar8;
  undefined8 uVar9;
  
  if (param_2 != 0) {
    uVar9 = param_4;
    uVar4 = FUN_0010fec0(param_2,param_1);
    if ((char)uVar4 != '\0') {
      return 1;
    }
    if (-1 < *(long *)(param_2 + 8)) {
      return uVar4;
    }
    iVar3 = *(int *)(param_2 + 0x1c);
    uVar5 = FUN_0010ec90(iVar3);
    uVar2 = (uint)CONCAT71((int7)((ulong)uVar5 >> 8),iVar3 == 7) |
            (uint)CONCAT71((int7)((ulong)uVar9 >> 8),iVar3 == 0xd);
    bVar1 = (byte)uVar2 | (byte)uVar5 ^ 1;
    if (bVar1 == 0) {
      return (ulong)CONCAT31((int3)(uVar2 >> 8),bVar1);
    }
  }
  if (param_3 < 0) {
    if ((param_5 & 0x20000) == 0) {
      pcVar6 = lgetxattr;
    }
    else {
      pcVar6 = getxattr;
    }
    iVar3 = (*pcVar6)(param_4,param_1,0,0);
  }
  else {
    sVar7 = fgetxattr(param_3,param_1,(void *)0x0,0);
    iVar3 = (int)sVar7;
  }
  if (-1 < iVar3) {
    return 1;
  }
  piVar8 = __errno_location();
  iVar3 = *piVar8;
  return (ulong)((uint)CONCAT71((int7)((ulong)piVar8 >> 8),iVar3 == 0x22) |
                CONCAT31((int3)((uint)iVar3 >> 8),iVar3 == 7));
}



void FUN_00110030(undefined *param_1)

{
  if ((param_1 != (undefined *)0x0) && (param_1 != &DAT_0011fcb2)) {
    freecon();
    return;
  }
  return;
}



void FUN_00110060(undefined8 *param_1)

{
  if ((void *)*param_1 != (void *)((long)param_1 + 0x1c)) {
    free((void *)*param_1);
  }
  if (((undefined *)param_1[2] != (undefined *)0x0) && ((undefined *)param_1[2] != &DAT_0011fcb2)) {
    freecon();
    return;
  }
  return;
}



ulong FUN_001100a0(int param_1,undefined8 param_2,long *param_3,uint param_4)

{
  char *pcVar1;
  uint *puVar2;
  uint uVar3;
  char cVar4;
  byte bVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  ulong uVar9;
  code *pcVar10;
  char *__list;
  ssize_t sVar11;
  uint uVar12;
  long lVar13;
  uint uVar14;
  size_t __size;
  ulong uVar15;
  uint *puVar16;
  uint uVar17;
  uint uVar18;
  long in_FS_OFFSET;
  code *local_f8;
  int local_e0;
  uint local_d8;
  uint local_d4 [37];
  long local_40;
  
  pcVar1 = (char *)((long)param_3 + 0x1c);
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  piVar8 = __errno_location();
  uVar14 = param_4 & 0x20000;
  local_e0 = *piVar8;
  if (uVar14 == 0) {
    local_f8 = llistxattr;
  }
  else {
    local_f8 = listxattr;
  }
  __size = 0x98;
  __list = pcVar1;
  do {
    *param_3 = (long)__list;
    if (param_1 < 0) {
      uVar9 = (*local_f8)(param_2);
      param_3[1] = uVar9;
    }
    else {
      uVar9 = flistxattr(param_1,__list,__size);
      param_3[1] = uVar9;
    }
    if (0 < (long)uVar9) {
      if ((param_4 & 0x10000) == 0) goto LAB_00110153;
      goto LAB_00110354;
    }
    if (uVar9 == 0) {
      *(undefined4 *)((long)param_3 + 0x1c) = 0;
      if ((param_4 & 0x10000) != 0) {
        *(undefined4 *)(param_3 + 3) = 0x5f;
        param_3[2] = (long)&DAT_0011fcb2;
        goto LAB_00110412;
      }
LAB_00110151:
      uVar9 = 0;
      goto LAB_00110153;
    }
    iVar6 = *piVar8;
    *(int *)((long)param_3 + 0x1c) = iVar6;
    if ((__size == 0x7fffffffffffffff) || (iVar6 != 0x22)) {
      if ((param_4 & 0x10000) == 0) goto LAB_00110153;
      goto LAB_00110457;
    }
    if (param_1 < 0) {
      uVar9 = (*local_f8)(param_2);
    }
    else {
      uVar9 = flistxattr(param_1,(char *)0x0,0);
    }
    if ((long)uVar9 < 1) {
      param_3[1] = uVar9;
      if (uVar9 == 0) {
        *(undefined4 *)((long)param_3 + 0x1c) = 0;
        uVar9 = 0;
        if ((param_4 & 0x10000) == 0) goto LAB_00110151;
        goto LAB_001103de;
      }
      *(int *)((long)param_3 + 0x1c) = *piVar8;
      if ((param_4 & 0x10000) != 0) goto LAB_00110457;
      goto LAB_00110153;
    }
    if (pcVar1 != (char *)*param_3) {
      free((char *)*param_3);
      *param_3 = (long)pcVar1;
    }
    uVar15 = __size + ((long)__size >> 1);
    if (((long)uVar15 < 0) || (uVar15 < (ulong)((long)__size >> 1))) {
      __size = 0x7fffffffffffffff;
    }
    else {
      __size = uVar15;
      if ((long)uVar15 < (long)uVar9) {
        __size = uVar9;
      }
    }
    __list = malloc(__size);
  } while (__list != (char *)0x0);
  *(int *)((long)param_3 + 0x1c) = *piVar8;
  uVar9 = param_3[1];
  if ((param_4 & 0x10000) == 0) {
LAB_00110153:
    *(undefined4 *)(param_3 + 3) = 0x5f;
LAB_0011015a:
    param_3[2] = (long)&DAT_0011fcb2;
LAB_00110165:
    if ((long)uVar9 < 0) {
      iVar6 = *(int *)((long)param_3 + 0x1c);
      cVar4 = FUN_0010ec90(iVar6);
      if ((iVar6 != 7 && iVar6 != 0xd) && (cVar4 == '\x01')) goto LAB_00110418;
    }
    else if (uVar9 == 0) {
LAB_00110412:
      uVar9 = 0;
      iVar6 = local_e0;
LAB_00110418:
      *piVar8 = iVar6;
      uVar9 = uVar9 & 0xffffffff;
      goto LAB_0011041d;
    }
  }
  else {
    if ((long)uVar9 < 1) {
      if (uVar9 != 0) {
LAB_00110457:
        iVar6 = *(int *)((long)param_3 + 0x1c);
        cVar4 = FUN_0010ec90(iVar6);
        if ((iVar6 == 0xd || iVar6 == 7) || (cVar4 != '\x01')) goto LAB_00110480;
        uVar9 = param_3[1];
      }
LAB_001103de:
      *(undefined4 *)(param_3 + 3) = 0x5f;
      goto LAB_0011015a;
    }
LAB_00110354:
    cVar4 = FUN_0010fec0(param_3,"security.selinux");
    if (cVar4 != '\0') {
LAB_00110480:
      if (-1 < param_1) {
        iVar6 = FUN_00118e40(param_1,param_3 + 2);
        if (iVar6 < 0) goto LAB_00110647;
LAB_001104b0:
        if (iVar6 == 0) {
          *(undefined4 *)(param_3 + 3) = 0x5f;
          uVar9 = param_3[1];
        }
        else {
          if (((iVar6 != 10) || (*(long *)param_3[2] != 0x656c6562616c6e75)) ||
             ((short)((long *)param_3[2])[1] != 100)) {
            *(undefined4 *)(param_3 + 3) = 0;
            uVar9 = param_3[1];
            goto LAB_00110165;
          }
          freecon();
          *(undefined4 *)(param_3 + 3) = 0x3d;
          uVar9 = param_3[1];
        }
        goto LAB_0011015a;
      }
      if (uVar14 == 0) {
        pcVar10 = FUN_00118d40;
      }
      else {
        pcVar10 = FUN_00118c40;
      }
      iVar6 = (*pcVar10)(param_2,param_3 + 2);
      if (-1 < iVar6) goto LAB_001104b0;
LAB_00110647:
      iVar6 = *piVar8;
      uVar9 = param_3[1];
      *(int *)(param_3 + 3) = iVar6;
      if (iVar6 != 0) goto LAB_0011015a;
      goto LAB_00110165;
    }
    *(undefined4 *)(param_3 + 3) = 0x5f;
    param_3[2] = (long)&DAT_0011fcb2;
  }
  cVar4 = FUN_0010ff50("system.nfs4_acl",param_3,param_1,param_2);
  if (cVar4 == '\0') {
    cVar4 = FUN_0010ff50("system.posix_acl_access",param_3,param_1,param_2,param_4);
    if (cVar4 != '\0') {
LAB_00110670:
      uVar9 = 1;
      goto LAB_0011041d;
    }
    if ((param_4 & 0xfb) == 0) {
      bVar5 = FUN_0010ff50("system.posix_acl_default",param_3,param_1,param_2,param_4);
      uVar9 = (ulong)bVar5;
      goto LAB_0011041d;
    }
  }
  else {
    if (param_1 < 0) {
      if (uVar14 == 0) {
        pcVar10 = lgetxattr;
      }
      else {
        pcVar10 = getxattr;
      }
      iVar6 = (*pcVar10)(param_2,"system.nfs4_acl",&local_d8,0x98);
    }
    else {
      sVar11 = fgetxattr(param_1,"system.nfs4_acl",&local_d8,0x98);
      iVar6 = (int)sVar11;
    }
    if (-1 < iVar6) {
      lVar13 = (long)iVar6 + -4;
      if (lVar13 < 0) {
LAB_00110600:
        local_e0 = 0x16;
        uVar9 = 0xffffffff;
      }
      else {
        uVar9 = 1;
        uVar14 = local_d8 >> 0x18 | (local_d8 & 0xff0000) >> 8 | (local_d8 & 0xff00) << 8 |
                 local_d8 << 0x18;
        if (uVar14 < 7) {
          if (local_d8 == 0) {
            uVar9 = 0;
          }
          else {
            uVar18 = 0;
            uVar17 = 0;
            puVar16 = local_d4;
            do {
              if (lVar13 + -0x10 < 0) goto LAB_00110600;
              uVar7 = puVar16[3];
              uVar12 = *puVar16;
              puVar2 = puVar16 + 4;
              uVar3 = puVar16[1];
              uVar12 = uVar12 >> 0x18 | (uVar12 & 0xff0000) >> 8 | (uVar12 & 0xff00) << 8 |
                       uVar12 << 0x18;
              uVar9 = (ulong)((uint)((uVar7 & 0x3000000) != 0) +
                             ((uVar7 >> 0x18 | (uVar7 & 0xff0000) >> 8 | (uVar7 & 0xff00) << 8 |
                              uVar7 << 0x18) >> 2));
              if ((1 < uVar12) ||
                 ((((uVar3 >> 0x18 & 0xffffffbf) != 0 || (uVar3 & 0xff0000) != 0) ||
                  (uVar3 & 0xff00) != 0) || (uVar3 & 0xff) != 0)) {
LAB_0011028c:
                uVar9 = 1;
                goto LAB_00110291;
              }
              lVar13 = lVar13 + -0x10 + uVar9 * -4;
              if (lVar13 < 0) goto LAB_00110600;
              if (uVar7 == 0x6000000) {
                if ((*puVar2 != 0x454e574f) || ((short)puVar16[5] != 0x4052)) {
                  if ((*puVar2 != 0x554f5247) || ((short)puVar16[5] != 0x4050)) goto LAB_0011028c;
                  uVar12 = uVar12 | 2;
                }
              }
              else {
                if (((uVar7 != 0x9000000) || (*(long *)(puVar16 + 4) != 0x454e4f5952455645)) ||
                   ((char)puVar16[6] != '@')) goto LAB_0011028c;
                uVar12 = uVar12 | 4;
              }
              uVar7 = 1 << ((byte)uVar12 & 0x1f);
              if ((uVar17 & uVar7) != 0) goto LAB_0011028c;
              uVar18 = uVar18 + 1;
              uVar17 = uVar17 | uVar7;
              puVar16 = puVar2 + uVar9;
            } while (uVar18 < uVar14);
            uVar9 = 0;
          }
        }
      }
LAB_00110291:
      *piVar8 = local_e0;
      goto LAB_0011041d;
    }
    if (*piVar8 == 0x22) goto LAB_00110670;
    if (*piVar8 != 0x3d) {
      bVar5 = FUN_0010ec90();
      uVar9 = (ulong)-(uint)bVar5;
      goto LAB_0011041d;
    }
  }
  uVar9 = 0;
LAB_0011041d:
  if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
    return uVar9;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_00110730(undefined8 param_1,undefined8 param_2,undefined4 param_3)

{
  FUN_001100a0(0xffffffff,param_1,param_2,param_3);
  return;
}



undefined4 FUN_00110750(undefined8 param_1,long param_2)

{
  undefined4 uVar1;
  uint uVar2;
  long in_FS_OFFSET;
  undefined1 *local_c8 [2];
  undefined *local_b8;
  undefined1 local_ac [156];
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  uVar2 = *(uint *)(param_2 + 0x18) >> 0xc & 0xf;
  if ((*(uint *)(param_2 + 0x18) & 0xf000) != 0x4000) {
    uVar2 = (uint)CONCAT11(1,(char)uVar2);
  }
  uVar1 = FUN_001100a0(0xffffffff,param_1,local_c8,uVar2);
  if (local_c8[0] != local_ac) {
    free(local_c8[0]);
  }
  if ((local_b8 != &DAT_0011fcb2) && (local_b8 != (undefined *)0x0)) {
    freecon();
  }
  if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
    return uVar1;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_001107f0(long param_1,undefined8 param_2,undefined8 *param_3)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  
  if (param_1 == 0) {
    return;
  }
  puVar3 = (undefined8 *)FUN_00119d00(0x18);
  uVar4 = FUN_0011a180(param_2);
  uVar1 = *param_3;
  uVar2 = param_3[1];
  *puVar3 = uVar4;
  puVar3[1] = uVar2;
  puVar3[2] = uVar1;
  puVar5 = (undefined8 *)FUN_001124c0(param_1,puVar3);
  if (puVar5 != (undefined8 *)0x0) {
    if (puVar3 != puVar5) {
      FUN_00112760(puVar3);
      return;
    }
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



bool FUN_00110880(long param_1,undefined8 param_2,undefined8 *param_3)

{
  long lVar1;
  long in_FS_OFFSET;
  bool bVar2;
  undefined8 local_28;
  undefined8 local_20;
  undefined8 uStack_18;
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  bVar2 = false;
  if (param_1 != 0) {
    uStack_18 = *param_3;
    local_20 = param_3[1];
    local_28 = param_2;
    lVar1 = FUN_00111b50(param_1,&local_28);
    bVar2 = lVar1 != 0;
  }
  if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
    return bVar2;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_001108e0(uint param_1,undefined1 *param_2)

{
  byte bVar1;
  undefined1 uVar2;
  char cVar3;
  uint uVar4;
  
  uVar2 = 0x2d;
  uVar4 = param_1 & 0xf000;
  if ((((uVar4 != 0x8000) && (uVar2 = 100, uVar4 != 0x4000)) && (uVar2 = 0x62, uVar4 != 0x6000)) &&
     (((uVar2 = 99, uVar4 != 0x2000 && (uVar2 = 0x6c, uVar4 != 0xa000)) &&
      ((uVar2 = 0x70, uVar4 != 0x1000 && (uVar2 = 0x73, uVar4 != 0xc000)))))) {
    uVar2 = 0x3f;
  }
  *param_2 = uVar2;
  param_2[1] = (-((param_1 & 0x100) == 0) & 0xbbU) + 0x72;
  param_2[2] = (-((param_1 & 0x80) == 0) & 0xb6U) + 0x77;
  bVar1 = -((param_1 & 0x40) == 0);
  if ((param_1 & 0x800) == 0) {
    cVar3 = (bVar1 & 0xb5) + 0x78;
  }
  else {
    cVar3 = (bVar1 & 0xe0) + 0x73;
  }
  param_2[3] = cVar3;
  param_2[4] = (-((param_1 & 0x20) == 0) & 0xbbU) + 0x72;
  param_2[5] = (-((param_1 & 0x10) == 0) & 0xb6U) + 0x77;
  bVar1 = -((param_1 & 8) == 0);
  if ((param_1 & 0x400) == 0) {
    cVar3 = (bVar1 & 0xb5) + 0x78;
  }
  else {
    cVar3 = (bVar1 & 0xe0) + 0x73;
  }
  param_2[6] = cVar3;
  param_2[7] = (-((param_1 & 4) == 0) & 0xbbU) + 0x72;
  param_2[8] = (-((param_1 & 2) == 0) & 0xb6U) + 0x77;
  if ((param_1 & 0x200) != 0) {
    param_2[9] = (-((param_1 & 1) == 0) & 0xe0U) + 0x74;
    *(undefined2 *)(param_2 + 10) = 0x20;
    return;
  }
  param_2[9] = (-((param_1 & 1) == 0) & 0xb5U) + 0x78;
  *(undefined2 *)(param_2 + 10) = 0x20;
  return;
}



void FUN_00110a60(long param_1)

{
  FUN_001108e0(*(undefined4 *)(param_1 + 0x18));
  return;
}



void FUN_00110a70(void)

{
  long lVar1;
  
  lVar1 = FUN_00110a90();
  if (lVar1 != 0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void * FUN_00110a90(void *param_1,char *param_2,undefined8 *param_3)

{
  long lVar1;
  long lVar2;
  size_t __n;
  void *__dest;
  undefined1 *puVar3;
  size_t __n_00;
  undefined1 local_39;
  
  lVar1 = thunk_FUN_0010f314();
  lVar2 = FUN_0010f390(lVar1);
  __n_00 = (lVar1 - (long)param_1) + lVar2;
  __n = strlen(param_2);
  if (lVar2 == 0) {
    if (*param_2 == '/') {
      local_39 = 0x2e;
      lVar1 = 1;
      goto LAB_00110b08;
    }
  }
  else if (*(char *)((long)param_1 + (__n_00 - 1)) != '/') {
    local_39 = 0x2f;
    lVar1 = 1;
    if (*param_2 != '/') goto LAB_00110b08;
  }
  local_39 = 0;
  lVar1 = 0;
LAB_00110b08:
  __dest = malloc(__n_00 + 1 + __n + lVar1);
  if (__dest != (void *)0x0) {
    puVar3 = mempcpy(__dest,param_1,__n_00);
    *puVar3 = local_39;
    if (param_3 != (undefined8 *)0x0) {
      *param_3 = puVar3 + lVar1;
    }
    puVar3 = mempcpy(puVar3 + lVar1,param_2,__n);
    *puVar3 = 0;
  }
  return __dest;
}



ulong FUN_00110b80(long param_1,ulong *param_2)

{
  char cVar1;
  ulong uVar2;
  ulong uVar3;
  ulong uVar4;
  ulong uVar5;
  ulong uVar6;
  
  uVar2 = *param_2;
  uVar5 = 0;
  uVar6 = 0;
LAB_00110b95:
  uVar3 = uVar5;
  uVar5 = uVar6;
  if ((long)uVar2 < 0) goto LAB_00110c0c;
  do {
    do {
      if (uVar2 == uVar3) {
LAB_00110c4b:
        *param_2 = uVar3;
        return uVar5;
      }
      uVar5 = uVar3 + 1;
      uVar4 = uVar3 + 2;
      uVar3 = uVar5;
      uVar6 = uVar5;
    } while (uVar2 <= uVar4);
LAB_00110bc0:
    do {
      if (*(char *)(param_1 + uVar5) != '.') goto LAB_00110b95;
      cVar1 = *(char *)(param_1 + 1 + uVar5);
      if (cVar1 < '[') {
        if (cVar1 < 'A') goto LAB_00110b95;
      }
      else if ((0x19 < (byte)(cVar1 + 0x9fU)) && (cVar1 != '~')) goto LAB_00110b95;
      for (uVar5 = uVar5 + 2; uVar5 < uVar2; uVar5 = uVar5 + 1) {
        cVar1 = *(char *)(param_1 + uVar5);
        if (cVar1 < '[') {
          if ((cVar1 < 'A') && (9 < (byte)(cVar1 - 0x30U))) break;
        }
        else if ((0x19 < (byte)(cVar1 + 0x9fU)) && (cVar1 != '~')) break;
      }
    } while (uVar5 + 1 < uVar2);
    uVar3 = uVar5;
    uVar5 = uVar6;
  } while (-1 < (long)uVar2);
LAB_00110c0c:
  do {
    if (*(char *)(param_1 + uVar3) == '\0') goto LAB_00110c4b;
    uVar5 = uVar3 + 1;
    uVar4 = uVar3 + 2;
    uVar3 = uVar5;
    uVar6 = uVar5;
  } while (uVar2 <= uVar4);
  goto LAB_00110bc0;
}



int FUN_00110c60(long param_1,long param_2,long param_3,long param_4)

{
  byte bVar1;
  long lVar2;
  long lVar3;
  uint uVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  
  lVar2 = 0;
  lVar3 = 0;
LAB_00110c69:
  if (lVar2 < param_2) goto LAB_00110c80;
LAB_00110c6e:
  if (param_4 <= lVar3) {
    return 0;
  }
  if (param_2 <= lVar2) goto LAB_00110d19;
LAB_00110c80:
  uVar4 = (uint)*(byte *)(param_1 + lVar2);
  if ((int)(char)*(byte *)(param_1 + lVar2) - 0x30U < 10) goto LAB_00110d19;
  do {
    cVar5 = (char)uVar4;
    if (cVar5 < '[') {
      if (cVar5 < 'A') goto LAB_00110cab;
LAB_00110d96:
      iVar7 = (int)cVar5;
      if (lVar3 == param_4) {
        return iVar7 + 1;
      }
      bVar1 = *(byte *)(param_3 + lVar3);
      uVar4 = (uint)bVar1;
      if (bVar1 - 0x30 < 10) {
        return iVar7;
      }
      if ('Z' < (char)bVar1) {
        if ((byte)(bVar1 + 0x9f) < 0x1a) goto LAB_00110f4e;
        goto LAB_00110cf3;
      }
      if ('@' < (char)bVar1) {
LAB_00110f4e:
        iVar6 = (int)(char)bVar1;
        goto LAB_00110d03;
      }
      if (bVar1 != 0x7e) {
        iVar6 = bVar1 + 0x100;
        goto LAB_00110d7b;
      }
LAB_00110fbe:
      iVar6 = -2;
      goto LAB_00110d7b;
    }
    if ((byte)(cVar5 + 0x9fU) < 0x1a) goto LAB_00110d96;
LAB_00110cab:
    if (cVar5 == '~') {
      if (lVar3 == param_4) {
        return -1;
      }
      bVar1 = *(byte *)(param_3 + lVar3);
      if (bVar1 - 0x30 < 10) {
        return -2;
      }
      if ((char)bVar1 < '[') {
        if ((char)bVar1 < 'A') {
LAB_00110ff7:
          iVar6 = bVar1 + 0x100;
          iVar7 = -2;
          goto LAB_00110d7b;
        }
      }
      else if (0x19 < (byte)(bVar1 + 0x9f)) {
        if (bVar1 != 0x7e) goto LAB_00110ff7;
        goto LAB_00110d08;
      }
      iVar6 = (int)(char)bVar1;
      iVar7 = -2;
      goto LAB_00110d7b;
    }
    iVar7 = uVar4 + 0x100;
    if (lVar3 == param_4) {
      return uVar4 + 0x101;
    }
    bVar1 = *(byte *)(param_3 + lVar3);
    uVar4 = (uint)bVar1;
    if (bVar1 - 0x30 < 10) {
      return iVar7;
    }
    if ((char)bVar1 < '[') {
      if ('@' < (char)bVar1) {
LAB_00110f2e:
        iVar6 = (int)(char)bVar1;
        goto LAB_00110d7b;
      }
    }
    else if ((byte)(bVar1 + 0x9f) < 0x1a) goto LAB_00110f2e;
LAB_00110cf3:
    if ((char)uVar4 == '~') goto LAB_00110fbe;
    iVar6 = uVar4 + 0x100;
LAB_00110d03:
    if (iVar6 != iVar7) goto LAB_00110d7b;
LAB_00110d08:
    lVar2 = lVar2 + 1;
    lVar3 = lVar3 + 1;
    if (lVar2 < param_2) goto LAB_00110c80;
LAB_00110d19:
    if (param_4 <= lVar3) {
      if (lVar2 < param_2) break;
      goto LAB_00110c6e;
    }
    bVar1 = *(byte *)(param_3 + lVar3);
    iVar6 = (int)(char)bVar1;
    if (iVar6 - 0x30U < 10) {
      if (lVar2 < param_2) break;
      goto LAB_00110ec0;
    }
    if (lVar2 == param_2) {
      if ((char)bVar1 < '[') {
        if ((char)bVar1 < 'A') {
LAB_00110f9a:
          iVar6 = bVar1 + 0x100;
        }
      }
      else if (0x19 < (byte)(bVar1 + 0x9f)) {
        if (bVar1 == 0x7e) {
          iVar7 = -1;
          goto LAB_00110fbe;
        }
        goto LAB_00110f9a;
      }
      iVar7 = -1;
      goto LAB_00110d7b;
    }
    uVar4 = (uint)*(byte *)(param_1 + lVar2);
    if (uVar4 - 0x30 < 10) {
      if ((char)bVar1 < '[') {
        if ((char)bVar1 < 'A') goto LAB_00110d71;
      }
      else if (0x19 < (byte)(bVar1 + 0x9f)) {
        if (bVar1 == 0x7e) {
          iVar7 = 0;
          iVar6 = -2;
          goto LAB_00110d7b;
        }
LAB_00110d71:
        iVar6 = bVar1 + 0x100;
      }
      iVar7 = 0;
LAB_00110d7b:
      return iVar7 - iVar6;
    }
  } while( true );
LAB_00110dfd:
  if (*(char *)(param_1 + lVar2) != '0') goto code_r0x00110e03;
  lVar2 = lVar2 + 1;
  if (param_2 == lVar2) goto LAB_00110ec0;
  goto LAB_00110dfd;
code_r0x00110e03:
  if (lVar3 < param_4) goto LAB_00110e1d;
  if (lVar2 < param_2) goto LAB_00110f6e;
  goto LAB_00110c6e;
LAB_00110ec0:
  if (lVar3 < param_4) goto LAB_00110e1d;
  goto LAB_00110c69;
  while (lVar3 = lVar3 + 1, param_4 != lVar3) {
LAB_00110e1d:
    if (*(char *)(param_3 + lVar3) != '0') {
      if (lVar3 < param_4) {
        if (lVar2 < param_2) {
          iVar7 = 0;
          goto LAB_00110e43;
        }
        if ((int)*(char *)(param_3 + lVar3) - 0x30U < 10) {
          return -1;
        }
        goto LAB_00110c69;
      }
      break;
    }
  }
  if (lVar2 < param_2) {
LAB_00110f6e:
    if ((int)*(char *)(param_1 + lVar2) - 0x30U < 10) {
      return 1;
    }
  }
  goto LAB_00110c69;
  while( true ) {
    if (9 < (int)*(char *)(param_3 + lVar3) - 0x30U) {
      if (lVar2 < param_2) {
        return 1;
      }
      goto LAB_00110e94;
    }
    if (iVar7 == 0) {
      iVar7 = (int)*(char *)(param_1 + lVar2) - (int)*(char *)(param_3 + lVar3);
    }
    lVar2 = lVar2 + 1;
    lVar3 = lVar3 + 1;
    if (param_2 <= lVar2) goto LAB_00110e94;
    if (param_4 <= lVar3) break;
LAB_00110e43:
    if (9 < (int)*(char *)(param_1 + lVar2) - 0x30U) break;
  }
  if ((lVar2 < param_2) && ((int)*(char *)(param_1 + lVar2) - 0x30U < 10)) {
    return 1;
  }
LAB_00110e94:
  if ((lVar3 < param_4) && ((int)*(char *)(param_3 + lVar3) - 0x30U < 10)) {
    return -1;
  }
  if (iVar7 != 0) {
    return iVar7;
  }
  goto LAB_00110c69;
}



ulong FUN_00111080(char *param_1,long param_2,char *param_3,long param_4)

{
  long lVar1;
  long lVar2;
  ulong uVar3;
  bool bVar4;
  bool bVar5;
  long local_30;
  long local_28;
  
  bVar4 = param_2 == 0;
  if (param_2 < 0) {
    bVar4 = *param_1 == '\0';
  }
  bVar5 = param_4 == 0;
  if (param_4 < 0) {
    bVar5 = *param_3 == '\0';
  }
  if (!bVar4) {
    if (bVar5 != false) {
      return 1;
    }
    if (*param_1 == '.') {
      if (*param_3 != '.') {
        return 0xffffffff;
      }
      bVar4 = param_2 == 1;
      if (param_2 < 0) {
        bVar4 = param_1[1] == '\0';
      }
      bVar5 = param_4 == 1;
      if (param_4 < 0) {
        bVar5 = param_3[1] == '\0';
      }
      if (bVar4) goto LAB_00111158;
      if (bVar5 != false) {
        return 1;
      }
      if (param_1[1] == '.') {
        if (param_2 < 0) {
          if (param_1[2] == '\0') goto LAB_001111fb;
        }
        else if (param_2 == 2) {
LAB_001111fb:
          if (param_3[1] != '.') {
            return 0xffffffff;
          }
          if (-1 < param_4) {
            return (ulong)((param_4 == 2) - 1);
          }
          return (ulong)-(uint)(param_3[2] != '\0');
        }
      }
      if (param_3[1] == '.') {
        if (param_4 < 0) {
          if (param_3[2] == '\0') {
            return 1;
          }
        }
        else if (param_4 == 2) {
          return 1;
        }
      }
    }
    else if (*param_3 == '.') {
      return 1;
    }
    local_30 = param_4;
    local_28 = param_2;
    lVar1 = FUN_00110b80(param_1,&local_28);
    lVar2 = FUN_00110b80(param_3,&local_30);
    bVar4 = local_28 != lVar1;
    bVar5 = local_30 != lVar2;
    uVar3 = FUN_00110c60(param_1,lVar1,param_3,lVar2);
    if (((int)uVar3 == 0) && (bVar4 || bVar5)) {
      uVar3 = FUN_00110c60();
    }
    return uVar3;
  }
LAB_00111158:
  return (ulong)(bVar5 - 1);
}



void FUN_00111250(undefined8 param_1,undefined8 param_2)

{
  FUN_00111080(param_1,0xffffffffffffffff,param_2,0xffffffffffffffff);
  return;
}



undefined8 FUN_00111270(void)

{
  return program_invocation_short_name;
}



void FUN_00111280(timespec *param_1)

{
  clock_gettime(0,param_1);
  return;
}



__time_t FUN_00111290(void)

{
  long in_FS_OFFSET;
  timespec local_28;
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  clock_gettime(0,&local_28);
  if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
    return local_28.tv_sec;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



undefined8 FUN_001112e0(long *param_1)

{
  ulong uVar1;
  void *pvVar2;
  long *plVar3;
  int *piVar4;
  undefined8 uVar5;
  ulong __size;
  
  uVar1 = param_1[1];
  plVar3 = param_1 + 2;
  __size = uVar1 * 2;
  if ((void *)*param_1 != plVar3) {
    free((void *)*param_1);
    uVar1 = param_1[1];
  }
  if (__size < uVar1) {
    piVar4 = __errno_location();
    *piVar4 = 0xc;
  }
  else {
    pvVar2 = malloc(__size);
    if (pvVar2 != (void *)0x0) {
      uVar5 = 1;
      plVar3 = pvVar2;
      goto LAB_0011131f;
    }
  }
  __size = 0x400;
  uVar5 = 0;
LAB_0011131f:
  *param_1 = (long)plVar3;
  param_1[1] = __size;
  return uVar5;
}



undefined8 FUN_00111350(long *param_1)

{
  ulong __n;
  ulong __size;
  void *pvVar1;
  void *__dest;
  int *piVar2;
  size_t __size_00;
  
  __n = param_1[1];
  pvVar1 = (void *)*param_1;
  __size = __n * 2;
  if (pvVar1 == param_1 + 2) {
    __dest = malloc(__size);
    if (__dest != (void *)0x0) {
      pvVar1 = memcpy(__dest,pvVar1,__n);
LAB_00111395:
      *param_1 = (long)pvVar1;
      param_1[1] = __size;
      return 1;
    }
  }
  else {
    if (__size < __n) {
      piVar2 = __errno_location();
      *piVar2 = 0xc;
    }
    else {
      __size_00 = 1;
      if (__size != 0) {
        __size_00 = __size;
      }
      pvVar1 = realloc(pvVar1,__size_00);
      if (pvVar1 != (void *)0x0) goto LAB_00111395;
      pvVar1 = (void *)*param_1;
    }
    free(pvVar1);
    *param_1 = (long)(param_1 + 2);
    param_1[1] = 0x400;
  }
  return 0;
}



undefined8 FUN_00111400(undefined8 param_1)

{
  int iVar1;
  undefined8 uVar2;
  long in_FS_OFFSET;
  int local_118;
  short local_114;
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  iVar1 = thunk_FUN_00118f70(param_1,&local_118,0x101);
  uVar2 = 0;
  if (((iVar1 == 0) && ((short)local_118 != 0x43)) &&
     ((local_118 != 0x49534f50 || (uVar2 = 0, local_114 != 0x58)))) {
    uVar2 = 1;
  }
  if (local_10 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return uVar2;
}



ulong FUN_00111480(ulong param_1,ulong param_2)

{
  return (param_1 >> 3 | param_1 << 0x3d) % param_2;
}



bool FUN_001114a0(long param_1,long param_2)

{
  return param_2 == param_1;
}



undefined8 FUN_001114b0(long param_1)

{
  float fVar1;
  float *pfVar2;
  float fVar3;
  
  pfVar2 = *(float **)(param_1 + 0x28);
  if (pfVar2 == (float *)&DAT_0011fcc0) {
    return 1;
  }
  fVar1 = pfVar2[2];
  if ((((0.1 < fVar1) && (fVar1 < 0.9)) && (1.1 < pfVar2[3])) && (0.0 <= *pfVar2)) {
    fVar3 = *pfVar2 + 0.1;
    if (((fVar3 < pfVar2[1]) && (pfVar2[1] <= 1.0)) && (fVar3 < fVar1)) {
      return 1;
    }
  }
  *(undefined **)(param_1 + 0x28) = &DAT_0011fcc0;
  return 0;
}



long FUN_00111540(long *param_1,long param_2,undefined8 *param_3,char param_4)

{
  long *plVar1;
  long lVar2;
  long lVar3;
  char cVar4;
  ulong uVar5;
  long *plVar6;
  long *plVar7;
  
  uVar5 = (*(code *)param_1[6])(param_2,param_1[2]);
  if ((ulong)param_1[2] <= uVar5) {
                    // WARNING: Subroutine does not return
    abort();
  }
  plVar7 = (long *)(uVar5 * 0x10 + *param_1);
  *param_3 = plVar7;
  if (*plVar7 == 0) {
    return 0;
  }
  if (*plVar7 != param_2) {
    cVar4 = (*(code *)param_1[7])(param_2);
    if (cVar4 == '\0') {
      plVar1 = (long *)plVar7[1];
      while( true ) {
        if (plVar1 == (long *)0x0) {
          return 0;
        }
        if (*plVar1 == param_2) break;
        cVar4 = (*(code *)param_1[7])(param_2);
        plVar6 = (long *)plVar7[1];
        if (cVar4 != '\0') goto LAB_001115d0;
        plVar1 = (long *)plVar6[1];
        plVar7 = plVar6;
      }
      plVar6 = (long *)plVar7[1];
LAB_001115d0:
      lVar2 = *plVar6;
      if (param_4 != '\0') {
        plVar7[1] = plVar6[1];
        lVar3 = param_1[9];
        *plVar6 = 0;
        plVar6[1] = lVar3;
        param_1[9] = (long)plVar6;
      }
      return lVar2;
    }
    param_2 = *plVar7;
  }
  if (param_4 != '\0') {
    plVar1 = (long *)plVar7[1];
    if (plVar1 == (long *)0x0) {
      *plVar7 = 0;
    }
    else {
      lVar3 = plVar1[1];
      lVar2 = param_1[9];
      *plVar7 = *plVar1;
      plVar7[1] = lVar3;
      *plVar1 = 0;
      plVar1[1] = lVar2;
      param_1[9] = (long)plVar1;
    }
  }
  return param_2;
}



ulong FUN_00111660(float param_1,ulong param_2,char param_3)

{
  int *piVar1;
  ulong uVar2;
  ulong uVar3;
  ulong uVar4;
  long lVar5;
  
  if (param_3 == '\0') {
    param_1 = (float)param_2 / param_1;
    if (1.8446744e+19 <= param_1) goto LAB_00111714;
    if (param_1 < 9.223372e+18) {
      param_2 = (ulong)param_1;
    }
    else {
      param_2 = (long)(param_1 - 9.223372e+18) ^ 0x8000000000000000;
    }
  }
  uVar3 = 10;
  if (9 < param_2) {
    uVar3 = param_2;
  }
  for (uVar3 = uVar3 | 1; uVar3 != 0xffffffffffffffff; uVar3 = uVar3 + 2) {
    lVar5 = 0x10;
    uVar4 = 9;
    uVar2 = 3;
    do {
      if (uVar3 % uVar2 == 0) goto LAB_0011170a;
      uVar4 = uVar4 + lVar5;
      uVar2 = uVar2 + 2;
      lVar5 = lVar5 + 8;
    } while (uVar4 < uVar3);
    if (uVar3 % uVar2 != 0) {
      if (((uVar3 >> 0x3c & 1) == 0) && (uVar3 >> 0x3d == 0)) {
        return uVar3;
      }
      break;
    }
LAB_0011170a:
  }
LAB_00111714:
  piVar1 = __errno_location();
  *piVar1 = 0xc;
  return 0;
}



undefined8 FUN_00111770(long *param_1,undefined8 *param_2,char param_3)

{
  long lVar1;
  ulong uVar2;
  long *plVar3;
  ulong uVar4;
  long *plVar5;
  long lVar6;
  long *plVar7;
  long *plVar8;
  
  plVar7 = (long *)*param_2;
  if ((long *)param_2[1] <= plVar7) {
    return 1;
  }
  do {
    while (lVar6 = *plVar7, lVar6 == 0) {
LAB_001117a0:
      plVar7 = plVar7 + 2;
      if ((long *)param_2[1] <= plVar7) {
        return 1;
      }
    }
    if ((long *)plVar7[1] != (long *)0x0) {
      uVar4 = param_1[2];
      plVar8 = (long *)plVar7[1];
      do {
        lVar6 = *plVar8;
        uVar2 = (*(code *)param_1[6])(lVar6,uVar4);
        uVar4 = param_1[2];
        if (uVar4 <= uVar2) goto <EXTERNAL>_abort;
        plVar3 = (long *)(uVar2 * 0x10 + *param_1);
        plVar5 = (long *)plVar8[1];
        if (*plVar3 == 0) {
          *plVar3 = lVar6;
          lVar6 = param_1[9];
          param_1[3] = param_1[3] + 1;
          *plVar8 = 0;
          plVar8[1] = lVar6;
          param_1[9] = (long)plVar8;
        }
        else {
          plVar8[1] = plVar3[1];
          plVar3[1] = (long)plVar8;
        }
        plVar8 = plVar5;
      } while (plVar5 != (long *)0x0);
      lVar6 = *plVar7;
    }
    plVar7[1] = 0;
    if (param_3 != '\0') goto LAB_001117a0;
    uVar4 = (*(code *)param_1[6])(lVar6,param_1[2]);
    if ((ulong)param_1[2] <= uVar4) {
<EXTERNAL>_abort:
                    // WARNING: Subroutine does not return
      abort();
    }
    plVar8 = (long *)(uVar4 * 0x10 + *param_1);
    if (*plVar8 == 0) {
      *plVar8 = lVar6;
      param_1[3] = param_1[3] + 1;
    }
    else {
      plVar5 = (long *)param_1[9];
      if (plVar5 == (long *)0x0) {
        plVar5 = malloc(0x10);
        if (plVar5 == (long *)0x0) {
          return 0;
        }
      }
      else {
        param_1[9] = plVar5[1];
      }
      lVar1 = plVar8[1];
      *plVar5 = lVar6;
      plVar5[1] = lVar1;
      plVar8[1] = (long)plVar5;
    }
    *plVar7 = 0;
    plVar7 = plVar7 + 2;
    param_2[3] = param_2[3] + -1;
    if ((long *)param_2[1] <= plVar7) {
      return 1;
    }
  } while( true );
}



undefined8 FUN_001118e0(long param_1)

{
  return *(undefined8 *)(param_1 + 0x10);
}



undefined8 FUN_001118f0(long param_1)

{
  return *(undefined8 *)(param_1 + 0x18);
}



undefined8 FUN_00111900(long param_1)

{
  return *(undefined8 *)(param_1 + 0x20);
}



ulong FUN_00111910(undefined8 *param_1)

{
  long lVar1;
  long *plVar2;
  ulong uVar3;
  ulong uVar4;
  
  plVar2 = (long *)*param_1;
  uVar4 = 0;
  do {
    if ((long *)param_1[1] <= plVar2) {
      return uVar4;
    }
    while (*plVar2 != 0) {
      uVar3 = 1;
      for (lVar1 = plVar2[1]; lVar1 != 0; lVar1 = *(long *)(lVar1 + 8)) {
        uVar3 = uVar3 + 1;
      }
      if (uVar4 < uVar3) {
        uVar4 = uVar3;
      }
      plVar2 = plVar2 + 2;
      if ((long *)param_1[1] <= plVar2) {
        return uVar4;
      }
    }
    plVar2 = plVar2 + 2;
  } while( true );
}



bool FUN_00111980(undefined8 *param_1)

{
  long lVar1;
  long *plVar2;
  long lVar3;
  long lVar4;
  
  plVar2 = (long *)*param_1;
  lVar3 = 0;
  lVar4 = 0;
  do {
    while( true ) {
      if ((long *)param_1[1] <= plVar2) {
        if (param_1[3] != lVar4) {
          return false;
        }
        return param_1[4] == lVar3;
      }
      if (*plVar2 != 0) break;
LAB_001119a0:
      plVar2 = plVar2 + 2;
    }
    lVar1 = plVar2[1];
    lVar4 = lVar4 + 1;
    lVar3 = lVar3 + 1;
    if (lVar1 == 0) goto LAB_001119a0;
    do {
      lVar1 = *(long *)(lVar1 + 8);
      lVar3 = lVar3 + 1;
    } while (lVar1 != 0);
    plVar2 = plVar2 + 2;
  } while( true );
}



void FUN_001119f0(undefined8 *param_1,undefined8 param_2)

{
  ulong uVar1;
  ulong uVar2;
  long lVar3;
  long *plVar4;
  ulong uVar5;
  ulong uVar6;
  
  uVar6 = 0;
  uVar1 = param_1[2];
  uVar2 = param_1[3];
  for (plVar4 = (long *)*param_1; plVar4 < (long *)param_1[1]; plVar4 = plVar4 + 2) {
    while (*plVar4 == 0) {
      plVar4 = plVar4 + 2;
      if ((long *)param_1[1] <= plVar4) goto LAB_00111a5d;
    }
    uVar5 = 1;
    for (lVar3 = plVar4[1]; lVar3 != 0; lVar3 = *(long *)(lVar3 + 8)) {
      uVar5 = uVar5 + 1;
    }
    if (uVar6 < uVar5) {
      uVar6 = uVar5;
    }
  }
LAB_00111a5d:
  __fprintf_chk(param_2,1,"# entries:         %lu\n",param_1[4]);
  __fprintf_chk(param_2,1,"# buckets:         %lu\n",uVar1);
  __fprintf_chk(((double)uVar2 * 100.0) / (double)uVar1,param_2,1,
                "# buckets used:    %lu (%.2f%%)\n",uVar2);
  __fprintf_chk(param_2,1,"max bucket length: %lu\n",uVar6);
  return;
}



long FUN_00111b50(long *param_1,long param_2)

{
  char cVar1;
  ulong uVar2;
  long *plVar3;
  long lVar4;
  
  uVar2 = (*(code *)param_1[6])(param_2,param_1[2]);
  if ((ulong)param_1[2] <= uVar2) {
                    // WARNING: Subroutine does not return
    abort();
  }
  plVar3 = (long *)(uVar2 * 0x10 + *param_1);
  lVar4 = *plVar3;
  if (lVar4 != 0) {
    while( true ) {
      if (param_2 == lVar4) {
        return lVar4;
      }
      cVar1 = (*(code *)param_1[7])(param_2);
      if (cVar1 != '\0') {
        return *plVar3;
      }
      plVar3 = (long *)plVar3[1];
      if (plVar3 == (long *)0x0) break;
      lVar4 = *plVar3;
    }
  }
  return 0;
}



long FUN_00111be0(ulong *param_1)

{
  long lVar1;
  long *plVar2;
  
  if (param_1[4] == 0) {
    return 0;
  }
  plVar2 = (long *)*param_1;
  if ((long *)param_1[1] <= plVar2) {
    lVar1 = FUN_00104b8c();
    return lVar1;
  }
  do {
    if (*plVar2 != 0) {
      return *plVar2;
    }
    plVar2 = plVar2 + 2;
  } while (plVar2 < (long *)param_1[1]);
  lVar1 = FUN_00104b8c();
  return lVar1;
}



long FUN_00111c30(long *param_1,long param_2)

{
  long lVar1;
  ulong uVar2;
  long *plVar3;
  long *plVar4;
  
  uVar2 = (*(code *)param_1[6])(param_2,param_1[2]);
  if ((ulong)param_1[2] <= uVar2) {
                    // WARNING: Subroutine does not return
    abort();
  }
  plVar3 = (long *)(uVar2 * 0x10 + *param_1);
  plVar4 = plVar3;
  do {
    lVar1 = *plVar4;
    plVar4 = (long *)plVar4[1];
    if (lVar1 == param_2) {
      if (plVar4 != (long *)0x0) {
        return *plVar4;
      }
      break;
    }
  } while (plVar4 != (long *)0x0);
  do {
    plVar3 = plVar3 + 2;
    if ((long *)param_1[1] <= plVar3) {
      return 0;
    }
  } while (*plVar3 == 0);
  return *plVar3;
}



void FUN_00111ce0(undefined8 *param_1,long param_2,ulong param_3)

{
  ulong *puVar1;
  ulong *puVar2;
  ulong uVar3;
  ulong *puVar4;
  
  puVar4 = (ulong *)*param_1;
  uVar3 = 0;
  if ((ulong)param_1[1] <= puVar4) {
    return;
  }
  do {
    puVar2 = puVar4;
    puVar1 = (ulong *)*puVar4;
    while (puVar1 != (ulong *)0x0) {
      if (param_3 <= uVar3) {
        return;
      }
      uVar3 = uVar3 + 1;
      *(ulong *)(param_2 + -8 + uVar3 * 8) = *puVar2;
      puVar2 = (ulong *)puVar2[1];
      puVar1 = puVar2;
    }
    puVar4 = puVar4 + 2;
  } while (puVar4 < (ulong *)param_1[1]);
  return;
}



long FUN_00111d40(ulong *param_1,code *param_2,undefined8 param_3)

{
  char cVar1;
  long *plVar2;
  long lVar3;
  long lVar4;
  long *plVar5;
  
  plVar5 = (long *)*param_1;
  if (plVar5 < (long *)param_1[1]) {
    lVar3 = 0;
    do {
      lVar4 = *plVar5;
      plVar2 = plVar5;
      if (lVar4 != 0) {
        while( true ) {
          cVar1 = (*param_2)(lVar4,param_3);
          if (cVar1 == '\0') {
            return lVar3;
          }
          plVar2 = (long *)plVar2[1];
          lVar3 = lVar3 + 1;
          if (plVar2 == (long *)0x0) break;
          lVar4 = *plVar2;
        }
      }
      plVar5 = plVar5 + 2;
    } while (plVar5 < (long *)param_1[1]);
  }
  else {
    lVar3 = 0;
  }
  return lVar3;
}



ulong FUN_00111dc0(byte *param_1,ulong param_2)

{
  byte bVar1;
  ulong uVar2;
  
  uVar2 = 0;
  bVar1 = *param_1;
  while (bVar1 != 0) {
    param_1 = param_1 + 1;
    uVar2 = (uVar2 * 0x1f + (ulong)bVar1) % param_2;
    bVar1 = *param_1;
  }
  return uVar2;
}



void FUN_00111e10(undefined8 *param_1)

{
  *(undefined1 *)(param_1 + 2) = 0;
  *param_1 = 0x3f80000000000000;
  param_1[1] = 0x3fb4fdf43f4ccccd;
  return;
}



undefined8 *
FUN_00111e30(undefined8 param_1,undefined *param_2,code *param_3,code *param_4,undefined8 param_5)

{
  char cVar1;
  undefined8 *__ptr;
  size_t __nmemb;
  void *pvVar2;
  int *piVar3;
  
  if (param_3 == (code *)0x0) {
    param_3 = FUN_00111480;
  }
  if (param_4 == (code *)0x0) {
    param_4 = FUN_001114a0;
  }
  __ptr = malloc(0x50);
  if (__ptr != (undefined8 *)0x0) {
    if (param_2 == (undefined *)0x0) {
      param_2 = &DAT_0011fcc0;
    }
    __ptr[5] = param_2;
    cVar1 = FUN_001114b0(__ptr);
    if (cVar1 == '\0') {
      piVar3 = __errno_location();
      *piVar3 = 0x16;
    }
    else {
      __nmemb = FUN_00111660(param_1,param_2[0x10]);
      __ptr[2] = __nmemb;
      if (__nmemb != 0) {
        pvVar2 = calloc(__nmemb,0x10);
        *__ptr = pvVar2;
        if (pvVar2 != (void *)0x0) {
          __ptr[6] = param_3;
          __ptr[7] = param_4;
          __ptr[1] = (void *)((long)pvVar2 + __nmemb * 0x10);
          __ptr[8] = param_5;
          __ptr[9] = 0;
          *(undefined1 (*) [16])(__ptr + 3) = (undefined1  [16])0x0;
          return __ptr;
        }
      }
    }
    free(__ptr);
  }
  return (undefined8 *)0x0;
}



void FUN_00111f30(undefined8 *param_1)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  code *pcVar4;
  code *pcVar5;
  undefined1 (*pauVar6) [16];
  undefined1 (*pauVar7) [16];
  
  pauVar6 = (undefined1 (*) [16])*param_1;
  if ((undefined1 (*) [16])*param_1 < (undefined1 (*) [16])param_1[1]) {
    do {
      while (*(long *)*pauVar6 != 0) {
        puVar3 = *(undefined8 **)(*pauVar6 + 8);
        pcVar4 = (code *)param_1[8];
        while (puVar3 != (undefined8 *)0x0) {
          pcVar5 = (code *)0x0;
          if (pcVar4 != (code *)0x0) {
            (*pcVar4)(*puVar3);
            pcVar5 = (code *)param_1[8];
          }
          puVar1 = (undefined8 *)puVar3[1];
          uVar2 = param_1[9];
          *puVar3 = 0;
          puVar3[1] = uVar2;
          param_1[9] = puVar3;
          puVar3 = puVar1;
          pcVar4 = pcVar5;
        }
        if (pcVar4 != (code *)0x0) {
          (*pcVar4)(*(undefined8 *)*pauVar6);
        }
        pauVar7 = pauVar6 + 1;
        *pauVar6 = (undefined1  [16])0x0;
        pauVar6 = pauVar7;
        if ((undefined1 (*) [16])param_1[1] <= pauVar7) goto LAB_00111fd4;
      }
      pauVar6 = pauVar6 + 1;
    } while (pauVar6 < (undefined1 (*) [16])param_1[1]);
  }
LAB_00111fd4:
  *(undefined1 (*) [16])(param_1 + 3) = (undefined1  [16])0x0;
  return;
}



void FUN_00111ff0(ulong *param_1)

{
  int iVar1;
  void *pvVar2;
  void *pvVar3;
  int *piVar4;
  long *plVar5;
  long *plVar6;
  long lVar7;
  long *plVar8;
  
  piVar4 = __errno_location();
  iVar1 = *piVar4;
  plVar5 = (long *)param_1[1];
  if ((param_1[8] != 0) && (param_1[4] != 0)) {
    plVar8 = (long *)*param_1;
    if (plVar5 <= plVar8) goto LAB_001120bb;
    do {
      while (lVar7 = *plVar8, plVar6 = plVar8, lVar7 == 0) {
        plVar8 = plVar8 + 2;
        if (plVar5 <= plVar8) goto LAB_00112080;
      }
      while( true ) {
        (*(code *)param_1[8])(lVar7);
        plVar6 = (long *)plVar6[1];
        if (plVar6 == (long *)0x0) break;
        lVar7 = *plVar6;
      }
      plVar5 = (long *)param_1[1];
      plVar8 = plVar8 + 2;
    } while (plVar8 < plVar5);
  }
LAB_00112080:
  plVar8 = (long *)*param_1;
  if (plVar8 < plVar5) {
    do {
      pvVar3 = (void *)plVar8[1];
      while (pvVar3 != (void *)0x0) {
        pvVar2 = *(void **)((long)pvVar3 + 8);
        free(pvVar3);
        pvVar3 = pvVar2;
      }
      plVar8 = plVar8 + 2;
    } while (plVar8 < (long *)param_1[1]);
  }
LAB_001120bb:
  pvVar3 = (void *)param_1[9];
  while (pvVar3 != (void *)0x0) {
    pvVar2 = *(void **)((long)pvVar3 + 8);
    free(pvVar3);
    pvVar3 = pvVar2;
  }
  free((void *)*param_1);
  free(param_1);
  *piVar4 = iVar1;
  return;
}



undefined8 FUN_00112100(undefined8 *param_1,undefined8 param_2)

{
  int iVar1;
  long lVar2;
  void *pvVar3;
  undefined8 uVar4;
  char cVar5;
  size_t sVar6;
  void *pvVar7;
  int *piVar8;
  undefined8 uVar9;
  long in_FS_OFFSET;
  void *local_88;
  void *pvStack_80;
  size_t local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  long local_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  undefined8 local_40;
  long local_30;
  
  lVar2 = param_1[5];
  local_30 = *(long *)(in_FS_OFFSET + 0x28);
  sVar6 = FUN_00111660(param_2,*(undefined1 *)(lVar2 + 0x10));
  if (sVar6 != 0) {
    if (param_1[2] == sVar6) {
LAB_00112273:
      uVar9 = 1;
      goto LAB_00112219;
    }
    pvVar7 = calloc(sVar6,0x10);
    if (pvVar7 != (void *)0x0) {
      local_48 = param_1[8];
      local_58 = param_1[6];
      uStack_50 = param_1[7];
      local_40 = param_1[9];
      pvStack_80 = (void *)((long)pvVar7 + sVar6 * 0x10);
      local_68 = 0;
      uStack_70 = 0;
      local_88 = pvVar7;
      local_78 = sVar6;
      local_60 = lVar2;
      cVar5 = FUN_00111770(&local_88,param_1,0);
      uVar4 = local_40;
      uVar9 = uStack_70;
      sVar6 = local_78;
      pvVar3 = pvStack_80;
      pvVar7 = local_88;
      if (cVar5 != '\0') {
        free((void *)*param_1);
        param_1[9] = uVar4;
        *param_1 = pvVar7;
        param_1[1] = pvVar3;
        param_1[2] = sVar6;
        param_1[3] = uVar9;
        goto LAB_00112273;
      }
      piVar8 = __errno_location();
      iVar1 = *piVar8;
      param_1[9] = uVar4;
      cVar5 = FUN_00111770(param_1,&local_88,1);
      if (cVar5 == '\0') {
<EXTERNAL>_abort:
                    // WARNING: Subroutine does not return
        abort();
      }
      cVar5 = FUN_00111770(param_1,&local_88,0);
      if (cVar5 == '\0') goto <EXTERNAL>_abort;
      free(local_88);
      *piVar8 = iVar1;
    }
  }
  uVar9 = 0;
LAB_00112219:
  if (local_30 == *(long *)(in_FS_OFFSET + 0x28)) {
    return uVar9;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



undefined8 FUN_00112280(long param_1,long param_2,long *param_3)

{
  long lVar1;
  char cVar2;
  long lVar3;
  undefined8 uVar4;
  int *piVar5;
  long *plVar6;
  ulong uVar7;
  long in_FS_OFFSET;
  float fVar8;
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  long *local_38;
  long local_30;
  
  local_30 = *(long *)(in_FS_OFFSET + 0x28);
  if (param_2 == 0) {
                    // WARNING: Subroutine does not return
    abort();
  }
  lVar3 = FUN_00111540(param_1,param_2,&local_38,0);
  if (lVar3 != 0) {
    if (param_3 != (long *)0x0) {
      *param_3 = lVar3;
    }
    uVar4 = 0;
    goto LAB_0011235b;
  }
  uVar7 = *(ulong *)(param_1 + 0x18);
  if ((long)uVar7 < 0) {
    auVar10._4_12_ = SUB1612((undefined1  [16])0x0,4);
    auVar10._0_4_ = (float)uVar7;
  }
  else {
    auVar10._4_12_ = SUB1612((undefined1  [16])0x0,4);
    auVar10._0_4_ = (float)(long)uVar7;
  }
  uVar7 = *(ulong *)(param_1 + 0x10);
  if ((long)uVar7 < 0) {
    auVar9._4_12_ = SUB1612((undefined1  [16])0x0,4);
    auVar9._0_4_ = (float)uVar7;
  }
  else {
    auVar9._4_12_ = SUB1612((undefined1  [16])0x0,4);
    auVar9._0_4_ = (float)(long)uVar7;
  }
  if (*(float *)(*(long *)(param_1 + 0x28) + 8) * auVar9._0_4_ < auVar10._0_4_) {
    FUN_001114b0(param_1);
    lVar3 = *(long *)(param_1 + 0x28);
    if (auVar10._0_4_ <= auVar9._0_4_ * *(float *)(lVar3 + 8)) goto LAB_0011231a;
    fVar8 = auVar9._0_4_ * *(float *)(lVar3 + 0xc);
    if (*(char *)(lVar3 + 0x10) == '\0') {
      fVar8 = fVar8 * *(float *)(lVar3 + 8);
    }
    if (fVar8 < 1.8446744e+19) {
      if (9.223372e+18 <= fVar8) {
        uVar7 = (long)(fVar8 - 9.223372e+18) ^ 0x8000000000000000;
      }
      else {
        uVar7 = (ulong)fVar8;
      }
      cVar2 = FUN_00112100(param_1,uVar7);
      if (cVar2 != '\0') {
        lVar3 = FUN_00111540(param_1,param_2,&local_38,0);
        if (lVar3 != 0) {
                    // WARNING: Subroutine does not return
          abort();
        }
        goto LAB_0011231a;
      }
    }
    else {
      piVar5 = __errno_location();
      *piVar5 = 0xc;
    }
LAB_00112400:
    uVar4 = 0xffffffff;
  }
  else {
LAB_0011231a:
    if (*local_38 == 0) {
      lVar3 = *(long *)(param_1 + 0x18);
      lVar1 = *(long *)(param_1 + 0x20);
      *local_38 = param_2;
      *(long *)(param_1 + 0x18) = lVar3 + 1;
      *(long *)(param_1 + 0x20) = lVar1 + 1;
    }
    else {
      plVar6 = *(long **)(param_1 + 0x48);
      if (plVar6 == (long *)0x0) {
        plVar6 = malloc(0x10);
        if (plVar6 == (long *)0x0) goto LAB_00112400;
      }
      else {
        *(long *)(param_1 + 0x48) = plVar6[1];
      }
      lVar3 = local_38[1];
      *plVar6 = param_2;
      plVar6[1] = lVar3;
      local_38[1] = (long)plVar6;
      *(long *)(param_1 + 0x20) = *(long *)(param_1 + 0x20) + 1;
    }
    uVar4 = 1;
  }
LAB_0011235b:
  if (local_30 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return uVar4;
}



undefined8 FUN_001124c0(undefined8 param_1,undefined8 param_2)

{
  int iVar1;
  long in_FS_OFFSET;
  undefined8 local_18;
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  iVar1 = FUN_00112280(param_1,param_2,&local_18);
  if (iVar1 == -1) {
    param_2 = 0;
  }
  else if (iVar1 == 0) {
    param_2 = local_18;
  }
  if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
    return param_2;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



long FUN_00112530(long param_1,undefined8 param_2)

{
  float *pfVar1;
  void *pvVar2;
  void *__ptr;
  char cVar3;
  long lVar4;
  ulong uVar5;
  ulong uVar6;
  long in_FS_OFFSET;
  float fVar7;
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  long *local_28;
  long local_20;
  
  local_20 = *(long *)(in_FS_OFFSET + 0x28);
  lVar4 = FUN_00111540(param_1,param_2,&local_28,1);
  if ((lVar4 == 0) || (*(long *)(param_1 + 0x20) = *(long *)(param_1 + 0x20) + -1, *local_28 != 0))
  goto LAB_00112571;
  uVar5 = *(long *)(param_1 + 0x18) - 1;
  *(ulong *)(param_1 + 0x18) = uVar5;
  if ((long)uVar5 < 0) {
    uVar6 = *(ulong *)(param_1 + 0x10);
    auVar9._4_12_ = SUB1612((undefined1  [16])0x0,4);
    auVar9._0_4_ = (float)uVar5;
    if ((long)uVar6 < 0) goto LAB_00112686;
LAB_001125c0:
    auVar8._4_12_ = SUB1612((undefined1  [16])0x0,4);
    auVar8._0_4_ = (float)(long)uVar6;
  }
  else {
    auVar9._4_12_ = SUB1612((undefined1  [16])0x0,4);
    auVar9._0_4_ = (float)(long)uVar5;
    uVar6 = *(ulong *)(param_1 + 0x10);
    if (-1 < (long)uVar6) goto LAB_001125c0;
LAB_00112686:
    auVar8._4_12_ = SUB1612((undefined1  [16])0x0,4);
    auVar8._0_4_ = (float)uVar6;
  }
  if (auVar9._0_4_ < **(float **)(param_1 + 0x28) * auVar8._0_4_) {
    FUN_001114b0(param_1);
    pfVar1 = *(float **)(param_1 + 0x28);
    if (auVar9._0_4_ < *pfVar1 * auVar8._0_4_) {
      fVar7 = auVar8._0_4_ * pfVar1[1];
      if (*(char *)(pfVar1 + 4) == '\0') {
        fVar7 = fVar7 * pfVar1[2];
      }
      if (9.223372e+18 <= fVar7) {
        uVar5 = (long)(fVar7 - 9.223372e+18) ^ 0x8000000000000000;
      }
      else {
        uVar5 = (ulong)fVar7;
      }
      cVar3 = FUN_00112100(param_1,uVar5);
      if (cVar3 == '\0') {
        __ptr = *(void **)(param_1 + 0x48);
        while (__ptr != (void *)0x0) {
          pvVar2 = *(void **)((long)__ptr + 8);
          free(__ptr);
          __ptr = pvVar2;
        }
        *(undefined8 *)(param_1 + 0x48) = 0;
      }
    }
  }
LAB_00112571:
  if (local_20 == *(long *)(in_FS_OFFSET + 0x28)) {
    return lVar4;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void thunk_FUN_00112530(void)

{
  FUN_00112530();
  return;
}



ulong FUN_001126e0(undefined8 *param_1,ulong param_2)

{
  ulong uVar1;
  
  uVar1 = FUN_0011ac20(*param_1);
  return (uVar1 ^ param_1[1]) % param_2;
}



bool FUN_00112710(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  
  if (param_1[1] == param_2[1] && param_1[2] == param_2[2]) {
    iVar1 = strcmp((char *)*param_1,(char *)*param_2);
    return iVar1 == 0;
  }
  return false;
}



void FUN_00112760(undefined8 *param_1)

{
  free((void *)*param_1);
  free(param_1);
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

char * FUN_00112780(ulong param_1,char *param_2,uint param_3,ulong param_4,ulong param_5)

{
  byte bVar1;
  bool bVar2;
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  ulong uVar8;
  char cVar9;
  uint uVar10;
  uint uVar11;
  lconv *plVar12;
  size_t sVar13;
  size_t sVar14;
  char *pcVar15;
  ulong uVar16;
  ulong uVar17;
  ulong uVar18;
  long lVar19;
  char cVar20;
  uint uVar21;
  uint uVar22;
  char *pcVar23;
  byte *pbVar24;
  uint uVar25;
  uint uVar26;
  uint uVar27;
  char *pcVar28;
  char *__s;
  int iVar29;
  char *__s_00;
  long in_FS_OFFSET;
  longdouble lVar30;
  longdouble lVar31;
  longdouble lVar32;
  char *local_c0;
  undefined1 local_78 [56];
  long local_40;
  
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  uVar21 = param_3 & 0x20;
  uVar27 = param_3 & 3;
  uVar10 = (-(uint)(uVar21 == 0) & 0xffffffe8) + 0x400;
  plVar12 = localeconv();
  __s_00 = plVar12->decimal_point;
  sVar13 = strlen(__s_00);
  if (0xf < sVar13 - 1) {
    sVar13 = 1;
    __s_00 = ".";
  }
  pbVar24 = (byte *)plVar12->grouping;
  __s = plVar12->thousands_sep;
  sVar14 = strlen(__s);
  if (0x10 < sVar14) {
    __s = "";
  }
  pcVar15 = param_2 + 0x287;
  uVar22 = (uint)sVar13;
  pcVar23 = pcVar15;
  pcVar28 = pcVar15;
  local_c0 = pcVar15;
  if (param_4 < param_5) {
    if ((param_4 == 0) || (uVar17 = param_5 / param_4, param_5 % param_4 != 0)) goto LAB_00112860;
    uVar16 = param_1 / uVar17;
    uVar18 = (param_1 % uVar17) * 10;
    uVar8 = (uVar18 % uVar17) * 2;
    auVar7._8_8_ = uVar8;
    auVar7._0_8_ = uVar16;
    uVar11 = (uint)(uVar18 / uVar17);
    if (uVar8 < uVar17) {
      uVar25 = (uint)(uVar8 != 0);
    }
    else {
      uVar25 = (uVar17 < uVar8) + 2;
    }
    uVar26 = uVar11;
    if ((param_3 & 0x10) == 0) goto LAB_00112f82;
LAB_00112d43:
    uVar16 = auVar7._0_8_;
    uVar17 = (ulong)uVar10;
    iVar29 = 0;
    if (uVar17 <= uVar16) {
      do {
        uVar18 = uVar16 / uVar17;
        uVar26 = uVar11 + (int)(uVar16 % uVar17) * 10;
        uVar11 = uVar26 / uVar10;
        uVar26 = ((int)uVar25 >> 1) + (uVar26 % uVar10) * 2;
        uVar25 = uVar25 + uVar26;
        if (uVar26 < uVar10) {
          uVar25 = (uint)(uVar25 != 0);
        }
        else {
          uVar25 = (uVar10 < uVar25) + 2;
        }
        iVar29 = iVar29 + 1;
        uVar16 = uVar18;
        if (uVar18 < uVar17) {
          if (uVar18 < 10) {
            if (uVar27 == 1) {
              if (2 < (uVar11 & 1) + uVar25) goto LAB_0011322f;
              if (uVar11 != 0) goto LAB_001133a8;
              if ((param_3 & 8) == 0) goto LAB_001132f1;
LAB_001132d3:
              cVar20 = (char)uVar16;
            }
            else {
              if ((uVar27 == 0) && (uVar25 != 0)) {
LAB_0011322f:
                cVar9 = (char)uVar11 + '1';
                if (uVar11 == 9) {
                  uVar16 = uVar18 + 1;
                  if (uVar18 != 9) {
                    uVar18 = uVar16;
                    if ((param_3 & 8) == 0) goto LAB_001132f1;
                    if (uVar27 == 1) goto LAB_001132d3;
                  }
                  goto LAB_00112dc0;
                }
              }
              else if (uVar11 == 0) {
                if ((param_3 & 8) != 0) goto LAB_00112d61;
LAB_001132f1:
                cVar9 = '0';
              }
              else {
LAB_001133a8:
                cVar9 = (char)uVar11 + '0';
              }
              cVar20 = (char)uVar18;
              param_2[0x286] = cVar9;
              pcVar28 = param_2 + (0x286 - sVar13);
              uVar17 = sVar13 & 0xffffffff;
              if (uVar22 < 8) {
                if ((sVar13 & 4) == 0) {
                  if ((uVar22 != 0) && (*pcVar28 = *__s_00, (sVar13 & 2) != 0)) {
                    *(undefined2 *)(param_2 + uVar17 + (0x284 - sVar13)) =
                         *(undefined2 *)(__s_00 + (uVar17 - 2));
                  }
                }
                else {
                  *(undefined4 *)pcVar28 = *(undefined4 *)__s_00;
                  *(undefined4 *)(param_2 + uVar17 + (0x282 - sVar13)) =
                       *(undefined4 *)(__s_00 + (uVar17 - 4));
                }
              }
              else {
                *(undefined8 *)pcVar28 = *(undefined8 *)__s_00;
                *(undefined8 *)(param_2 + (sVar13 & 0xffffffff) + (0x27e - sVar13)) =
                     *(undefined8 *)(__s_00 + ((sVar13 & 0xffffffff) - 8));
                lVar19 = (long)pcVar28 - ((ulong)(param_2 + (0x28e - sVar13)) & 0xfffffffffffffff8);
                uVar27 = (int)lVar19 + uVar22 & 0xfffffff8;
                if (7 < uVar27) {
                  uVar22 = 0;
                  do {
                    uVar17 = (ulong)uVar22;
                    uVar22 = uVar22 + 8;
                    *(undefined8 *)
                     (((ulong)(param_2 + (0x28e - sVar13)) & 0xfffffffffffffff8) + uVar17) =
                         *(undefined8 *)(__s_00 + (uVar17 - lVar19));
                  } while (uVar22 < uVar27);
                }
              }
            }
            goto LAB_001131d6;
          }
          break;
        }
      } while (iVar29 != 10);
    }
LAB_00112d57:
    if (uVar27 == 1) {
      if (5 < (int)((((uint)uVar16 & 1) + uVar25 != 0) + uVar11)) goto LAB_00112d6e;
LAB_00112dc0:
      do {
        pcVar23 = pcVar23 + -1;
        *pcVar23 = (char)uVar16 + (char)(uVar16 / 10) * -10 + '0';
        bVar2 = 9 < uVar16;
        uVar16 = uVar16 / 10;
      } while (bVar2);
      goto joined_r0x00112df6;
    }
LAB_00112d61:
    if ((uVar27 != 0) || ((int)(uVar11 + uVar25) < 1)) goto LAB_00112dc0;
LAB_00112d6e:
    uVar16 = uVar16 + 1;
    if (((param_3 & 0x10) == 0) || ((uVar10 != uVar16 || (iVar29 == 10)))) goto LAB_00112dc0;
    iVar29 = iVar29 + 1;
    cVar20 = '\x01';
    if ((param_3 & 8) == 0) {
      param_2[0x286] = '0';
      pcVar28 = pcVar15 + ~sVar13;
      uVar17 = sVar13 & 0xffffffff;
      if (uVar22 < 8) {
        if ((sVar13 & 4) == 0) {
          if ((uVar22 != 0) && (*pcVar28 = *__s_00, (sVar13 & 2) != 0)) {
            *(undefined2 *)(pcVar28 + (uVar17 - 2)) = *(undefined2 *)(__s_00 + (uVar17 - 2));
          }
        }
        else {
          *(undefined4 *)pcVar28 = *(undefined4 *)__s_00;
          *(undefined4 *)(pcVar28 + (uVar17 - 4)) = *(undefined4 *)(__s_00 + (uVar17 - 4));
        }
      }
      else {
        *(undefined8 *)pcVar28 = *(undefined8 *)__s_00;
        *(undefined8 *)(pcVar28 + ((sVar13 & 0xffffffff) - 8)) =
             *(undefined8 *)(__s_00 + ((sVar13 & 0xffffffff) - 8));
        lVar19 = (long)pcVar28 - ((ulong)(pcVar28 + 8) & 0xfffffffffffffff8);
        uVar27 = (int)lVar19 + uVar22 & 0xfffffff8;
        if (7 < uVar27) {
          uVar22 = 0;
          do {
            uVar17 = (ulong)uVar22;
            uVar22 = uVar22 + 8;
            *(undefined8 *)(((ulong)(pcVar28 + 8) & 0xfffffffffffffff8) + uVar17) =
                 *(undefined8 *)(__s_00 + (uVar17 - lVar19));
          } while (uVar22 < uVar27);
        }
      }
      cVar20 = '\x01';
    }
LAB_001131d6:
    pcVar23 = pcVar28 + -1;
    pcVar28[-1] = cVar20 + '0';
    if ((param_3 & 4) != 0) goto LAB_00112dfc;
    if ((param_3 & 0x80) == 0) goto LAB_00112cb1;
LAB_00112ca6:
    if (iVar29 == 0 && (param_3 & 0x100) == 0) goto LAB_00112cb1;
    if ((param_3 & 0x40) != 0) {
      local_c0 = param_2 + 0x288;
      param_2[0x287] = ' ';
    }
    pcVar15 = local_c0;
    if (iVar29 != 0) {
LAB_00112ff2:
      pcVar15 = local_c0 + 1;
      if ((uVar21 != 0) || (iVar29 != 1)) {
        *local_c0 = (&DAT_0011fce8)[iVar29];
        if ((param_3 & 0x100) == 0) goto LAB_00112cb1;
        if (uVar21 != 0) {
          local_c0[1] = 'i';
          pcVar15 = local_c0 + 2;
        }
        goto LAB_00113091;
      }
      *local_c0 = 'k';
    }
    if ((param_3 & 0x100) == 0) goto LAB_00112cb1;
  }
  else {
    auVar3._8_8_ = 0;
    auVar3._0_8_ = param_5;
    auVar4._8_8_ = 0;
    auVar4._0_8_ = param_4;
    if (param_4 % param_5 == 0) {
      auVar5._8_8_ = 0;
      auVar5._0_8_ = SUB168(auVar4 / auVar3,0);
      auVar6._8_8_ = 0;
      auVar6._0_8_ = param_1;
      auVar7 = auVar5 * auVar6;
      uVar16 = auVar7._0_8_;
      if (auVar7._8_8_ == 0) {
        uVar25 = 0;
        uVar11 = 0;
        uVar26 = 0;
        if ((param_3 & 0x10) != 0) goto LAB_00112d43;
LAB_00112f82:
        iVar29 = -1;
        uVar11 = uVar26;
        goto LAB_00112d57;
      }
    }
LAB_00112860:
    lVar30 = (longdouble)(long)param_4;
    if ((long)param_4 < 0) {
      lVar30 = lVar30 + (longdouble)1.8446744e+19;
    }
    if ((long)param_5 < 0) {
      lVar30 = lVar30 / ((longdouble)(long)param_5 + (longdouble)1.8446744e+19);
      if (-1 < (long)param_1) goto LAB_0011289d;
LAB_00112ad8:
      lVar30 = ((longdouble)(long)param_1 + (longdouble)1.8446744e+19) * lVar30;
      if ((param_3 & 0x10) != 0) goto LAB_001128aa;
LAB_00112bc0:
      iVar29 = -1;
      __sprintf_chk(param_2,1,0xffffffffffffffff,"%.0Lf");
      uVar17 = strlen(param_2);
      sVar13 = uVar17;
    }
    else {
      lVar30 = lVar30 / (longdouble)(long)param_5;
      if ((long)param_1 < 0) goto LAB_00112ad8;
LAB_0011289d:
      lVar30 = (longdouble)(long)param_1 * lVar30;
      if ((param_3 & 0x10) == 0) goto LAB_00112bc0;
LAB_001128aa:
      iVar29 = 0;
      lVar32 = (longdouble)(int)uVar10;
      do {
        lVar31 = lVar32;
        iVar29 = iVar29 + 1;
        lVar32 = lVar31 * (longdouble)(int)uVar10;
        if (lVar30 < lVar32) break;
      } while (iVar29 != 10);
      if ((uVar27 == 1) || (_DAT_0011fc90 <= lVar30 / lVar31)) {
        __sprintf_chk(param_2,1,0xffffffffffffffff,"%.1Lf");
        uVar17 = strlen(param_2);
      }
      else {
        __sprintf_chk(param_2,1,0xffffffffffffffff,"%.1Lf");
        uVar17 = strlen(param_2);
      }
      if ((sVar13 + 2 + (ulong)(uVar21 == 0) < uVar17) ||
         (((param_3 & 8) != 0 && (param_2[uVar17 - 1] == '0')))) {
        __sprintf_chk(param_2,1,0xffffffffffffffff,"%.0Lf");
        uVar17 = strlen(param_2);
        sVar13 = uVar17;
      }
      else {
        sVar13 = uVar17 - (sVar13 + 1);
      }
    }
    pcVar23 = pcVar15 + -uVar17;
    memmove(pcVar23,param_2,uVar17);
    pcVar28 = pcVar23 + sVar13;
joined_r0x00112df6:
    if ((param_3 & 4) != 0) {
LAB_00112dfc:
      sVar13 = strlen(__s);
      uVar16 = (long)pcVar28 - (long)pcVar23;
      __memcpy_chk(local_78,pcVar23,uVar16,0x29);
      uVar17 = 0xffffffffffffffff;
      do {
        bVar1 = *pbVar24;
        if (bVar1 == 0) {
          if (uVar16 < uVar17) {
            uVar17 = uVar16;
          }
        }
        else {
          if (0x7e < bVar1) {
            pcVar23 = pcVar28 + -uVar16;
            memcpy(pcVar23,local_78,uVar16);
            break;
          }
          uVar17 = (long)(char)bVar1;
          if (uVar16 < (ulong)(long)(char)bVar1) {
            uVar17 = uVar16;
          }
          pbVar24 = pbVar24 + 1;
        }
        uVar16 = uVar16 - uVar17;
        pcVar23 = pcVar28 + -uVar17;
        memcpy(pcVar23,local_78 + uVar16,uVar17);
        if (uVar16 == 0) break;
        pcVar28 = pcVar23 + -sVar13;
        memcpy(pcVar28,__s,sVar13);
      } while( true );
    }
    if ((param_3 & 0x80) == 0) goto LAB_00112cb1;
    if (iVar29 != -1) goto LAB_00112ca6;
    if (1 < param_5) {
      iVar29 = 1;
      uVar17 = 1;
      do {
        uVar17 = uVar17 * uVar10;
        if (param_5 <= uVar17) break;
        iVar29 = iVar29 + 1;
      } while (iVar29 != 10);
      if ((param_3 & 0x40) != 0) {
        local_c0 = param_2 + 0x288;
        param_2[0x287] = ' ';
      }
      goto LAB_00112ff2;
    }
    if ((param_3 & 0x100) == 0) goto LAB_00112cb1;
    if ((param_3 & 0x40) != 0) {
      param_2[0x287] = ' ';
      pcVar15 = param_2 + 0x288;
    }
  }
LAB_00113091:
  *pcVar15 = 'B';
  pcVar15 = pcVar15 + 1;
LAB_00112cb1:
  local_c0 = pcVar15;
  *local_c0 = '\0';
  if (local_40 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return pcVar23;
}



undefined8 FUN_00113490(char *param_1,uint *param_2,long *param_3)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  char *pcVar4;
  long lVar5;
  uint uVar6;
  long in_FS_OFFSET;
  char *local_38;
  long local_30;
  
  local_30 = *(long *)(in_FS_OFFSET + 0x28);
  if (((param_1 == (char *)0x0) && (param_1 = getenv("BLOCK_SIZE"), param_1 == (char *)0x0)) &&
     (param_1 = getenv("BLOCKSIZE"), param_1 == (char *)0x0)) {
    pcVar4 = getenv("POSIXLY_CORRECT");
    *param_3 = (ulong)(-(uint)(pcVar4 == (char *)0x0) & 0x200) + 0x200;
    *param_2 = 0;
  }
  else {
    uVar6 = 0;
    if (*param_1 == '\'') {
      param_1 = param_1 + 1;
      uVar6 = 4;
    }
    iVar2 = FUN_0010ee80(param_1,&PTR_s_human_readable_00126980,&DAT_0011fce0,4);
    if (iVar2 < 0) {
      uVar3 = FUN_0011a540(param_1,&local_38,0,param_3,"eEgGkKmMpPtTyYzZ0");
      if ((int)uVar3 == 0) {
        cVar1 = *param_1;
        while (9 < (byte)(cVar1 - 0x30U)) {
          if (local_38 == param_1) {
            if (local_38[-1] == 'B') {
              uVar6 = uVar6 | 0x180;
              if (local_38[-2] != 'i') break;
            }
            else {
              uVar6 = uVar6 | 0x80;
            }
            uVar6 = uVar6 | 0x20;
            break;
          }
          pcVar4 = param_1 + 1;
          param_1 = param_1 + 1;
          cVar1 = *pcVar4;
        }
        lVar5 = *param_3;
        *param_2 = uVar6;
      }
      else {
        *param_2 = 0;
        lVar5 = *param_3;
      }
      if (lVar5 == 0) {
        pcVar4 = getenv("POSIXLY_CORRECT");
        *param_3 = (ulong)(-(uint)(pcVar4 == (char *)0x0) & 0x200) + 0x200;
        uVar3 = 4;
      }
      goto LAB_00113508;
    }
    *param_3 = 1;
    *param_2 = uVar6 | *(uint *)(&DAT_0011fce0 + (long)iVar2 * 4);
  }
  uVar3 = 0;
LAB_00113508:
  if (local_30 == *(long *)(in_FS_OFFSET + 0x28)) {
    return uVar3;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



__uid_t * FUN_00113660(__uid_t param_1)

{
  __uid_t *p_Var1;
  passwd *ppVar2;
  size_t sVar3;
  __uid_t *p_Var4;
  ulong uVar5;
  char *__s;
  
  for (p_Var4 = DAT_00128438; p_Var4 != (__uid_t *)0x0; p_Var4 = *(__uid_t **)(p_Var4 + 2)) {
    if (*p_Var4 == param_1) goto LAB_0011368d;
  }
  __s = "";
  ppVar2 = getpwuid(param_1);
  uVar5 = 0x18;
  if (ppVar2 != (passwd *)0x0) {
    __s = ppVar2->pw_name;
    sVar3 = strlen(__s);
    uVar5 = sVar3 + 0x18 & 0xfffffffffffffff8;
  }
  p_Var4 = (__uid_t *)FUN_00119d00(uVar5);
  *p_Var4 = param_1;
  strcpy((char *)(p_Var4 + 4),__s);
  p_Var1 = p_Var4;
  *(__uid_t **)(p_Var4 + 2) = DAT_00128438;
  DAT_00128438 = p_Var1;
LAB_0011368d:
  p_Var1 = (__uid_t *)0x0;
  if ((char)p_Var4[4] != '\0') {
    p_Var1 = p_Var4 + 4;
  }
  return p_Var1;
}



__uid_t * FUN_00113700(char *param_1)

{
  char cVar1;
  __uid_t *p_Var2;
  int iVar3;
  passwd *ppVar4;
  size_t sVar5;
  __uid_t *p_Var6;
  long lVar7;
  
  if (DAT_00128438 != (__uid_t *)0x0) {
    cVar1 = *param_1;
    p_Var6 = DAT_00128438;
    do {
      if (((char)p_Var6[4] == cVar1) && (iVar3 = strcmp((char *)(p_Var6 + 4),param_1), iVar3 == 0))
      {
        return p_Var6;
      }
      p_Var6 = *(__uid_t **)(p_Var6 + 2);
    } while (p_Var6 != (__uid_t *)0x0);
  }
  if (DAT_00128430 != (__uid_t *)0x0) {
    cVar1 = *param_1;
    lVar7 = (long)DAT_00128430;
    do {
      if ((*(char *)(lVar7 + 0x10) == cVar1) &&
         (iVar3 = strcmp((char *)(lVar7 + 0x10),param_1), iVar3 == 0)) {
        return (__uid_t *)0x0;
      }
      lVar7 = *(long *)(lVar7 + 8);
    } while (lVar7 != 0);
  }
  ppVar4 = getpwnam(param_1);
  sVar5 = strlen(param_1);
  p_Var6 = (__uid_t *)FUN_00119d00(sVar5 + 0x18 & 0xfffffffffffffff8);
  strcpy((char *)(p_Var6 + 4),param_1);
  if (ppVar4 == (passwd *)0x0) {
    *(__uid_t **)(p_Var6 + 2) = DAT_00128430;
    DAT_00128430 = p_Var6;
    return (__uid_t *)0x0;
  }
  *p_Var6 = ppVar4->pw_uid;
  p_Var2 = p_Var6;
  *(__uid_t **)(p_Var6 + 2) = DAT_00128438;
  DAT_00128438 = p_Var2;
  return p_Var6;
}



__gid_t * FUN_00113810(__gid_t param_1)

{
  __gid_t *p_Var1;
  group *pgVar2;
  size_t sVar3;
  __gid_t *p_Var4;
  ulong uVar5;
  char *__s;
  
  for (p_Var4 = DAT_00128428; p_Var4 != (__gid_t *)0x0; p_Var4 = *(__gid_t **)(p_Var4 + 2)) {
    if (*p_Var4 == param_1) goto LAB_0011383d;
  }
  __s = "";
  pgVar2 = getgrgid(param_1);
  uVar5 = 0x18;
  if (pgVar2 != (group *)0x0) {
    __s = pgVar2->gr_name;
    sVar3 = strlen(__s);
    uVar5 = sVar3 + 0x18 & 0xfffffffffffffff8;
  }
  p_Var4 = (__gid_t *)FUN_00119d00(uVar5);
  *p_Var4 = param_1;
  strcpy((char *)(p_Var4 + 4),__s);
  p_Var1 = p_Var4;
  *(__gid_t **)(p_Var4 + 2) = DAT_00128428;
  DAT_00128428 = p_Var1;
LAB_0011383d:
  p_Var1 = (__gid_t *)0x0;
  if ((char)p_Var4[4] != '\0') {
    p_Var1 = p_Var4 + 4;
  }
  return p_Var1;
}



__gid_t * FUN_001138b0(char *param_1)

{
  char cVar1;
  __gid_t *p_Var2;
  int iVar3;
  group *pgVar4;
  size_t sVar5;
  __gid_t *p_Var6;
  long lVar7;
  
  if (DAT_00128428 != (__gid_t *)0x0) {
    cVar1 = *param_1;
    p_Var6 = DAT_00128428;
    do {
      if (((char)p_Var6[4] == cVar1) && (iVar3 = strcmp((char *)(p_Var6 + 4),param_1), iVar3 == 0))
      {
        return p_Var6;
      }
      p_Var6 = *(__gid_t **)(p_Var6 + 2);
    } while (p_Var6 != (__gid_t *)0x0);
  }
  if (DAT_00128420 != (__gid_t *)0x0) {
    cVar1 = *param_1;
    lVar7 = (long)DAT_00128420;
    do {
      if ((*(char *)(lVar7 + 0x10) == cVar1) &&
         (iVar3 = strcmp((char *)(lVar7 + 0x10),param_1), iVar3 == 0)) {
        return (__gid_t *)0x0;
      }
      lVar7 = *(long *)(lVar7 + 8);
    } while (lVar7 != 0);
  }
  pgVar4 = getgrnam(param_1);
  sVar5 = strlen(param_1);
  p_Var6 = (__gid_t *)FUN_00119d00(sVar5 + 0x18 & 0xfffffffffffffff8);
  strcpy((char *)(p_Var6 + 4),param_1);
  if (pgVar4 == (group *)0x0) {
    *(__gid_t **)(p_Var6 + 2) = DAT_00128420;
    DAT_00128420 = p_Var6;
    return (__gid_t *)0x0;
  }
  *p_Var6 = pgVar4->gr_gid;
  p_Var2 = p_Var6;
  *(__gid_t **)(p_Var6 + 2) = DAT_00128428;
  DAT_00128428 = p_Var2;
  return p_Var6;
}



char * FUN_001139c0(long param_1,long param_2)

{
  long lVar1;
  char *pcVar2;
  char *pcVar3;
  
  *(undefined1 *)(param_2 + 0x14) = 0;
  pcVar2 = (char *)(param_2 + 0x14);
  if (param_1 < 0) {
    do {
      pcVar3 = pcVar2;
      lVar1 = param_1 / 10;
      pcVar3[-1] = ((char)lVar1 * '\n' + '0') - (char)param_1;
      param_1 = lVar1;
      pcVar2 = pcVar3 + -1;
    } while (lVar1 != 0);
    pcVar3[-2] = '-';
    return pcVar3 + -2;
  }
  do {
    pcVar2 = pcVar2 + -1;
    lVar1 = param_1 / 10;
    *pcVar2 = (char)param_1 + (char)lVar1 * -10 + '0';
    param_1 = lVar1;
  } while (lVar1 != 0);
  return pcVar2;
}



char * FUN_00113ac0(ulong param_1,long param_2)

{
  bool bVar1;
  char *pcVar2;
  
  *(undefined1 *)(param_2 + 0x14) = 0;
  pcVar2 = (char *)(param_2 + 0x14);
  do {
    pcVar2 = pcVar2 + -1;
    *pcVar2 = (char)param_1 + (char)(param_1 / 10) * -10 + '0';
    bVar1 = 9 < param_1;
    param_1 = param_1 / 10;
  } while (bVar1);
  return pcVar2;
}



ulong FUN_00113b30(uint *param_1,byte *param_2,long param_3,mbstate_t *param_4)

{
  char cVar1;
  int iVar2;
  ulong uVar3;
  byte *pbVar4;
  uint *puVar5;
  long lVar6;
  
  pbVar4 = &DAT_0011cf4c;
  puVar5 = (uint *)0x0;
  lVar6 = 1;
  if (param_2 != (byte *)0x0) {
    pbVar4 = param_2;
    puVar5 = param_1;
    lVar6 = param_3;
  }
  if (param_4 == (mbstate_t *)0x0) {
    param_4 = (mbstate_t *)&DAT_00128440;
  }
  uVar3 = mbrtoc32(puVar5,pbVar4,lVar6,param_4);
  if (uVar3 < 0xfffffffffffffffd) {
    iVar2 = mbsinit(param_4);
    if (iVar2 == 0) {
      param_4->__count = 0;
      param_4->__value = (_union_27)0x0;
      return uVar3;
    }
  }
  else {
    if (uVar3 == 0xfffffffffffffffd) {
                    // WARNING: Subroutine does not return
      abort();
    }
    if (lVar6 != 0) {
      cVar1 = FUN_00111400(0);
      if (cVar1 == '\0') {
        if (puVar5 != (uint *)0x0) {
          *puVar5 = (uint)*pbVar4;
        }
        uVar3 = 1;
      }
    }
  }
  return uVar3;
}



int FUN_00113c00(byte *param_1,long param_2,uint param_3)

{
  byte *pbVar1;
  byte bVar2;
  int iVar3;
  size_t sVar4;
  long lVar5;
  ushort **ppuVar6;
  long lVar7;
  int iVar8;
  long in_FS_OFFSET;
  wchar_t local_4c;
  undefined8 local_48;
  long local_40;
  
  pbVar1 = param_1 + param_2;
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  sVar4 = __ctype_get_mb_cur_max();
  if (sVar4 < 2) {
    iVar8 = 0;
    if (param_1 < pbVar1) {
      ppuVar6 = __ctype_b_loc();
      iVar8 = 0;
      do {
        bVar2 = *param_1;
        param_1 = param_1 + 1;
        if (((*ppuVar6)[bVar2] & 0x4000) == 0) {
          if ((param_3 & 2) != 0) goto LAB_00113cd6;
          if (((*ppuVar6)[bVar2] & 2) == 0) goto LAB_00113d89;
        }
        else {
LAB_00113d89:
          if (iVar8 == 0x7fffffff) goto LAB_00113d91;
          iVar8 = iVar8 + 1;
        }
      } while (pbVar1 != param_1);
    }
  }
  else {
    iVar8 = 0;
    if (param_1 < pbVar1) {
      do {
        if ((int)(char)*param_1 - 0x20U < 0x5f) {
LAB_00113c60:
          param_1 = param_1 + 1;
          iVar8 = iVar8 + 1;
        }
        else {
          local_48 = 0;
          lVar5 = FUN_00113b30(&local_4c,param_1,(long)pbVar1 - (long)param_1,&local_48);
          if (lVar5 == -1) {
            if ((param_3 & 1) == 0) goto LAB_00113c60;
            goto LAB_00113cd6;
          }
          if (lVar5 == -2) {
            if ((param_3 & 1) == 0) {
              iVar8 = iVar8 + 1;
            }
            else {
LAB_00113cd6:
              iVar8 = -1;
            }
            break;
          }
          lVar7 = 1;
          if (lVar5 != 0) {
            lVar7 = lVar5;
          }
          iVar3 = wcwidth(local_4c);
          if (iVar3 < 0) {
            if ((param_3 & 2) != 0) goto LAB_00113cd6;
            iVar3 = iswcntrl(local_4c);
            if (iVar3 == 0) {
              if (iVar8 == 0x7fffffff) goto LAB_00113d91;
              iVar8 = iVar8 + 1;
            }
          }
          else {
            if (0x7fffffff - iVar8 < iVar3) goto LAB_00113d91;
            iVar8 = iVar8 + iVar3;
          }
          param_1 = param_1 + lVar7;
        }
      } while (param_1 < pbVar1);
    }
  }
LAB_00113caa:
  if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
    return iVar8;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
LAB_00113d91:
  iVar8 = 0x7fffffff;
  goto LAB_00113caa;
}



void FUN_00113da0(char *param_1,undefined4 param_2)

{
  size_t sVar1;
  
  sVar1 = strlen(param_1);
  FUN_00113c00(param_1,sVar1,param_2);
  return;
}



void FUN_00113dd0(undefined8 *param_1,ulong param_2,undefined8 *param_3,code *param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  int iVar3;
  ulong uVar4;
  undefined8 uVar5;
  ulong uVar6;
  ulong uVar7;
  ulong uVar8;
  ulong uVar9;
  long lVar10;
  long lVar11;
  undefined8 *puVar12;
  undefined8 *__dest;
  undefined8 local_78;
  ulong local_48;
  
  uVar4 = param_2 >> 1;
  uVar6 = param_2 - uVar4;
  puVar1 = param_1 + uVar4;
  if (uVar6 < 3) {
    if (uVar6 == 2) {
      uVar5 = *puVar1;
      uVar2 = puVar1[1];
      iVar3 = (*param_4)(uVar5,uVar2);
      if (0 < iVar3) {
        *puVar1 = uVar2;
        puVar1[1] = uVar5;
      }
    }
  }
  else {
    FUN_00113dd0(puVar1,uVar6,param_3);
  }
  if (param_2 == 3) {
    local_78 = *param_1;
    *param_3 = local_78;
    goto LAB_00113e30;
  }
  uVar6 = param_2 >> 2;
  uVar7 = uVar4 - uVar6;
  puVar12 = param_1 + uVar6;
  if (uVar7 < 3) {
    if (uVar7 == 2) {
      uVar5 = *puVar12;
      uVar2 = puVar12[1];
      iVar3 = (*param_4)(uVar5,uVar2);
      if (0 < iVar3) {
        *puVar12 = uVar2;
        puVar12[1] = uVar5;
      }
    }
  }
  else {
    FUN_00113dd0(puVar12,uVar7,param_3,param_4);
  }
  if (uVar6 < 3) {
    uVar5 = *param_1;
    local_78 = uVar5;
    if (uVar6 == 2) {
      local_78 = param_1[1];
      iVar3 = (*param_4)(uVar5,local_78);
      if (iVar3 < 1) goto LAB_00114049;
      *param_1 = local_78;
      param_1[1] = uVar5;
    }
  }
  else {
    FUN_00113dd0(param_1,uVar6,param_3,param_4);
LAB_00114049:
    local_78 = *param_1;
  }
  uVar5 = *puVar12;
  uVar8 = 0;
  uVar7 = uVar6;
  puVar12 = param_3;
  while( true ) {
    while( true ) {
      __dest = puVar12 + 1;
      iVar3 = (*param_4)(local_78,uVar5);
      if (0 < iVar3) break;
      uVar8 = uVar8 + 1;
      *puVar12 = local_78;
      uVar9 = uVar7;
      local_48 = uVar4;
      if (uVar6 == uVar8) goto LAB_00113fdd;
      local_78 = param_1[uVar8];
      puVar12 = __dest;
    }
    *puVar12 = uVar5;
    uVar7 = uVar7 + 1;
    uVar9 = uVar8;
    local_48 = uVar6;
    if (uVar4 == uVar7) break;
    uVar5 = param_1[uVar7];
    puVar12 = __dest;
  }
LAB_00113fdd:
  memcpy(__dest,param_1 + uVar9,(local_48 - uVar9) * 8);
  local_78 = *param_3;
LAB_00113e30:
  uVar7 = 0;
  uVar5 = *puVar1;
  uVar6 = uVar4;
  lVar10 = 0;
  while( true ) {
    while( true ) {
      lVar11 = lVar10 + 1;
      iVar3 = (*param_4)(local_78,uVar5);
      if (0 < iVar3) break;
      uVar7 = uVar7 + 1;
      param_1[lVar10] = local_78;
      if (uVar4 == uVar7) {
        return;
      }
      local_78 = param_3[uVar7];
      lVar10 = lVar11;
    }
    param_1[lVar10] = uVar5;
    uVar6 = uVar6 + 1;
    if (param_2 == uVar6) break;
    uVar5 = param_1[uVar6];
    lVar10 = lVar11;
  }
  memcpy(param_1 + lVar11,param_3 + uVar7,(uVar4 - uVar7) * 8);
  return;
}



void FUN_001140d0(undefined8 *param_1,ulong param_2,code *param_3)

{
  undefined8 uVar1;
  undefined8 uVar2;
  int iVar3;
  
  if (2 < param_2) {
    FUN_00113dd0(param_1,param_2,param_1 + param_2,param_3);
    return;
  }
  if (param_2 == 2) {
    uVar1 = *param_1;
    uVar2 = param_1[1];
    iVar3 = (*param_3)(uVar1,uVar2);
    if (0 < iVar3) {
      *param_1 = uVar2;
      param_1[1] = uVar1;
      return;
    }
  }
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

char * nl_langinfo(nl_item __item)

{
  char *pcVar1;
  
  pcVar1 = nl_langinfo(__item);
  return pcVar1;
}



long FUN_00114180(char *param_1,long param_2,char *param_3,tm *param_4,byte param_5,int param_6,
                 int param_7,ulong param_8,int param_9)

{
  int iVar1;
  undefined4 uVar2;
  char cVar3;
  bool bVar4;
  byte bVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int *piVar10;
  __int32_t **pp_Var11;
  long lVar12;
  byte bVar13;
  long lVar14;
  int iVar15;
  uint uVar16;
  ulong uVar17;
  ulong uVar18;
  size_t sVar19;
  size_t __n;
  long lVar20;
  char cVar21;
  ulong uVar22;
  uint uVar23;
  int iVar24;
  uint uVar25;
  int iVar26;
  byte bVar27;
  int iVar28;
  char *pcVar29;
  byte bVar30;
  char *pcVar31;
  char *pcVar32;
  ulong uVar33;
  long in_FS_OFFSET;
  bool bVar34;
  uint local_4d0;
  char *local_4b8;
  undefined8 local_488;
  undefined8 uStack_480;
  undefined8 local_478;
  undefined8 uStack_470;
  undefined8 local_468;
  long lStack_460;
  char *local_458;
  undefined8 uStack_450;
  undefined8 local_448;
  char local_432 [1010];
  long local_40;
  
  uVar33 = (ulong)param_7;
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  piVar10 = __errno_location();
  iVar1 = *piVar10;
  uVar23 = param_4->tm_hour;
  if ((int)uVar23 < 0xd) {
    local_4d0 = 0xc;
    if (uVar23 != 0) {
      local_4d0 = uVar23;
    }
  }
  else {
    local_4d0 = uVar23 - 0xc;
  }
  cVar3 = *param_3;
  lVar20 = 0;
  do {
    if (cVar3 == '\0') {
      if ((param_1 != (char *)0x0) && (param_2 != 0)) {
        *param_1 = '\0';
      }
      *piVar10 = iVar1;
LAB_001142eb:
      if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
        return lVar20;
      }
                    // WARNING: Subroutine does not return
      __stack_chk_fail();
    }
    pcVar31 = param_3;
    if (cVar3 == '%') {
      bVar27 = 0;
      iVar6 = 0;
      bVar30 = param_5;
LAB_00114380:
      do {
        bVar13 = pcVar31[1];
        pcVar31 = pcVar31 + 1;
        cVar3 = bVar13 - 0x30;
        bVar34 = bVar13 == 0x30;
        if (!bVar34) {
LAB_0011438e:
          uVar17 = (ulong)bVar13;
          if (bVar34 || SBORROW1(bVar13,'0') != cVar3 < '\0') {
            if (bVar13 == 0x2b) {
              iVar6 = 2;
            }
            else {
              if (bVar13 != 0x2d) {
                if (bVar13 == 0x23) goto code_r0x001143a3;
                goto LAB_00114466;
              }
              iVar6 = 4;
            }
          }
          else if (bVar13 == 0x5e) {
            bVar30 = 1;
          }
          else {
            if (bVar13 != 0x5f) {
              uVar23 = (uint)(char)bVar13;
              if (uVar23 - 0x30 < 10) {
                iVar7 = 0;
                bVar34 = false;
                while( true ) {
                  uVar33 = 0x7fffffff;
                  if ((!bVar34) && (!SCARRY4(iVar7,*pcVar31 + -0x30))) {
                    uVar33 = (ulong)(uint)(iVar7 + *pcVar31 + -0x30);
                  }
                  uVar23 = (uint)pcVar31[1];
                  uVar17 = (ulong)uVar23;
                  pcVar31 = pcVar31 + 1;
                  if (9 < uVar23 - 0x30) break;
                  lVar14 = (long)(int)uVar33 * 10;
                  iVar7 = (int)lVar14;
                  bVar34 = iVar7 != lVar14;
                }
              }
              iVar7 = (int)uVar33;
              if ((char)uVar17 == 'E') {
LAB_00114585:
                uVar17 = (ulong)(byte)pcVar31[1];
                pcVar31 = pcVar31 + 1;
              }
              else {
LAB_00114466:
                iVar7 = (int)uVar33;
                uVar23 = 0;
                if ((char)uVar17 == 'O') {
                  uVar23 = 0x4f;
                  goto LAB_00114585;
                }
              }
              bVar13 = (byte)uVar17;
              pcVar32 = pcVar31;
              if (0x7a < bVar13) goto switchD_00114487_caseD_1;
              lVar14 = lVar20;
              uVar16 = local_4d0;
              switch(uVar17 & 0xff) {
              case 0:
                pcVar32 = pcVar31 + -1;
                break;
              case 0x25:
                pcVar32 = pcVar31 + -1;
                if (pcVar32 != param_3) break;
                if ((iVar6 == 4) || (iVar7 < 0)) {
                  if (1 < (ulong)(param_2 - lVar20)) {
                    uVar33 = 1;
                    if (param_1 != (char *)0x0) goto LAB_00115ad9;
                    goto LAB_001145b0;
                  }
                }
                else {
                  uVar17 = (ulong)iVar7;
                  uVar33 = 1;
                  if (uVar17 != 0) {
                    uVar33 = uVar17;
                  }
                  if (uVar33 < (ulong)(param_2 - lVar20)) {
                    if (param_1 != (char *)0x0) {
                      if (uVar17 < 2) {
                        uVar33 = 1;
                      }
                      else {
                        sVar19 = uVar17 - 1;
                        if (iVar6 - 1U < 2) {
                          memset(param_1,0x30,sVar19);
                        }
                        else {
                          memset(param_1,0x20,sVar19);
                        }
                        param_1 = param_1 + sVar19;
                      }
LAB_00115ad9:
                      *param_1 = *pcVar31;
                      param_1 = param_1 + 1;
                    }
                    goto LAB_001145b0;
                  }
                }
                goto LAB_001142e0;
              case 0x3a:
                cVar3 = pcVar31[1];
                pcVar29 = pcVar31 + 1;
                uVar33 = 1;
                if (cVar3 == ':') {
                  do {
                    uVar33 = uVar33 + 1;
                    cVar3 = pcVar31[uVar33];
                  } while (cVar3 == ':');
                  pcVar29 = pcVar31 + uVar33;
                }
                if (cVar3 == 'z') goto LAB_001151b0;
                break;
              case 0x41:
              case 0x61:
                if (uVar23 != 0) break;
LAB_001149eb:
                bVar30 = bVar30 | bVar27;
                bVar27 = 0;
                goto LAB_001145e9;
              case 0x42:
                if (uVar23 != 0x45) goto LAB_001149eb;
                break;
              case 0x43:
                if (uVar23 == 0x45) goto switchD_00114487_caseD_72;
                iVar24 = param_4->tm_year;
                local_4b8._0_1_ = iVar24 < -0x76c;
                uVar16 = (int)((-(uint)(iVar24 + 0x76cU < 0x76c) & 0xffffff9d) + iVar24) / 100 +
                         0x13;
                bVar4 = -0x76d < iVar24;
                if (iVar6 == 0) {
                  iVar6 = param_6;
                }
                if (iVar6 == 2) {
                  iVar24 = 2;
                  uVar25 = 99;
LAB_00115cd1:
                  bVar34 = true;
                  iVar6 = 2;
                  bVar4 = (bool)(local_4b8._0_1_ ^ 1);
                  if (uVar16 <= uVar25) goto LAB_00115b1d;
                }
                else {
                  bVar34 = false;
                  iVar24 = 2;
                }
LAB_00114950:
                uVar25 = 0;
                goto LAB_00114960;
              case 0x44:
                if (uVar23 == 0) {
                  iVar24 = -1;
                  local_4b8 = "%m/%d/%y";
                  goto LAB_00114beb;
                }
                break;
              case 0x46:
                if (uVar23 != 0) break;
                if ((iVar6 != 0) || (-1 < iVar7)) {
                  iVar24 = 0;
                  if (-1 < iVar7 + -6) {
                    iVar24 = iVar7 + -6;
                  }
                  local_4b8 = "%Y-%m-%d";
                  goto LAB_00114beb;
                }
                uVar17 = FUN_00114180(0,0xffffffffffffffff,"%Y-%m-%d",param_4,bVar30,2,4,param_8,
                                      param_9,(long)&switchD_00114487::switchdataD_0011fcf4 +
                                              (long)(int)(&switchD_00114487::switchdataD_0011fcf4)
                                                         [uVar17 & 0xff]);
                iVar6 = 2;
                iVar24 = 4;
                local_4b8 = "%Y-%m-%d";
                goto LAB_00115850;
              case 0x47:
              case 0x56:
              case 0x67:
                if (uVar23 != 0x45) {
                  iVar9 = param_4->tm_year;
                  iVar26 = param_4->tm_yday;
                  iVar28 = param_4->tm_wday;
                  iVar24 = (iVar26 - iVar28) + 0x17e;
                  uVar16 = iVar9 + -100 + (iVar9 >> 0x1f & 400U);
                  iVar24 = (iVar26 - iVar24) + 3 + (iVar24 / 7) * 7;
                  if (iVar24 < 0) {
                    uVar16 = uVar16 - 1;
                    iVar24 = 0x16d;
                    if (((uVar16 & 3) == 0) &&
                       (iVar24 = 0x16e,
                       (uVar16 * -0x3d70a3d7 + 0x51eb850 >> 2 | uVar16 * 0x40000000) < 0x28f5c29)) {
                      iVar24 = ((int)uVar16 % 400 == 0) + 0x16d;
                    }
                    iVar28 = ((iVar24 + iVar26) - iVar28) + 0x17e;
                    iVar26 = ((iVar24 + iVar26) - iVar28) + 3 + (iVar28 / 7) * 7;
                    iVar28 = -1;
                  }
                  else {
                    iVar8 = 0x16d;
                    if (((uVar16 & 3) == 0) &&
                       (iVar8 = 0x16e,
                       (uVar16 * -0x3d70a3d7 + 0x51eb850 >> 2 | iVar9 * 0x40000000) < 0x28f5c29)) {
                      iVar8 = ((int)uVar16 % 400 == 0) + 0x16d;
                    }
                    iVar15 = ((iVar26 - iVar8) - iVar28) + 0x17e;
                    iVar28 = 1;
                    iVar26 = ((iVar26 - iVar8) - iVar15) + 3 + (iVar15 / 7) * 7;
                    if (iVar26 < 0) {
                      iVar28 = 0;
                      iVar26 = iVar24;
                    }
                  }
                  if (bVar13 == 0x47) {
                    uVar16 = iVar9 + 0x76c + iVar28;
                    local_4b8._0_1_ = iVar9 < -0x76c - iVar28;
                    bVar4 = -0x76c - iVar28 <= iVar9;
                    if (iVar6 == 0) {
                      iVar6 = param_6;
                    }
                    if (iVar6 == 2) {
LAB_00115d9c:
                      iVar24 = 4;
                      uVar25 = 9999;
                      goto LAB_00115cd1;
                    }
                    bVar34 = false;
                    iVar24 = 4;
                    goto LAB_00114950;
                  }
                  if (bVar13 == 0x67) {
                    uVar16 = (iVar9 % 100 + iVar28) % 100;
                    if ((int)uVar16 < 0) {
                      if (iVar9 < -0x76c - iVar28) {
                        uVar16 = -uVar16;
                      }
                      else {
                        uVar16 = uVar16 + 100;
                      }
                    }
                    goto joined_r0x00114925;
                  }
                  iVar24 = 2;
                  uVar16 = iVar26 / 7 + 1;
                  goto LAB_00114f10;
                }
                break;
              case 0x48:
                if (uVar23 != 0x45) {
                  iVar24 = 2;
                  uVar16 = param_4->tm_hour;
                  goto LAB_00114f10;
                }
                break;
              case 0x49:
                if (uVar23 != 0x45) {
                  iVar24 = 2;
                  goto LAB_00114f10;
                }
                break;
              case 0x4d:
                if (uVar23 != 0x45) {
                  iVar24 = 2;
                  uVar16 = param_4->tm_min;
                  goto LAB_00114f10;
                }
                break;
              case 0x4e:
                if (uVar23 != 0x45) {
                  iVar9 = 9;
                  iVar24 = param_9;
                  if (iVar7 < 1) {
                    iVar7 = 9;
                  }
                  for (; iVar7 < iVar9; iVar9 = iVar9 + -1) {
LAB_001152a0:
                    iVar24 = iVar24 / 10;
                  }
                  if (iVar9 == 1) {
                    uVar33 = 1;
                  }
                  else {
                    if (iVar24 % 10 == 0) goto LAB_001152a0;
                    uVar33 = (ulong)iVar9;
                  }
                  pcVar32 = (char *)((long)&local_448 + uVar33);
                  do {
                    pcVar32 = pcVar32 + -1;
                    *pcVar32 = (char)iVar24 + (char)(iVar24 / 10) * -10 + '0';
                    iVar24 = iVar24 / 10;
                  } while (pcVar32 != (char *)((long)&uStack_450 + (uVar33 - (iVar9 - 1)) + 7));
                  if ((ulong)(param_2 - lVar20) <= uVar33) goto LAB_001142e0;
                  if (param_1 == (char *)0x0) {
                    if (iVar6 == 4) goto LAB_001153ec;
                    if ((ulong)(long)(iVar7 - iVar9) < param_2 - (lVar20 + uVar33)) {
                      lVar14 = lVar20 + uVar33 + (long)(iVar7 - iVar9);
                      goto LAB_0011426f;
                    }
                    goto LAB_001142e0;
                  }
                  if (bVar30 == 0) {
                    uVar23 = (uint)uVar33;
                    uVar17 = uVar33 & 0xffffffff;
                    if (uVar23 < 8) {
                      if ((uVar33 & 4) == 0) {
                        if (uVar23 != 0) {
                          *param_1 = (char)local_448;
                          if ((uVar33 & 2) != 0) {
                            *(undefined2 *)(param_1 + (uVar17 - 2)) =
                                 *(undefined2 *)((long)&uStack_450 + uVar17 + 6);
                          }
                        }
                      }
                      else {
                        *(undefined4 *)param_1 = (undefined4)local_448;
                        *(undefined4 *)(param_1 + (uVar17 - 4)) =
                             *(undefined4 *)((long)&uStack_450 + uVar17 + 4);
                      }
                    }
                    else {
                      *(ulong *)param_1 = CONCAT44(local_448._4_4_,(undefined4)local_448);
                      *(undefined8 *)(param_1 + ((uVar33 & 0xffffffff) - 8)) =
                           *(undefined8 *)((long)&uStack_450 + (uVar33 & 0xffffffff));
                      lVar14 = (long)param_1 - ((ulong)(param_1 + 8) & 0xfffffffffffffff8);
                      uVar23 = (int)lVar14 + uVar23 & 0xfffffff8;
                      if (7 < uVar23) {
                        uVar16 = 0;
                        do {
                          uVar17 = (ulong)uVar16;
                          uVar16 = uVar16 + 8;
                          *(undefined8 *)(((ulong)(param_1 + 8) & 0xfffffffffffffff8) + uVar17) =
                               *(undefined8 *)((long)&local_448 + (uVar17 - lVar14));
                        } while (uVar16 < uVar23);
                      }
                    }
                  }
                  else {
                    pp_Var11 = __ctype_toupper_loc();
                    uVar17 = uVar33;
                    do {
                      uVar18 = uVar17 - 1;
                      param_1[uVar18] = (char)(*pp_Var11)[*(byte *)((long)&uStack_450 + uVar17 + 7)]
                      ;
                      uVar17 = uVar18;
                    } while (uVar18 != 0);
                  }
                  param_1 = param_1 + uVar33;
                  lVar14 = lVar20 + uVar33;
                  if (iVar6 == 4) {
LAB_001153ec:
                    lVar14 = lVar20 + uVar33;
                    if (param_2 == lVar14) goto LAB_001142e0;
                  }
                  else {
                    uVar33 = (ulong)(iVar7 - iVar9);
                    if ((ulong)(param_2 - lVar14) <= uVar33) goto LAB_001142e0;
                    if (uVar33 != 0) {
                      if (iVar6 == 3) {
                        memset(param_1,0x20,uVar33);
                      }
                      else {
                        memset(param_1,0x30,uVar33);
                      }
                      param_1 = param_1 + uVar33;
                      lVar14 = lVar14 + uVar33;
                    }
                  }
                  goto LAB_0011426f;
                }
                break;
              case 0x50:
                bVar5 = 1;
                goto LAB_0011565d;
              case 0x52:
                iVar24 = -1;
                local_4b8 = "%H:%M";
                goto LAB_00114beb;
              case 0x53:
                if (uVar23 != 0x45) {
                  iVar24 = 2;
                  uVar16 = param_4->tm_sec;
                  goto LAB_00114f10;
                }
                break;
              case 0x54:
                iVar24 = -1;
                local_4b8 = "%H:%M:%S";
LAB_00114beb:
                uVar17 = FUN_00114180(0,0xffffffffffffffff,local_4b8,param_4,bVar30,iVar6,iVar24,
                                      param_8,param_9);
                uVar18 = param_2 - lVar20;
                if (iVar6 == 4) {
LAB_00115858:
                  if (uVar18 <= uVar17) goto LAB_001142e0;
                  uVar33 = uVar17;
                  if (param_1 != (char *)0x0) {
LAB_00114cc1:
                    FUN_00114180(param_1,uVar18,local_4b8,param_4,bVar30,iVar6,iVar24,param_8,
                                 param_9);
                    param_1 = param_1 + uVar17;
                  }
                }
                else {
                  if (iVar7 < 0) {
LAB_00115850:
                    uVar18 = param_2 - lVar20;
                    goto LAB_00115858;
                  }
                  uVar22 = (ulong)iVar7;
                  uVar33 = uVar22;
                  if (uVar22 <= uVar17) {
                    uVar33 = uVar17;
                  }
                  if (uVar18 <= uVar33) goto LAB_001142e0;
                  if (param_1 != (char *)0x0) {
                    if (uVar17 < uVar22) {
                      sVar19 = uVar22 - uVar17;
                      if (iVar6 - 1U < 2) {
                        memset(param_1,0x30,sVar19);
                      }
                      else {
                        memset(param_1,0x20,sVar19);
                      }
                      param_1 = param_1 + sVar19;
                    }
                    goto LAB_00114cc1;
                  }
                }
                goto LAB_001145b0;
              case 0x55:
                if (uVar23 != 0x45) {
                  iVar9 = (param_4->tm_yday - param_4->tm_wday) + 7;
LAB_00114fed:
                  iVar24 = 2;
                  uVar16 = iVar9 / 7;
                  goto LAB_00114f10;
                }
                break;
              case 0x57:
                if (uVar23 != 0x45) {
                  iVar24 = param_4->tm_wday + 6;
                  iVar9 = ((iVar24 / 7) * 7 - iVar24) + 7 + param_4->tm_yday;
                  goto LAB_00114fed;
                }
                break;
              case 0x58:
              case 99:
              case 0x78:
                if (uVar23 != 0x4f) goto switchD_00114487_caseD_72;
                break;
              case 0x59:
                if (uVar23 == 0x45) goto switchD_00114487_caseD_72;
                if (uVar23 == 0x4f) break;
                local_4b8._0_1_ = param_4->tm_year < -0x76c;
                uVar16 = param_4->tm_year + 0x76c;
                if (iVar6 == 0) {
                  iVar6 = param_6;
                }
                if (iVar6 == 2) goto LAB_00115d9c;
                bVar34 = false;
                uVar25 = 0;
                iVar24 = 4;
                goto LAB_00114970;
              case 0x5a:
                if (bVar27 != 0) {
                  bVar30 = 0;
                }
                pcVar32 = param_4->tm_zone;
                uVar17 = strlen(pcVar32);
                uVar33 = uVar17;
                if ((iVar6 == 4) || (iVar7 < 0)) {
                  if (uVar17 < (ulong)(param_2 - lVar20)) {
                    if (param_1 != (char *)0x0) goto LAB_0011513a;
                    goto LAB_001145b0;
                  }
                  goto LAB_001142e0;
                }
                uVar18 = (ulong)iVar7;
                uVar33 = uVar18;
                if (uVar18 <= uVar17) {
                  uVar33 = uVar17;
                }
                if ((ulong)(param_2 - lVar20) <= uVar33) goto LAB_001142e0;
                if (param_1 == (char *)0x0) goto LAB_001145b0;
                if (uVar17 < uVar18) {
                  sVar19 = uVar18 - uVar17;
                  if (iVar6 - 1U < 2) {
                    memset(param_1,0x30,sVar19);
                  }
                  else {
                    memset(param_1,0x20,sVar19);
                  }
                  param_1 = param_1 + sVar19;
                }
LAB_0011513a:
                if (bVar27 == 0) {
                  if (bVar30 == 0) {
                    memcpy(param_1,pcVar32,uVar17);
                  }
                  else if (uVar17 != 0) {
                    pp_Var11 = __ctype_toupper_loc();
                    sVar19 = uVar17;
                    do {
                      sVar19 = sVar19 - 1;
                      param_1[sVar19] = (char)(*pp_Var11)[(byte)pcVar32[sVar19]];
                    } while (sVar19 != 0);
                  }
                }
                else if (uVar17 != 0) {
                  pp_Var11 = __ctype_tolower_loc();
                  sVar19 = uVar17;
                  do {
                    sVar19 = sVar19 - 1;
                    param_1[sVar19] = (char)(*pp_Var11)[(byte)pcVar32[sVar19]];
                  } while (sVar19 != 0);
                }
                goto LAB_001147b4;
              case 0x62:
              case 0x68:
                bVar30 = bVar30 | bVar27;
                if (uVar23 != 0x45) goto switchD_00114487_caseD_72;
                break;
              case 100:
                if (uVar23 != 0x45) {
                  iVar24 = 2;
                  uVar16 = param_4->tm_mday;
                  goto LAB_00114f10;
                }
                break;
              case 0x65:
                if (uVar23 != 0x45) {
                  uVar16 = param_4->tm_mday;
LAB_001155eb:
                  iVar24 = 2;
                  if (iVar6 == 0) {
                    iVar6 = 3;
                  }
                  goto LAB_00114f10;
                }
                break;
              case 0x6a:
                if (uVar23 != 0x45) {
                  bVar34 = false;
                  iVar24 = 3;
                  iVar9 = param_4->tm_yday;
                  uVar16 = iVar9 + 1;
                  local_4b8._0_1_ = iVar9 < -1;
                  bVar4 = -2 < iVar9;
                  uVar25 = 0;
                  goto LAB_00114960;
                }
                break;
              case 0x6b:
                if (uVar23 != 0x45) {
                  uVar16 = param_4->tm_hour;
                  goto LAB_001155eb;
                }
                break;
              case 0x6c:
                if (uVar23 != 0x45) goto LAB_001155eb;
                break;
              case 0x6d:
                if (uVar23 != 0x45) {
                  bVar34 = false;
                  iVar24 = 2;
                  iVar9 = param_4->tm_mon;
                  uVar16 = iVar9 + 1;
                  local_4b8._0_1_ = iVar9 < -1;
                  bVar4 = -2 < iVar9;
                  uVar25 = 0;
                  goto LAB_00114960;
                }
                break;
              case 0x6e:
                if ((iVar6 == 4) || (iVar7 < 0)) {
                  if (1 < (ulong)(param_2 - lVar20)) {
                    uVar33 = 1;
                    if (param_1 != (char *)0x0) goto LAB_00114fc9;
                    goto LAB_001145b0;
                  }
                  goto LAB_001142e0;
                }
                uVar17 = (ulong)iVar7;
                uVar33 = 1;
                if (uVar17 != 0) {
                  uVar33 = uVar17;
                }
                if ((ulong)(param_2 - lVar20) <= uVar33) goto LAB_001142e0;
                if (param_1 != (char *)0x0) {
                  if (uVar17 < 2) {
                    uVar33 = 1;
                  }
                  else {
                    sVar19 = uVar17 - 1;
                    if (iVar6 - 1U < 2) {
                      memset(param_1,0x30,sVar19);
                    }
                    else {
                      memset(param_1,0x20,sVar19);
                    }
                    param_1 = param_1 + sVar19;
                  }
LAB_00114fc9:
                  *param_1 = '\n';
                  param_1 = param_1 + 1;
                }
                goto LAB_001145b0;
              case 0x70:
                bVar5 = 0;
LAB_0011565d:
                if (bVar27 == 0) {
                  bVar13 = 0x70;
                  bVar27 = bVar5;
                }
                else {
                  bVar13 = 0x70;
                  bVar30 = 0;
                }
                goto LAB_001145e9;
              case 0x71:
                bVar27 = 0;
                if (uVar23 == 0x4f) goto LAB_001145e9;
                bVar34 = false;
                iVar24 = 1;
                uVar25 = 0;
                local_4b8._0_1_ = false;
                uVar33 = (ulong)((param_4->tm_mon * 0xb >> 5) + 1);
                goto LAB_0011497c;
              case 0x72:
                goto switchD_00114487_caseD_72;
              case 0x73:
                local_488._0_4_ = param_4->tm_sec;
                local_488._4_4_ = param_4->tm_min;
                uStack_480._0_4_ = param_4->tm_hour;
                uStack_480._4_4_ = param_4->tm_mday;
                local_478._0_4_ = param_4->tm_mon;
                local_478._4_4_ = param_4->tm_year;
                uVar2 = param_4->tm_wday;
                local_468 = *(undefined8 *)&param_4->tm_isdst;
                lStack_460 = param_4->tm_gmtoff;
                local_458 = param_4->tm_zone;
                uStack_470 = CONCAT44(0xffffffff,uVar2);
                lVar14 = FUN_00119460(param_8,&local_488);
                if (-1 < uStack_470) {
                  pcVar29 = local_432 + 1;
                  lVar12 = lVar14 / 10;
                  uVar33 = (ulong)(uint)((int)lVar14 + (int)lVar12 * -10);
                  pcVar32 = pcVar29;
                  if (lVar14 < 0) {
                    while( true ) {
                      pcVar32 = pcVar32 + -1;
                      *pcVar32 = '0' - (char)uVar33;
                      if (lVar12 == 0) break;
                      uVar33 = lVar12 % 10;
                      lVar12 = lVar12 / 10;
                    }
                  }
                  else {
                    while( true ) {
                      pcVar32 = pcVar32 + -1;
                      *pcVar32 = (char)uVar33 + '0';
                      if (lVar12 == 0) break;
                      uVar33 = lVar12 % 10;
                      lVar12 = lVar12 / 10;
                    }
                  }
                  iVar9 = 1;
                  if (iVar6 != 0) {
                    iVar9 = iVar6;
                  }
                  iVar24 = (int)pcVar29;
                  iVar26 = (int)pcVar32;
                  if (-1 < iVar7) {
                    iVar24 = iVar24 - iVar26;
                    if (lVar14 < 0) {
                      uVar33 = (ulong)iVar24;
                      cVar21 = '-';
                      iVar24 = (iVar7 + -1) - iVar24;
                      cVar3 = '-';
                      if (iVar6 == 4) {
                        iVar24 = 0;
                        goto LAB_00114a5f;
                      }
                      goto LAB_00115759;
                    }
                    if (iVar7 <= iVar24) goto LAB_00115961;
                    goto joined_r0x00114e6f;
                  }
                  if (lVar14 < 0) {
                    iVar24 = iVar24 - iVar26;
                    uVar33 = (ulong)iVar24;
                    if ((iVar6 == 4) || (-1 < iVar24)) {
                      iVar7 = 1;
                      goto LAB_0011589f;
                    }
                    iVar24 = -iVar24;
                    iVar7 = 1;
                    cVar21 = '-';
                    goto LAB_00114a5f;
                  }
                  iVar24 = iVar24 - iVar26;
                  if ((0 < iVar24) || (iVar7 = 1, iVar6 == 4)) {
                    iVar7 = 1;
                    goto LAB_00115961;
                  }
                  goto LAB_00114e75;
                }
                *piVar10 = 0x4b;
                goto LAB_001142e8;
              case 0x74:
                if ((iVar6 == 4) || (iVar7 < 0)) {
                  if (1 < (ulong)(param_2 - lVar20)) {
                    uVar33 = 1;
                    if (param_1 != (char *)0x0) goto LAB_0011556f;
                    goto LAB_001145b0;
                  }
                }
                else {
                  uVar17 = (ulong)iVar7;
                  uVar33 = 1;
                  if (uVar17 != 0) {
                    uVar33 = uVar17;
                  }
                  if (uVar33 < (ulong)(param_2 - lVar20)) {
                    if (param_1 != (char *)0x0) {
                      if (uVar17 < 2) {
                        uVar33 = 1;
                      }
                      else {
                        sVar19 = uVar17 - 1;
                        if (iVar6 - 1U < 2) {
                          memset(param_1,0x30,sVar19);
                        }
                        else {
                          memset(param_1,0x20,sVar19);
                        }
                        param_1 = param_1 + sVar19;
                      }
LAB_0011556f:
                      *param_1 = '\t';
                      param_1 = param_1 + 1;
                    }
                    goto LAB_001145b0;
                  }
                }
                goto LAB_001142e0;
              case 0x75:
                iVar24 = 1;
                uVar16 = (param_4->tm_wday + 6) % 7 + 1;
LAB_00114f10:
                bVar34 = false;
                uVar25 = 0;
                bVar27 = (byte)(uVar16 >> 0x18);
                local_4b8._0_1_ = (bool)(bVar27 >> 7);
                bVar4 = (bool)((byte)~bVar27 >> 7);
LAB_00114960:
                if ((uVar23 == 0x4f) && (bVar27 = 0, bVar4 != false)) {
LAB_001145e9:
                  uStack_450._4_1_ = (undefined1)uVar23;
                  uStack_450._2_2_ = 0x2520;
                  *(byte *)((long)&uStack_450 + -(ulong)(uVar23 == 0) + 5) = bVar13;
                  *(undefined1 *)((long)&uStack_450 + -(ulong)(uVar23 == 0) + 6) = 0;
                  if (1 < param_8) {
                    lVar12 = FUN_00119290();
                    if (lVar12 != 0) {
                      sVar19 = strftime((char *)&local_448,0x400,(char *)((long)&uStack_450 + 2),
                                        param_4);
                      goto LAB_00114681;
                    }
                    goto LAB_0011426f;
                  }
                  sVar19 = strftime((char *)&local_448,0x400,(char *)((long)&uStack_450 + 2),param_4
                                   );
                  if (param_8 != 0) {
LAB_00114681:
                    cVar3 = FUN_00119390();
                    if (cVar3 == '\0') goto LAB_0011426f;
                  }
                  if (sVar19 == 0) goto LAB_0011426f;
                  uVar17 = sVar19 - 1;
                  uVar33 = uVar17;
                  if ((iVar6 == 4) || (iVar7 < 0)) {
                    if (uVar17 < (ulong)(param_2 - lVar20)) {
                      if (param_1 != (char *)0x0) goto LAB_00114752;
                      goto LAB_001145b0;
                    }
                    goto LAB_001142e0;
                  }
                  uVar18 = (ulong)iVar7;
                  uVar33 = uVar18;
                  if (uVar18 <= uVar17) {
                    uVar33 = uVar17;
                  }
                  if ((ulong)(param_2 - lVar20) <= uVar33) goto LAB_001142e0;
                  if (param_1 != (char *)0x0) {
                    if (uVar17 < uVar18) {
                      __n = uVar18 - uVar17;
                      if (iVar6 - 1U < 2) {
                        memset(param_1,0x30,__n);
                      }
                      else {
                        memset(param_1,0x20,__n);
                      }
                      param_1 = param_1 + __n;
                    }
LAB_00114752:
                    if (bVar27 == 0) {
                      if (bVar30 == 0) {
                        memcpy(param_1,(void *)((long)&local_448 + 1),uVar17);
                      }
                      else {
                        lVar14 = sVar19 - 2;
                        if (uVar17 != 0) {
                          pp_Var11 = __ctype_toupper_loc();
                          do {
                            param_1[lVar14] =
                                 (char)(*pp_Var11)[*(byte *)((long)&local_448 + lVar14 + 1)];
                            bVar34 = lVar14 != 0;
                            lVar14 = lVar14 + -1;
                          } while (bVar34);
                        }
                      }
                    }
                    else {
                      lVar14 = sVar19 - 2;
                      if (uVar17 != 0) {
                        pp_Var11 = __ctype_tolower_loc();
                        do {
                          param_1[lVar14] =
                               (char)(*pp_Var11)[*(byte *)((long)&local_448 + lVar14 + 1)];
                          bVar34 = lVar14 != 0;
                          lVar14 = lVar14 + -1;
                        } while (bVar34);
                      }
                    }
LAB_001147b4:
                    param_1 = param_1 + uVar17;
                  }
                  goto LAB_001145b0;
                }
LAB_00114970:
                uVar33 = (ulong)uVar16;
                if (local_4b8._0_1_ != false) {
                  uVar33 = (ulong)-uVar16;
                }
LAB_0011497c:
                pcVar32 = local_432 + 1;
                while( true ) {
                  pcVar29 = pcVar32;
                  if ((uVar25 & 1) != 0) {
                    pcVar32[-1] = ':';
                    pcVar29 = pcVar32 + -1;
                  }
                  uVar25 = (int)uVar25 >> 1;
                  pcVar32 = pcVar29 + -1;
                  pcVar29[-1] = (char)uVar33 + (char)(uVar33 / 10) * -10 + '0';
                  if (((uint)uVar33 < 10) && (uVar25 == 0)) break;
                  uVar33 = uVar33 / 10;
                }
                iVar9 = 1;
                if (iVar6 != 0) {
                  iVar9 = iVar6;
                }
                if (-1 < iVar7) {
                  iVar24 = iVar7;
                }
                iVar7 = iVar24;
                iVar24 = (int)(local_432 + 1) - (int)pcVar32;
                if (local_4b8._0_1_ != false) {
                  uVar33 = (ulong)iVar24;
                  iVar24 = (iVar7 + -1) - iVar24;
                  if ((iVar6 == 4) || (cVar21 = '-', iVar24 < 1)) {
LAB_0011589f:
                    cVar21 = '-';
                    iVar24 = 0;
                  }
LAB_00114a5f:
                  if (iVar6 == 3) {
                    sVar19 = (size_t)iVar24;
                    iVar7 = iVar7 - iVar24;
                    lVar20 = lVar20 + sVar19;
                    if (param_1 == (char *)0x0) {
                      if (1 < (ulong)(param_2 - lVar20)) {
                        lVar20 = lVar20 + 1;
                        uVar17 = param_2 - lVar20;
                        iVar6 = iVar7 + -1;
                        if (-1 < iVar6) {
LAB_00115a5f:
                          if (uVar33 < (ulong)(long)iVar6) {
                            uVar33 = (long)iVar6;
                          }
                        }
LAB_001142ca:
                        if (uVar33 < uVar17) goto LAB_00114af7;
                      }
                    }
                    else {
                      memset(param_1,0x20,sVar19);
                      if (1 < (ulong)(param_2 - lVar20)) {
                        param_1[sVar19] = cVar21;
                        param_1 = param_1 + sVar19 + 1;
                        lVar20 = lVar20 + 1;
LAB_00115920:
                        uVar17 = (ulong)(int)uVar33;
                        uVar18 = param_2 - lVar20;
                        uVar22 = (ulong)(iVar7 + -1);
                        if (iVar7 + -1 < 0) goto LAB_00114aa5;
                        uVar33 = uVar22;
                        if (uVar22 <= uVar17) {
                          uVar33 = uVar17;
                        }
                        if (uVar33 < uVar18) goto LAB_00114e9f;
                      }
                    }
                  }
                  else if (1 < (ulong)(param_2 - lVar20)) {
                    if (param_1 == (char *)0x0) {
                      lVar20 = lVar20 + 1;
                      if (iVar6 != 4) {
                        iVar6 = iVar7 + -1;
                        uVar17 = param_2 - lVar20;
                        if (iVar7 != 0) goto LAB_00115a5f;
                        goto LAB_001142ca;
                      }
                      if (uVar33 < (ulong)(param_2 - lVar20)) goto LAB_00114af7;
                    }
                    else {
                      *param_1 = cVar21;
                      lVar20 = lVar20 + 1;
                      param_1 = param_1 + 1;
                      if (iVar6 != 4) goto LAB_00115920;
                      uVar18 = param_2 - lVar20;
LAB_00114aa5:
                      uVar33 = (ulong)(int)uVar33;
                      uVar17 = uVar33;
                      if (uVar33 < uVar18) goto LAB_00114ab1;
                    }
                  }
                  goto LAB_001142e0;
                }
                if (bVar34) {
                  uVar33 = (ulong)iVar24;
                  cVar21 = '+';
                  iVar24 = (iVar7 + -1) - iVar24;
                  cVar3 = cVar21;
                  if (iVar6 != 4) {
LAB_00115759:
                    cVar21 = cVar3;
                    if (0 < iVar24) goto LAB_00114a5f;
                  }
                  iVar24 = 0;
                  goto LAB_00114a5f;
                }
                if (iVar24 < iVar7) {
joined_r0x00114e6f:
                  if (iVar6 == 4) goto LAB_00115961;
LAB_00114e75:
                  uVar17 = (ulong)iVar24;
LAB_00114e78:
                  uVar22 = (ulong)iVar7;
                  uVar33 = uVar17;
                  if (uVar17 <= uVar22) {
                    uVar33 = uVar22;
                  }
                  if ((ulong)(param_2 - lVar20) <= uVar33) goto LAB_001142e0;
                  if (param_1 != (char *)0x0) {
LAB_00114e9f:
                    if (uVar17 < uVar22) {
                      sVar19 = uVar22 - uVar17;
                      if (iVar9 - 1U < 2) {
                        memset(param_1,0x30,sVar19);
                      }
                      else {
                        memset(param_1,0x20,sVar19);
                      }
                      param_1 = param_1 + sVar19;
                    }
                    goto LAB_00114ab1;
                  }
                }
                else {
LAB_00115961:
                  uVar33 = (ulong)iVar24;
                  uVar17 = uVar33;
                  if (iVar6 != 4) goto LAB_00114e78;
                  if ((ulong)(param_2 - lVar20) <= uVar33) goto LAB_001142e0;
                  if (param_1 == (char *)0x0) goto LAB_00114af7;
LAB_00114ab1:
                  if (bVar30 == 0) {
                    memcpy(param_1,pcVar32,uVar17);
                  }
                  else if (uVar17 != 0) {
                    pp_Var11 = __ctype_toupper_loc();
                    sVar19 = uVar17;
                    do {
                      sVar19 = sVar19 - 1;
                      param_1[sVar19] = (char)(*pp_Var11)[(byte)pcVar32[sVar19]];
                    } while (sVar19 != 0);
                  }
                  param_1 = param_1 + uVar17;
                }
LAB_00114af7:
                lVar14 = lVar20 + uVar33;
                goto LAB_0011426f;
              case 0x77:
                if (uVar23 != 0x45) {
                  iVar24 = 1;
                  uVar16 = param_4->tm_wday;
                  goto LAB_00114f10;
                }
                break;
              case 0x79:
                if (uVar23 != 0x45) {
                  uVar25 = param_4->tm_year % 100;
                  uVar16 = uVar25;
                  if ((int)uVar25 < 0) {
                    uVar16 = uVar25 + 100;
                    if (param_4->tm_year < -0x76c) {
                      uVar16 = -uVar25;
                    }
                  }
joined_r0x00114925:
                  if (iVar6 == 0) {
                    iVar6 = param_6;
                  }
                  if (iVar6 == 2) {
                    local_4b8._0_1_ = false;
                    iVar24 = 2;
LAB_00115b1d:
                    iVar6 = 2;
                    bVar34 = iVar24 < iVar7;
                    bVar4 = (bool)(local_4b8._0_1_ ^ 1);
                  }
                  else {
                    bVar34 = false;
                    bVar4 = true;
                    iVar24 = 2;
                    local_4b8._0_1_ = false;
                  }
                  goto LAB_00114950;
                }
                goto switchD_00114487_caseD_72;
              case 0x7a:
                uVar33 = 0;
                pcVar29 = pcVar31;
LAB_001151b0:
                pcVar31 = pcVar29;
                if (-1 < param_4->tm_isdst) {
                  iVar9 = (int)param_4->tm_gmtoff;
                  if (iVar9 == 0) {
                    local_4b8._0_1_ = *param_4->tm_zone == '-';
                  }
                  else {
                    local_4b8._0_1_ = (bool)((byte)((ulong)param_4->tm_gmtoff >> 0x1f) & 1);
                  }
                  uVar16 = iVar9 / 0xe10;
                  iVar26 = (iVar9 / 0x3c) % 0x3c;
                  if (uVar33 == 2) {
LAB_00115e4d:
                    iVar24 = 9;
                    bVar34 = true;
                    bVar4 = (bool)(local_4b8._0_1_ ^ 1);
                    uVar25 = 0x14;
                    uVar16 = uVar16 * 10000 + iVar26 * 100 + iVar9 % 0x3c;
                  }
                  else if (uVar33 < 3) {
                    if (uVar33 == 0) {
                      bVar34 = true;
                      iVar24 = 5;
                      bVar4 = (bool)(local_4b8._0_1_ ^ 1);
                      uVar16 = uVar16 * 100 + iVar26;
                      uVar25 = 0;
                    }
                    else {
LAB_00115251:
                      bVar34 = true;
                      iVar24 = 6;
                      bVar4 = (bool)(local_4b8._0_1_ ^ 1);
                      uVar16 = uVar16 * 100 + iVar26;
                      uVar25 = 4;
                    }
                  }
                  else {
                    pcVar32 = pcVar29;
                    if (uVar33 != 3) break;
                    if (iVar9 % 0x3c != 0) goto LAB_00115e4d;
                    if (iVar26 != 0) goto LAB_00115251;
                    iVar24 = 3;
                    bVar34 = true;
                    bVar4 = (bool)(local_4b8._0_1_ ^ 1);
                    uVar25 = 0;
                  }
                  goto LAB_00114960;
                }
                goto LAB_0011426f;
              }
switchD_00114487_caseD_1:
              lVar14 = (long)pcVar32 - (long)param_3;
              uVar17 = lVar14 + 1;
              pcVar31 = pcVar32;
              uVar33 = uVar17;
              if ((iVar6 == 4) || (iVar7 < 0)) {
                if (uVar17 < (ulong)(param_2 - lVar20)) {
                  if (param_1 != (char *)0x0) goto LAB_00114523;
                  goto LAB_001145b0;
                }
                goto LAB_001142e0;
              }
              uVar18 = (ulong)iVar7;
              uVar33 = uVar18;
              if (uVar18 <= uVar17) {
                uVar33 = uVar17;
              }
              if ((ulong)(param_2 - lVar20) <= uVar33) goto LAB_001142e0;
              if (param_1 != (char *)0x0) {
                if (uVar17 < uVar18) {
                  sVar19 = uVar18 - uVar17;
                  if (iVar6 - 1U < 2) {
                    memset(param_1,0x30,sVar19);
                  }
                  else {
                    memset(param_1,0x20,sVar19);
                  }
                  param_1 = param_1 + sVar19;
                }
LAB_00114523:
                if (bVar30 == 0) {
                  memcpy(param_1,param_3,uVar17);
                }
                else if (uVar17 != 0) {
                  pp_Var11 = __ctype_toupper_loc();
                  do {
                    param_1[lVar14] = (char)(*pp_Var11)[(byte)param_3[lVar14]];
                    bVar34 = lVar14 != 0;
                    lVar14 = lVar14 + -1;
                  } while (bVar34);
                }
                param_1 = param_1 + uVar17;
              }
LAB_001145b0:
              lVar14 = lVar20 + uVar33;
              goto LAB_0011426f;
            }
            iVar6 = 3;
          }
          goto LAB_00114380;
        }
LAB_001143c0:
        iVar6 = 1;
      } while( true );
    }
    uVar17 = 0;
    if (-1 < (int)uVar33) {
      uVar17 = uVar33;
    }
    uVar18 = 1;
    if (uVar17 != 0) {
      uVar18 = uVar17;
    }
    if ((ulong)(param_2 - lVar20) <= uVar18) {
LAB_001142e0:
      *piVar10 = 0x22;
LAB_001142e8:
      lVar20 = 0;
      goto LAB_001142eb;
    }
    if (param_1 != (char *)0x0) {
      pcVar32 = param_1;
      if (1 < (int)uVar33) {
        pcVar32 = param_1 + (uVar17 - 1);
        memset(param_1,0x20,uVar17 - 1);
      }
      param_1 = pcVar32 + 1;
      *pcVar32 = *param_3;
    }
    lVar14 = lVar20 + uVar18;
LAB_0011426f:
    cVar3 = pcVar31[1];
    param_3 = pcVar31 + 1;
    uVar33 = 0xffffffffffffffff;
    lVar20 = lVar14;
  } while( true );
code_r0x001143a3:
  bVar13 = pcVar31[1];
  pcVar31 = pcVar31 + 1;
  bVar27 = 1;
  cVar3 = bVar13 - 0x30;
  bVar34 = false;
  if (cVar3 == '\0') goto LAB_001143c0;
  goto LAB_0011438e;
switchD_00114487_caseD_72:
  bVar27 = 0;
  goto LAB_001145e9;
}



void FUN_001160b0(void)

{
  FUN_00114180();
  return;
}



void FUN_001160e0(void)

{
  undefined8 uVar1;
  
  uVar1 = dcgettext("gnulib","memory exhausted",5);
  __fprintf_chk(stderr,1,"%s\n",uVar1);
                    // WARNING: Subroutine does not return
  exit(DAT_001271f8);
}



long * FUN_00116130(long *param_1,long param_2,long param_3,undefined8 param_4,undefined8 param_5)

{
  long lVar1;
  long *plVar2;
  long lVar3;
  ulong uVar4;
  
  uVar4 = param_3 - 1;
  if (param_3 == 0) {
    uVar4 = 0xf;
  }
  if (param_2 == 0) {
    param_2 = 0xfe0;
  }
  param_1[6] = uVar4;
  *param_1 = param_2;
  if ((*(byte *)(param_1 + 10) & 1) == 0) {
    plVar2 = (long *)(*(code *)param_1[7])();
  }
  else {
    param_2 = param_1[9];
    plVar2 = (long *)(*(code *)param_1[7])();
  }
  param_1[1] = (long)plVar2;
  if (plVar2 != (long *)0x0) {
    lVar3 = (long)(plVar2 + 2) + (-(long)(plVar2 + 2) & uVar4);
    lVar1 = *param_1;
    param_1[2] = lVar3;
    param_1[3] = lVar3;
    *plVar2 = lVar1 + (long)plVar2;
    param_1[4] = lVar1 + (long)plVar2;
    plVar2[1] = 0;
    *(byte *)(param_1 + 10) = *(byte *)(param_1 + 10) & 0xf9;
    return plVar2;
  }
  (*(code *)obstack_alloc_failed_handler)();
  *(byte *)(param_2 + 0x50) = *(byte *)(param_2 + 0x50) & 0xfe;
  *(undefined8 *)(param_2 + 0x38) = param_4;
  *(undefined8 *)(param_2 + 0x40) = param_5;
  FUN_00116130();
  return (long *)0x1;
}



undefined8
FUN_001161c0(long param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
            undefined8 param_5)

{
  *(byte *)(param_1 + 0x50) = *(byte *)(param_1 + 0x50) & 0xfe;
  *(undefined8 *)(param_1 + 0x38) = param_4;
  *(undefined8 *)(param_1 + 0x40) = param_5;
  FUN_00116130();
  return 1;
}



undefined8
FUN_001161f0(long param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
            undefined8 param_5,undefined8 param_6)

{
  *(byte *)(param_1 + 0x50) = *(byte *)(param_1 + 0x50) | 1;
  *(undefined8 *)(param_1 + 0x38) = param_4;
  *(undefined8 *)(param_1 + 0x40) = param_5;
  *(undefined8 *)(param_1 + 0x48) = param_6;
  FUN_00116130();
  return 1;
}



void * FUN_00116220(ulong *param_1,ulong param_2)

{
  ulong uVar1;
  ulong *puVar2;
  void *pvVar3;
  ulong *puVar4;
  ulong uVar5;
  ulong *puVar6;
  ulong *puVar7;
  ulong __n;
  void *__dest;
  bool bVar8;
  
  __n = param_1[3] - param_1[2];
  uVar5 = param_2 + __n;
  uVar1 = param_1[1];
  bVar8 = CARRY8(uVar5,param_1[6]);
  puVar6 = (ulong *)(uVar5 + param_1[6]);
  puVar4 = (ulong *)CONCAT71((int7)((ulong)param_1 >> 8),bVar8);
  puVar7 = (ulong *)((long)puVar6 + (__n >> 3) + 100);
  if (puVar6 < (ulong *)*param_1) {
    puVar6 = (ulong *)*param_1;
  }
  if (puVar6 <= puVar7) {
    puVar6 = puVar7;
  }
  puVar7 = puVar6;
  if ((!CARRY8(param_2,__n)) && (puVar4 = (ulong *)(ulong)bVar8, puVar4 == (ulong *)0x0)) {
    if ((param_1[10] & 1) == 0) {
      puVar4 = puVar6;
      puVar2 = (ulong *)(*(code *)param_1[7])();
    }
    else {
      puVar4 = (ulong *)param_1[9];
      puVar2 = (ulong *)(*(code *)param_1[7])();
    }
    if (puVar2 != (ulong *)0x0) {
      param_1[1] = (ulong)puVar2;
      puVar2[1] = uVar1;
      pvVar3 = (void *)param_1[2];
      param_1[4] = (long)puVar2 + (long)puVar6;
      *puVar2 = (long)puVar2 + (long)puVar6;
      __dest = (void *)((long)(puVar2 + 2) + (-(long)(puVar2 + 2) & param_1[6]));
      pvVar3 = memcpy(__dest,pvVar3,__n);
      uVar5 = param_1[10];
      if ((uVar5 & 2) == 0) {
        pvVar3 = (void *)(uVar1 + 0x10 + (-(uVar1 + 0x10) & param_1[6]));
        if ((void *)param_1[2] == pvVar3) {
          puVar2[1] = *(ulong *)(uVar1 + 8);
          if ((uVar5 & 1) == 0) {
            pvVar3 = (void *)(*(code *)param_1[8])(uVar1);
          }
          else {
            pvVar3 = (void *)(*(code *)param_1[8])(param_1[9],uVar1);
          }
        }
      }
      param_1[2] = (ulong)__dest;
      *(byte *)(param_1 + 10) = (byte)param_1[10] & 0xfd;
      param_1[3] = (long)__dest + __n;
      return pvVar3;
    }
  }
  (*(code *)obstack_alloc_failed_handler)();
  puVar4 = (ulong *)puVar4[1];
  if (puVar4 == (ulong *)0x0) {
    return (void *)0x0;
  }
  while ((puVar7 <= puVar4 || ((ulong *)*puVar4 < puVar7))) {
    puVar4 = (ulong *)puVar4[1];
    if (puVar4 == (ulong *)0x0) {
      return (void *)0x0;
    }
  }
  return (void *)0x1;
}



undefined8 FUN_00116350(long param_1,ulong *param_2)

{
  ulong *puVar1;
  
  puVar1 = *(ulong **)(param_1 + 8);
  if (puVar1 == (ulong *)0x0) {
    return 0;
  }
  while ((param_2 <= puVar1 || ((ulong *)*puVar1 < param_2))) {
    puVar1 = (ulong *)puVar1[1];
    if (puVar1 == (ulong *)0x0) {
      return 0;
    }
  }
  return 1;
}



void FUN_00116390(long param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 8);
  while( true ) {
    if (puVar3 == (undefined8 *)0x0) {
      if (param_2 == (undefined8 *)0x0) {
        return;
      }
                    // WARNING: Subroutine does not return
      abort();
    }
    if ((puVar3 < param_2) && (param_2 <= (undefined8 *)*puVar3)) break;
    puVar2 = (undefined8 *)puVar3[1];
    if ((*(byte *)(param_1 + 0x50) & 1) == 0) {
      (**(code **)(param_1 + 0x40))(puVar3);
      *(byte *)(param_1 + 0x50) = *(byte *)(param_1 + 0x50) | 2;
      puVar3 = puVar2;
    }
    else {
      (**(code **)(param_1 + 0x40))(*(undefined8 *)(param_1 + 0x48));
      *(byte *)(param_1 + 0x50) = *(byte *)(param_1 + 0x50) | 2;
      puVar3 = puVar2;
    }
  }
  uVar1 = *puVar3;
  *(undefined8 **)(param_1 + 8) = puVar3;
  *(undefined8 **)(param_1 + 0x10) = param_2;
  *(undefined8 **)(param_1 + 0x18) = param_2;
  *(undefined8 *)(param_1 + 0x20) = uVar1;
  return;
}



long FUN_00116420(long param_1)

{
  long *plVar1;
  long lVar2;
  
  lVar2 = 0;
  for (plVar1 = *(long **)(param_1 + 8); plVar1 != (long *)0x0; plVar1 = (long *)plVar1[1]) {
    lVar2 = lVar2 + (*plVar1 - (long)plVar1);
  }
  return lVar2;
}



void FUN_00116460(char *param_1)

{
  int iVar1;
  char *pcVar2;
  char *pcVar3;
  
  if (param_1 == (char *)0x0) {
    fwrite("A NULL argv[0] was passed through an exec system call.\n",1,0x37,stderr);
                    // WARNING: Subroutine does not return
    abort();
  }
  pcVar2 = strrchr(param_1,0x2f);
  pcVar3 = param_1;
  if ((((pcVar2 != (char *)0x0) && (pcVar3 = pcVar2 + 1, 6 < (long)pcVar3 - (long)param_1)) &&
      (iVar1 = strncmp(pcVar2 + -6,"/.libs/",7), iVar1 == 0)) &&
     (((param_1 = pcVar3, pcVar2[1] == 'l' && (pcVar2[2] == 't')) && (pcVar2[3] == '-')))) {
    pcVar3 = pcVar2 + 4;
    param_1 = pcVar3;
  }
  DAT_00128448 = param_1;
  program_invocation_name = param_1;
  program_invocation_short_name = pcVar3;
  return;
}



long FUN_00116520(long param_1,long param_2)

{
  int iVar1;
  long lVar2;
  undefined8 uVar3;
  
  lVar2 = dcgettext(0,param_1,5);
  if (param_1 != lVar2) {
    return lVar2;
  }
  uVar3 = FUN_0011ac70();
  iVar1 = FUN_0011aa10(uVar3,"UTF-8");
  if (iVar1 == 0) {
    lVar2 = param_2;
  }
  return lVar2;
}



char * FUN_00116580(char *param_1,int param_2)

{
  byte *pbVar1;
  char *pcVar2;
  
  pbVar1 = (byte *)FUN_0011ac70();
  if ((*pbVar1 & 0xdf) == 0x55) {
    if (((((pbVar1[1] & 0xdf) == 0x54) && ((pbVar1[2] & 0xdf) == 0x46)) && (pbVar1[3] == 0x2d)) &&
       ((pbVar1[4] == 0x38 && (pbVar1[5] == 0)))) {
      pcVar2 = &DAT_0011d670;
      if (*param_1 == '`') {
        pcVar2 = &DAT_0011d67d;
      }
      return pcVar2;
    }
  }
  else if (((((*pbVar1 & 0xdf) == 0x47) && ((pbVar1[1] & 0xdf) == 0x42)) && (pbVar1[2] == 0x31)) &&
          (((pbVar1[3] == 0x38 && (pbVar1[4] == 0x30)) &&
           ((pbVar1[5] == 0x33 && ((pbVar1[6] == 0x30 && (pbVar1[7] == 0)))))))) {
    pcVar2 = &DAT_0011d674;
    if (*param_1 == '`') {
      pcVar2 = &DAT_0011d679;
    }
    return pcVar2;
  }
  pcVar2 = "\'";
  if (param_2 == 9) {
    pcVar2 = "\"";
  }
  return pcVar2;
}



ulong FUN_00116660(undefined1 *param_1,ulong param_2,char *param_3,ulong param_4,int param_5,
                  uint param_6,long param_7,char *param_8,char *param_9)

{
  byte bVar1;
  bool bVar2;
  byte bVar3;
  bool bVar4;
  int iVar5;
  int iVar6;
  size_t sVar7;
  ushort **ppuVar8;
  ulong uVar9;
  char cVar10;
  ulong uVar11;
  ulong uVar12;
  ulong uVar13;
  ulong uVar14;
  uint uVar15;
  bool bVar16;
  byte *pbVar18;
  byte *__s1;
  ulong uVar19;
  long in_FS_OFFSET;
  bool bVar20;
  bool bVar21;
  bool bVar22;
  bool bVar23;
  bool bVar24;
  bool local_d1;
  long local_c8;
  size_t local_c0;
  byte local_b8;
  bool local_b7;
  bool local_b6;
  bool local_b5;
  int local_b4;
  char *local_98;
  ulong local_90;
  uint local_80;
  bool local_7c;
  bool local_7a;
  bool local_79;
  char *local_68;
  char *local_60;
  wint_t local_4c;
  undefined8 local_48;
  long local_40;
  bool bVar17;
  
  local_c8 = param_7;
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  local_60 = param_8;
  local_68 = param_9;
  local_b4 = param_5;
  local_80 = param_6;
LAB_001166d0:
  sVar7 = __ctype_get_mb_cur_max();
  local_b8 = 1;
  local_7a = false;
  local_b6 = false;
  local_c0 = 0;
  local_d1 = (bool)((byte)(local_80 >> 1) & 1);
  local_98 = (char *)0x0;
  local_90 = 0;
  uVar12 = param_2;
  do {
    switch(local_b4) {
    case 0:
      local_79 = local_b6;
      local_7c = false;
      local_b7 = false;
      bVar21 = local_c0 != 1;
      local_b5 = (bool)(local_b6 ^ 1);
      uVar13 = 0;
      bVar22 = (bool)(local_c0 != 0 & local_b6);
      local_d1 = false;
      break;
    case 2:
      if (local_d1 == false) {
LAB_00116ea3:
        if (uVar12 != 0) {
          *param_1 = 0x27;
        }
        bVar22 = false;
        uVar13 = 1;
        local_b5 = true;
        local_7c = false;
        local_b7 = true;
        bVar21 = false;
        local_79 = false;
        local_d1 = false;
        local_c0 = 1;
        local_98 = "\'";
        local_b4 = 2;
      }
      else {
        local_b7 = local_d1;
        bVar22 = false;
        uVar13 = 0;
        bVar21 = false;
        local_79 = false;
        local_c0 = 1;
        local_98 = "\'";
        local_b5 = local_b7;
        local_7c = local_b7;
      }
      break;
    case 3:
      local_b6 = true;
      goto LAB_00116df7;
    case 4:
      if (local_d1 == false) {
        local_b6 = true;
        goto LAB_00116ea3;
      }
    case 1:
LAB_00116df7:
      bVar22 = false;
      local_79 = false;
      bVar21 = false;
      local_7c = true;
      local_b5 = true;
      local_b7 = true;
      local_d1 = true;
      local_b4 = 2;
      uVar13 = 0;
      local_c0 = 1;
      local_98 = "\'";
      break;
    case 5:
      if (local_d1 != false) goto switchD_00116736_caseD_6;
      if (uVar12 != 0) {
        *param_1 = 0x22;
      }
      local_b5 = false;
      uVar13 = 1;
      local_7c = false;
      local_b7 = false;
      bVar21 = false;
      bVar22 = true;
      local_79 = true;
      local_b6 = true;
      local_c0 = 1;
      local_98 = "\"";
      break;
    case 6:
switchD_00116736_caseD_6:
      bVar22 = true;
      uVar13 = 0;
      local_b5 = false;
      local_7c = false;
      local_b7 = false;
      bVar21 = false;
      local_79 = true;
      local_d1 = true;
      local_b6 = true;
      local_c0 = 1;
      local_98 = "\"";
      local_b4 = 5;
      break;
    case 7:
      local_b5 = false;
      local_7c = false;
      bVar21 = local_c0 != 1;
      local_b7 = false;
      bVar22 = local_c0 != 0;
      uVar13 = 0;
      local_79 = true;
      local_d1 = false;
      local_b6 = true;
      break;
    case 8:
    case 9:
    case 10:
      if (local_b4 != 10) {
        local_60 = (char *)dcgettext("gnulib",&DAT_0011d681,5);
        if (local_60 == "`") {
          local_60 = (char *)FUN_00116580(&DAT_0011d681,local_b4);
        }
        local_68 = (char *)dcgettext("gnulib","\'",5);
        if (local_68 == "\'") {
          local_68 = (char *)FUN_00116580("\'");
        }
      }
      uVar13 = 0;
      if (local_d1 == false) {
        cVar10 = *local_60;
        while (cVar10 != '\0') {
          if (uVar13 < uVar12) {
            param_1[uVar13] = cVar10;
          }
          uVar13 = uVar13 + 1;
          cVar10 = local_60[uVar13];
        }
      }
      local_c0 = strlen(local_68);
      local_98 = local_68;
      bVar21 = local_c0 != 1;
      local_b5 = false;
      local_7c = false;
      local_b7 = false;
      local_79 = true;
      local_b6 = true;
      bVar22 = local_c0 != 0;
      break;
    default:
                    // WARNING: Subroutine does not return
      abort();
    }
    bVar4 = false;
    uVar19 = 0;
LAB_001167f9:
    bVar23 = param_4 != uVar19;
    param_2 = uVar12;
    if (param_4 == 0xffffffffffffffff) goto LAB_00116928;
LAB_00116810:
    param_2 = uVar12;
    if (bVar23 != false) {
      do {
        __s1 = (byte *)(param_3 + uVar19);
        uVar14 = uVar13;
        uVar12 = param_2;
        iVar6 = local_b4;
        bVar17 = bVar4;
        bVar20 = bVar23;
        if (bVar22 == false) {
LAB_0011682d:
          bVar3 = *__s1;
          uVar15 = (uint)bVar3;
          if ((char)bVar3 < '@') {
            switch(bVar3) {
            case 0:
              goto switchD_00116860_caseD_0;
            default:
              goto switchD_00116860_caseD_1;
            case 7:
              goto switchD_00116860_caseD_7;
            case 8:
              goto switchD_00116860_caseD_8;
            case 9:
              goto switchD_00116860_caseD_9;
            case 10:
              uVar9 = 10;
              bVar3 = 0x6e;
              bVar24 = false;
              goto LAB_00116bed;
            case 0xb:
              goto switchD_00116860_caseD_b;
            case 0xc:
              goto switchD_00116860_caseD_c;
            case 0xd:
              goto switchD_00116860_caseD_d;
            case 0x20:
              bVar16 = false;
              uVar15 = 0x20;
              goto LAB_00116a85;
            case 0x21:
            case 0x22:
            case 0x24:
            case 0x26:
            case 0x28:
            case 0x29:
            case 0x2a:
            case 0x3b:
            case 0x3c:
            case 0x3d:
            case 0x3e:
              goto switchD_00116860_caseD_21;
            case 0x23:
              uVar15 = 0x23;
              bVar16 = false;
              goto LAB_00116d60;
            case 0x25:
            case 0x2b:
            case 0x2c:
            case 0x2d:
            case 0x2e:
            case 0x2f:
            case 0x30:
            case 0x31:
            case 0x32:
            case 0x33:
            case 0x34:
            case 0x35:
            case 0x36:
            case 0x37:
            case 0x38:
            case 0x39:
            case 0x3a:
              goto switchD_00116860_caseD_25;
            case 0x27:
              goto switchD_00116860_caseD_27;
            case 0x3f:
              goto switchD_00116860_caseD_3f;
            }
          }
          if ('z' < (char)bVar3) {
            if (bVar3 == 0x7d) {
LAB_001175f0:
              bVar16 = false;
              if (param_4 == 0xffffffffffffffff) {
LAB_001175fd:
                bVar24 = param_3[1] != '\0';
              }
              else {
LAB_00117526:
                bVar24 = param_4 != 1;
              }
              if (bVar24) {
                uVar9 = uVar19;
                bVar20 = false;
                bVar24 = bVar16;
                goto joined_r0x00116b40;
              }
LAB_00116d60:
              if (uVar19 != 0) {
                uVar9 = uVar19;
                bVar20 = false;
                bVar24 = bVar16;
                goto joined_r0x00116b40;
              }
              goto LAB_00116a85;
            }
            if ((char)bVar3 < '~') goto LAB_00117512;
LAB_00117590:
            bVar24 = false;
            bVar16 = false;
            uVar9 = uVar19;
            if ((char)uVar15 == '~') goto LAB_00116d60;
joined_r0x00117084:
            bVar16 = local_b6;
            if (sVar7 == 1) {
              ppuVar8 = __ctype_b_loc();
              uVar11 = 1;
              bVar3 = (byte)((*ppuVar8)[uVar15] >> 8) & 0x40;
              bVar20 = (bool)(bVar3 >> 6);
              bVar2 = (bool)((bVar3 >> 6 ^ 1) & local_b6);
              goto LAB_00116a09;
            }
            local_48 = 0;
            if (param_4 == 0xffffffffffffffff) {
              param_4 = strlen(param_3);
            }
            uVar11 = FUN_00113b30(&local_4c,__s1,param_4 - uVar9,&local_48);
            if (uVar11 == 0) goto joined_r0x00116b40;
            bVar2 = local_b6;
            if (uVar11 == 0xffffffffffffffff) {
              bVar20 = false;
              uVar11 = 0;
LAB_00116a09:
              if (bVar2 != false) {
                bVar23 = false;
                goto joined_r0x0011774d;
              }
              goto joined_r0x00116b40;
            }
            if (uVar11 == 0xfffffffffffffffe) {
              uVar11 = 0;
              if (uVar9 < param_4) {
                do {
                  if (__s1[uVar11] == 0) break;
                  uVar11 = uVar11 + 1;
                } while (param_4 - uVar9 != uVar11);
LAB_00117a50:
                if (1 < uVar11) {
                  bVar23 = false;
                  goto joined_r0x0011774d;
                }
                bVar20 = false;
              }
              else {
                bVar20 = false;
              }
              goto LAB_00116a09;
            }
            if (local_7c == false) {
              iVar6 = iswprint(local_4c);
              if (iVar6 == 0) goto LAB_00117a50;
              if (uVar11 != 1) goto LAB_00117db8;
              goto joined_r0x00116b40;
            }
            if (uVar11 == 1) {
              iVar6 = iswprint(local_4c);
              if (iVar6 == 0) {
                bVar20 = false;
                goto LAB_00116a09;
              }
              goto joined_r0x00116b40;
            }
            pbVar18 = (byte *)(param_3 + uVar9 + 1);
            do {
              while (0x21 < (byte)(*pbVar18 - 0x5b)) {
                pbVar18 = pbVar18 + 1;
                if (__s1 + uVar11 == pbVar18) goto LAB_00117ba7;
              }
              if ((0x20000002bU >> ((ulong)(*pbVar18 - 0x5b) & 0x3f) & 1) != 0) goto LAB_00116a8f;
              pbVar18 = pbVar18 + 1;
            } while (__s1 + uVar11 != pbVar18);
LAB_00117ba7:
            iVar6 = iswprint(local_4c);
            if (iVar6 == 0) {
              bVar23 = false;
            }
            else {
LAB_00117db8:
              bVar16 = false;
            }
joined_r0x0011774d:
            uVar19 = uVar9 + 1;
            uVar11 = uVar11 + uVar9;
            if (bVar16 == false) {
              if (bVar24 != false) {
                if (uVar13 < param_2) {
                  param_1[uVar13] = 0x5c;
                }
                uVar13 = uVar13 + 1;
              }
LAB_00117c1b:
              bVar1 = (byte)uVar15;
              if (uVar19 < uVar11) {
                do {
                  bVar1 = (byte)uVar15;
                  if (bVar4 != false) {
                    if (uVar13 < param_2) {
                      param_1[uVar13] = 0x27;
                    }
                    if (uVar13 + 1 < param_2) {
                      param_1[uVar13 + 1] = 0x27;
                    }
                    if (uVar13 + 2 < param_2) goto LAB_00117c90;
                    uVar13 = uVar13 + 3;
                    bVar1 = param_3[uVar19];
                    uVar19 = uVar19 + 1;
                    if (uVar11 <= uVar19) {
                      bVar4 = false;
                      break;
                    }
                    bVar4 = false;
                  }
                  if (uVar13 < param_2) {
                    param_1[uVar13] = bVar1;
                  }
                  uVar13 = uVar13 + 1;
                  bVar1 = param_3[uVar19];
                  uVar15 = (uint)bVar1;
                  uVar19 = uVar19 + 1;
                  if (uVar11 <= uVar19) break;
                } while( true );
              }
              local_b8 = local_b8 & bVar23;
              uVar14 = uVar13;
              bVar17 = bVar4;
              goto LAB_00116a51;
            }
            if (local_d1 != false) goto LAB_0011794b;
            while( true ) {
              bVar23 = (bool)((bVar4 ^ 1U) & local_b7);
              if (bVar23 != false) {
                if (uVar13 < param_2) {
                  param_1[uVar13] = 0x27;
                }
                if (uVar13 + 1 < param_2) {
                  param_1[uVar13 + 1] = 0x24;
                }
                if (uVar13 + 2 < param_2) {
                  param_1[uVar13 + 2] = 0x27;
                }
                uVar13 = uVar13 + 3;
                bVar4 = bVar23;
              }
              if (uVar13 < param_2) {
                param_1[uVar13] = 0x5c;
              }
              bVar3 = (byte)uVar15;
              if (uVar13 + 1 < param_2) {
                param_1[uVar13 + 1] = (bVar3 >> 6) + 0x30;
              }
              if (uVar13 + 2 < param_2) {
                param_1[uVar13 + 2] = (bVar3 >> 3 & 7) + 0x30;
              }
              uVar14 = uVar13 + 3;
              bVar1 = (bVar3 & 7) + 0x30;
              if (uVar11 <= uVar19) break;
              if (uVar14 < param_2) {
                param_1[uVar14] = bVar1;
              }
              uVar13 = uVar13 + 4;
              uVar15 = (uint)(byte)param_3[uVar19];
              uVar19 = uVar19 + 1;
            }
            local_b8 = 0;
            goto LAB_0011690a;
          }
          if (bVar3 == 0x40) {
switchD_00116860_caseD_1:
            uVar9 = uVar19;
            bVar24 = false;
            goto joined_r0x00117084;
          }
          uVar9 = 1L << (bVar3 + 0xbf & 0x3f);
          if ((uVar9 & 0x3ffffff53ffffff) != 0) {
switchD_00116860_caseD_25:
            if (local_b5 != false) {
              if (local_d1 == false) goto LAB_00117840;
              if (local_c8 != 0) {
                bVar24 = false;
                uVar9 = (ulong)uVar15;
                bVar20 = local_d1;
                goto LAB_00116b00;
              }
LAB_00117630:
              bVar1 = (byte)uVar15;
              bVar2 = local_d1;
              goto LAB_00117637;
            }
            if (local_c8 != 0) {
              bVar24 = false;
              goto LAB_00116885;
            }
            bVar16 = false;
            bVar17 = bVar23;
            goto LAB_00116a42;
          }
LAB_00117372:
          if ((uVar9 & 0xa4000000) != 0) goto switchD_00116860_caseD_21;
          if (local_b4 != 2) {
            if (local_b6 == false) {
              bVar24 = false;
              bVar16 = false;
              goto LAB_00116b48;
            }
            if (local_d1 == false) {
LAB_001179a9:
              local_b8 = 0;
              uVar19 = uVar19 + 1;
              bVar3 = 0x5c;
              bVar1 = (bVar4 ^ 1U) & local_b7;
              goto LAB_001168c9;
            }
            if (local_c0 != 0) goto LAB_001175bb;
            goto LAB_00116ab3;
          }
          if (local_d1 != false) goto LAB_00116aa0;
LAB_001175bb:
          uVar19 = uVar19 + 1;
          if (bVar4 != false) {
            local_b8 = 0;
            bVar1 = 0x5c;
            goto LAB_00116a59;
          }
          if (uVar13 < param_2) {
            local_b8 = 0;
            bVar1 = 0x5c;
            goto LAB_0011690f;
          }
          local_b8 = 0;
          uVar13 = uVar13 + 1;
          goto LAB_001167f9;
        }
        if ((param_4 == 0xffffffffffffffff) && (bVar21)) {
          param_4 = strlen(param_3);
        }
        if (local_c0 + uVar19 <= param_4) {
          iVar5 = memcmp(__s1,local_98,local_c0);
          if (iVar5 != 0) {
            bVar3 = *__s1;
            uVar15 = (uint)bVar3;
            if ('?' < (char)bVar3) {
              if ('z' < (char)bVar3) {
                if (bVar3 == 0x7d) goto LAB_001175f0;
                goto LAB_00117584;
              }
              goto LAB_00117404;
            }
            goto LAB_001173c6;
          }
          if (local_d1 == false) {
            bVar3 = *__s1;
            uVar15 = (uint)bVar3;
            uVar9 = uVar19;
            bVar24 = bVar22;
            bVar16 = bVar22;
            if ('?' < (char)bVar3) {
              if ('z' < (char)bVar3) {
                if (bVar3 != 0x7d) {
                  if ('}' < (char)bVar3) {
                    if (bVar3 == 0x7e) goto LAB_00116d60;
                    uVar15 = 0x7f;
                    goto joined_r0x00117084;
                  }
                  if (bVar3 != 0x7b) {
                    uVar15 = 0x7c;
                    bVar20 = false;
                    goto LAB_00116a85;
                  }
                }
                goto LAB_0011751c;
              }
              if (bVar3 == 0x40) goto switchD_0011704a_caseD_1;
              uVar11 = 1L << (bVar3 + 0xbf & 0x3f);
              if ((uVar11 & 0x3ffffff53ffffff) != 0) goto switchD_0011704a_caseD_25;
              if ((uVar11 & 0xa4000000) != 0) goto switchD_0011704a_caseD_21;
              if (local_b4 == 2) goto LAB_001175bb;
              if (local_b6 != false) goto LAB_001179a9;
              bVar16 = false;
              bVar20 = false;
              goto LAB_00116b52;
            }
            switch(uVar15) {
            case 0:
              goto joined_r0x00117213;
            default:
switchD_0011704a_caseD_1:
              goto joined_r0x00117084;
            case 7:
              if (local_b6 != false) {
                bVar3 = 0x61;
                bVar16 = false;
                goto LAB_001168b2;
              }
              local_b8 = 0;
              uVar19 = uVar19 + 1;
              bVar3 = 7;
              goto LAB_00116b64;
            case 8:
              if (local_b6 != false) {
                bVar16 = false;
                bVar3 = 0x62;
                uVar19 = uVar19 + 1;
                break;
              }
              bVar16 = false;
              uVar15 = 8;
              goto LAB_00116b50;
            case 9:
              goto LAB_00116be3;
            case 10:
              uVar9 = 10;
              bVar3 = 0x6e;
              goto LAB_00116bed;
            case 0xb:
              if (local_b6 == false) {
                bVar16 = false;
                uVar15 = 0xb;
                goto LAB_00116b50;
              }
              bVar16 = false;
              bVar3 = 0x76;
              uVar19 = uVar19 + 1;
              break;
            case 0xc:
              if (local_b6 == false) {
                bVar16 = false;
                uVar15 = 0xc;
                goto LAB_00116b50;
              }
              bVar16 = false;
              bVar3 = 0x66;
              uVar19 = uVar19 + 1;
              break;
            case 0xd:
              goto LAB_00116c03;
            case 0x20:
              uVar15 = 0x20;
              goto LAB_00116a85;
            case 0x21:
            case 0x22:
            case 0x24:
            case 0x26:
            case 0x28:
            case 0x29:
            case 0x2a:
            case 0x3b:
            case 0x3c:
            case 0x3d:
            case 0x3e:
switchD_0011704a_caseD_21:
              goto LAB_001171ae;
            case 0x23:
              uVar15 = 0x23;
              goto LAB_00116d60;
            case 0x25:
            case 0x2b:
            case 0x2c:
            case 0x2d:
            case 0x2e:
            case 0x2f:
            case 0x30:
            case 0x31:
            case 0x32:
            case 0x33:
            case 0x34:
            case 0x35:
            case 0x36:
            case 0x37:
            case 0x38:
            case 0x39:
            case 0x3a:
switchD_0011704a_caseD_25:
              if (local_b5 != false) {
                uVar19 = uVar19 + 1;
                goto LAB_00116b64;
              }
              bVar20 = bVar22;
              if (local_c8 != 0) goto LAB_00116885;
              goto LAB_001168b2;
            case 0x27:
              local_7a = bVar22;
              if (local_b4 != 2) {
                uVar15 = 0x27;
                bVar20 = bVar22;
                goto joined_r0x00116b40;
              }
              goto LAB_0011765c;
            case 0x3f:
              if (local_b4 == 2) {
                local_b8 = 0;
                uVar19 = uVar19 + 1;
                bVar3 = 0x3f;
                goto LAB_00116b64;
              }
              goto LAB_00116c56;
            }
            goto LAB_001168b7;
          }
LAB_0011794b:
          local_b6 = local_b7;
          goto LAB_00116aa0;
        }
        bVar3 = *__s1;
        uVar15 = (uint)bVar3;
        if ('?' < (char)bVar3) {
          if ((char)bVar3 < '{') {
LAB_00117404:
            if ((char)uVar15 == '@') goto switchD_00116860_caseD_1;
            uVar9 = 1L << ((char)uVar15 + 0xbfU & 0x3f);
            if ((uVar9 & 0x3ffffff53ffffff) == 0) goto LAB_00117372;
            goto switchD_001173eb_caseD_25;
          }
          if (bVar3 == 0x7d) {
            bVar16 = false;
            goto LAB_00117526;
          }
LAB_00117584:
          if ('}' < (char)uVar15) goto LAB_00117590;
LAB_00117512:
          bVar24 = false;
          bVar16 = false;
          if ((char)uVar15 == '{') {
LAB_0011751c:
            if (param_4 == 0xffffffffffffffff) goto LAB_001175fd;
            goto LAB_00117526;
          }
LAB_001171ae:
          bVar16 = bVar24;
          bVar20 = false;
          goto LAB_00116a85;
        }
LAB_001173c6:
        switch(uVar15) {
        case 0:
switchD_001173eb_caseD_0:
          if (local_d1 != false) goto LAB_0011794b;
          bVar24 = false;
          uVar9 = uVar19;
joined_r0x00117213:
          bVar20 = (bool)((bVar4 ^ 1U) & local_b7);
          if (bVar20 != false) {
            if (uVar13 < param_2) {
              param_1[uVar13] = 0x27;
            }
            if (uVar13 + 1 < param_2) {
              param_1[uVar13 + 1] = 0x24;
            }
            if (uVar13 + 2 < param_2) {
              param_1[uVar13 + 2] = 0x27;
            }
            uVar14 = uVar13 + 4;
            bVar4 = bVar20;
            if (param_2 <= uVar13 + 3) {
              bVar16 = false;
              bVar3 = 0x30;
              goto LAB_00116b52;
            }
            param_1[uVar13 + 3] = 0x5c;
            uVar19 = uVar9 + 1;
            if (bVar24 != false) {
              local_b8 = 0;
              bVar3 = 0x30;
              goto LAB_001168fc;
            }
            local_b8 = 0;
            bVar1 = 0x30;
            goto LAB_0011690a;
          }
          if (uVar13 < param_2) {
            param_1[uVar13] = 0x5c;
          }
          uVar14 = uVar13 + 1;
          uVar19 = uVar9 + 1;
          if (local_79 != false) {
            bVar16 = local_79;
            if ((uVar19 < param_4) && ((byte)(param_3[uVar9 + 1] - 0x30U) < 10)) {
              if (uVar14 < param_2) {
                param_1[uVar14] = 0x30;
              }
              if (uVar13 + 2 < param_2) {
                param_1[uVar13 + 2] = 0x30;
              }
              uVar14 = uVar13 + 3;
              if (local_c8 != 0) {
                bVar20 = false;
                uVar13 = uVar14;
                if ((*(byte *)(local_c8 + 6) & 1) != 0) goto LAB_001174d0;
                uVar15 = 0x30;
                uVar19 = uVar9;
                goto LAB_00116a39;
              }
              if (bVar24 != false) goto LAB_00117a05;
              local_b8 = 0;
              bVar1 = 0x30;
              goto LAB_0011690a;
            }
            if (local_c8 == 0) {
              if (bVar24 != false) {
LAB_00117a05:
                local_b8 = 0;
                bVar3 = 0x30;
                bVar24 = bVar4;
                goto LAB_001168fc;
              }
              local_b8 = 0;
              bVar1 = 0x30;
              goto LAB_0011690a;
            }
            bVar20 = false;
            uVar13 = uVar14;
            if ((*(byte *)(local_c8 + 6) & 1) != 0) {
LAB_001174d0:
              bVar16 = false;
              bVar3 = 0x30;
              goto LAB_001168b7;
            }
            uVar15 = 0x30;
            uVar19 = uVar9;
            goto LAB_00116a39;
          }
          local_b8 = 0;
          bVar1 = 0x30;
          bVar23 = bVar24 == false;
          bVar3 = 0x30;
          bVar24 = bVar4;
          if (bVar23) goto LAB_0011690a;
          goto LAB_001168fc;
        default:
          goto switchD_00116860_caseD_1;
        case 7:
switchD_00116860_caseD_7:
          if (local_b6 == false) {
            if (local_d1 == false) {
              local_b8 = 0;
              uVar19 = uVar19 + 1;
              bVar1 = 7;
            }
            else {
              if (local_c8 != 0) {
                bVar24 = false;
                bVar20 = false;
                uVar9 = 7;
                goto LAB_00116b00;
              }
              uVar19 = uVar19 + 1;
              local_b8 = 0;
              bVar1 = 7;
            }
            goto LAB_00116a51;
          }
          bVar20 = false;
          bVar3 = 0x61;
          goto LAB_001168a7;
        case 8:
switchD_00116860_caseD_8:
          uVar9 = 8;
          bVar24 = false;
          bVar3 = 0x62;
          break;
        case 9:
switchD_00116860_caseD_9:
          bVar24 = false;
LAB_00116be3:
          uVar9 = 9;
          bVar3 = 0x74;
          goto LAB_00116bed;
        case 10:
          uVar9 = (ulong)uVar15;
          bVar24 = false;
          bVar3 = 0x6e;
          goto LAB_00116bed;
        case 0xb:
switchD_00116860_caseD_b:
          uVar9 = 0xb;
          bVar24 = false;
          bVar3 = 0x76;
          break;
        case 0xc:
switchD_00116860_caseD_c:
          uVar9 = 0xc;
          bVar24 = false;
          bVar3 = 0x66;
          break;
        case 0xd:
switchD_00116860_caseD_d:
          bVar24 = false;
LAB_00116c03:
          uVar9 = 0xd;
          bVar3 = 0x72;
LAB_00116bed:
          if (local_7c != false) goto LAB_00116a8f;
          break;
        case 0x20:
          bVar16 = false;
          goto LAB_00116a85;
        case 0x21:
        case 0x22:
        case 0x24:
        case 0x26:
        case 0x28:
        case 0x29:
        case 0x2a:
        case 0x3b:
        case 0x3c:
        case 0x3d:
        case 0x3e:
switchD_00116860_caseD_21:
          bVar16 = false;
          bVar20 = false;
LAB_00116a85:
          uVar9 = uVar19;
          bVar24 = bVar16;
          if (local_7c == false) {
joined_r0x00116b40:
            uVar19 = uVar9;
            bVar16 = bVar20;
            if (local_b5 != false) {
LAB_00116b48:
              uVar9 = (ulong)uVar15;
              bVar2 = bVar16;
              if (local_d1 == false) goto LAB_00116b50;
              goto LAB_00116af4;
            }
            if (local_c8 != 0) {
LAB_00116885:
              bVar1 = (byte)uVar15 >> 5;
              goto LAB_00116896;
            }
            goto LAB_00116a37;
          }
          goto LAB_00116a8f;
        case 0x23:
          bVar16 = false;
          goto LAB_00116d60;
        case 0x25:
        case 0x2b:
        case 0x2c:
        case 0x2d:
        case 0x2e:
        case 0x2f:
        case 0x30:
        case 0x31:
        case 0x32:
        case 0x33:
        case 0x34:
        case 0x35:
        case 0x36:
        case 0x37:
        case 0x38:
        case 0x39:
        case 0x3a:
switchD_001173eb_caseD_25:
          if (local_b5 != false) {
            if (local_d1 == false) {
LAB_00117840:
              bVar3 = (byte)uVar15;
              bVar20 = false;
              uVar9 = uVar19;
              bVar16 = local_b5;
              bVar24 = false;
              goto LAB_00116b52;
            }
            if (local_c8 == 0) goto LAB_00117630;
            uVar9 = (ulong)uVar15;
            bVar24 = false;
            bVar20 = local_d1;
            goto LAB_00116b00;
          }
          if (local_c8 == 0) {
            bVar16 = false;
            bVar17 = bVar22;
            goto LAB_00116a42;
          }
          bVar24 = false;
          bVar20 = bVar22;
          goto LAB_00116885;
        case 0x27:
switchD_00116860_caseD_27:
          if (local_b4 != 2) {
            uVar15 = 0x27;
            uVar9 = uVar19;
            local_7a = bVar23;
            bVar24 = false;
            goto joined_r0x00116b40;
          }
          if (local_d1 == false) {
            local_7a = false;
LAB_0011765c:
            bVar20 = local_90 == 0;
            if (param_2 == 0 || !bVar20) {
              if (uVar13 < param_2) {
                param_1[uVar13] = 0x27;
              }
              if (uVar13 + 1 < param_2) {
                param_1[uVar13 + 1] = 0x5c;
              }
              if (uVar13 + 2 < param_2) {
                param_1[uVar13 + 2] = 0x27;
              }
              uVar14 = uVar13 + 3;
              uVar19 = uVar19 + 1;
              bVar3 = 0x27;
              bVar1 = 0x27;
              if (local_7a == false) {
                local_7a = bVar23;
                bVar4 = false;
                goto LAB_0011690a;
              }
              goto LAB_001168cd;
            }
            uVar19 = uVar19 + 1;
            local_90 = param_2;
            if (local_7a != false) {
              uVar14 = uVar13 + 6;
              uVar12 = 0;
              bVar1 = 0x27;
              bVar24 = local_7a;
              goto LAB_00116906;
            }
            uVar14 = uVar13 + 3;
            bVar4 = false;
            uVar12 = 0;
            local_7a = param_2 != 0 && bVar20;
            goto LAB_00116913;
          }
          goto LAB_00116aa0;
        case 0x3f:
switchD_00116860_caseD_3f:
          uVar9 = uVar19;
          bVar24 = false;
          if (local_b4 == 2) {
            if (local_d1 == false) {
              local_b8 = 0;
              uVar19 = uVar19 + 1;
              bVar1 = 0x3f;
              goto LAB_00116a51;
            }
            goto LAB_00116aa0;
          }
LAB_00116c56:
          if ((local_b4 != 5) || ((local_80 & 4) == 0)) {
            uVar15 = 0x3f;
            bVar20 = false;
            goto joined_r0x00116b40;
          }
          uVar19 = uVar9 + 2;
          bVar20 = false;
          uVar15 = 0x3f;
          if ((param_4 <= uVar19) || (param_3[uVar9 + 1] != '?')) goto joined_r0x00116b40;
          bVar3 = param_3[uVar9 + 2];
          if ((0x3e < bVar3) ||
             (bVar20 = (0x7000a38200000000U >> ((ulong)bVar3 & 0x3f) & 1) != 0, !bVar20))
          goto joined_r0x00116b40;
          if (local_d1 == false) {
            if (uVar13 < param_2) {
              param_1[uVar13] = 0x3f;
            }
            if (uVar13 + 1 < param_2) {
              param_1[uVar13 + 1] = 0x22;
            }
            if (uVar13 + 2 < param_2) {
              param_1[uVar13 + 2] = 0x22;
            }
            if (uVar13 + 3 < param_2) {
              param_1[uVar13 + 3] = 0x3f;
            }
            uVar13 = uVar13 + 4;
            if (local_b6 != false) {
              bVar16 = false;
              bVar20 = false;
              bVar17 = false;
              uVar15 = (uint)bVar3;
              if (local_c8 != 0) goto LAB_00116885;
              if (bVar24 == false) {
                bVar16 = false;
                goto LAB_00116a42;
              }
              uVar19 = uVar9 + 3;
              goto LAB_001168b7;
            }
            local_b8 = 0;
            bVar20 = false;
            uVar19 = uVar9 + 3;
            bVar1 = bVar3;
            goto joined_r0x00116d1e;
          }
          goto LAB_00116ab3;
        }
        uVar15 = (uint)uVar9;
        bVar2 = false;
        bVar20 = false;
        bVar16 = false;
        if (local_b6 == false) {
          if (local_d1 != false) {
LAB_00116af4:
            bVar1 = (byte)uVar9;
            bVar20 = bVar2;
            if (local_c8 != 0) {
LAB_00116b00:
              uVar15 = (uint)uVar9;
              bVar1 = (byte)(uVar9 >> 5);
LAB_00116896:
              bVar3 = (byte)uVar15;
              if ((*(uint *)(local_c8 + (ulong)bVar1 * 4) >> (uVar15 & 0x1f) & 1) == 0) {
LAB_00116a37:
                bVar16 = false;
LAB_00116a39:
                bVar3 = (byte)uVar15;
                bVar17 = bVar20;
                if (bVar24 == false) {
LAB_00116a42:
                  bVar1 = (byte)uVar15;
                  local_b8 = local_b8 & bVar17;
                  uVar19 = uVar19 + 1;
                  uVar14 = uVar13;
                  bVar17 = (bool)((bVar16 ^ 1U) & bVar4);
                  goto LAB_00116a51;
                }
              }
              goto LAB_001168a7;
            }
            if (bVar24 == false) {
LAB_00117637:
              local_b8 = local_b8 & bVar2;
              uVar19 = uVar19 + 1;
              goto LAB_00116a51;
            }
            goto LAB_00117549;
          }
LAB_00116b50:
          bVar3 = (byte)uVar15;
          bVar20 = false;
          uVar9 = uVar19;
LAB_00116b52:
          local_b8 = local_b8 & bVar16;
          uVar19 = uVar9 + 1;
          bVar1 = bVar3;
          uVar13 = uVar14;
joined_r0x00116d1e:
          bVar3 = bVar1;
          if (bVar24 != false) {
LAB_00116b64:
            bVar1 = (bVar4 ^ 1U) & local_b7;
            uVar14 = uVar13;
            goto LAB_001168c9;
          }
          uVar14 = uVar13;
          bVar17 = (bool)((bVar20 ^ 1U) & bVar4);
LAB_00116a51:
          uVar13 = uVar14;
          if (bVar17 != false) {
LAB_00116a59:
            if (uVar13 < param_2) {
              param_1[uVar13] = 0x27;
            }
            if (uVar13 + 1 < param_2) {
              param_1[uVar13 + 1] = 0x27;
            }
            uVar14 = uVar13 + 2;
            bVar4 = false;
          }
        }
        else {
LAB_001168a7:
          bVar16 = bVar20;
          if (local_d1 != false) {
LAB_00117549:
            local_b6 = (bool)(local_b6 & local_b7);
            goto LAB_00116aa0;
          }
LAB_001168b2:
          uVar19 = uVar19 + 1;
LAB_001168b7:
          local_b8 = local_b8 & bVar16;
          bVar1 = (bVar4 ^ 1U) & local_b7;
          uVar14 = uVar13;
LAB_001168c9:
          bVar24 = bVar4;
          if (bVar1 != 0) {
LAB_001168cd:
            if (uVar14 < param_2) {
              param_1[uVar14] = 0x27;
            }
            if (uVar14 + 1 < param_2) {
              param_1[uVar14 + 1] = 0x24;
            }
            if (uVar14 + 2 < param_2) {
              param_1[uVar14 + 2] = 0x27;
            }
            uVar14 = uVar14 + 3;
            bVar24 = bVar23;
          }
LAB_001168fc:
          bVar1 = bVar3;
          if (uVar14 < param_2) {
            param_1[uVar14] = 0x5c;
          }
LAB_00116906:
          uVar14 = uVar14 + 1;
          bVar4 = bVar24;
        }
LAB_0011690a:
        if (uVar14 < uVar12) {
LAB_0011690f:
          param_1[uVar14] = bVar1;
        }
LAB_00116913:
        uVar13 = uVar14 + 1;
        bVar23 = param_4 != uVar19;
        param_2 = uVar12;
        if (param_4 != 0xffffffffffffffff) goto LAB_00116810;
LAB_00116928:
        param_4 = 0xffffffffffffffff;
        bVar23 = param_3[uVar19] != '\0';
        if (!bVar23) break;
      } while( true );
    }
LAB_00116946:
    if ((uVar13 == 0) && (local_b7 != false)) {
      if (local_d1 != false) {
LAB_00116a8f:
        local_b4 = 2;
LAB_00116aa0:
        iVar6 = 4;
        if (local_b6 == false) {
          iVar6 = local_b4;
        }
LAB_00116ab3:
        local_b4 = iVar6;
        local_80 = local_80 & 0xfffffffd;
        local_c8 = 0;
        goto LAB_001166d0;
      }
    }
    else {
      local_d1 = (bool)(local_d1 ^ 1);
      if ((local_d1 == false) || (local_b7 == false)) goto LAB_00117875;
    }
    if (local_7a == false) {
      local_d1 = true;
LAB_00117875:
      uVar12 = uVar13;
      if (((local_98 != (char *)0x0) && (local_d1 != false)) && (cVar10 = *local_98, cVar10 != '\0')
         ) {
        do {
          if (uVar12 < param_2) {
            param_1[uVar12] = cVar10;
          }
          uVar12 = uVar12 + 1;
          cVar10 = local_98[uVar12 - uVar13];
        } while (cVar10 != '\0');
      }
      if (uVar12 < param_2) {
        param_1[uVar12] = 0;
      }
      if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
        return uVar12;
      }
                    // WARNING: Subroutine does not return
      __stack_chk_fail();
    }
    if (local_b8 != 0) goto LAB_00117e4f;
    local_d1 = local_7a;
    if (param_2 != 0 || local_90 == 0) goto LAB_00117875;
    local_d1 = false;
    uVar12 = local_90;
    local_7a = param_2 == 0 && local_90 != 0;
  } while( true );
switchD_00116860_caseD_0:
  if (local_b6 != false) goto switchD_001173eb_caseD_0;
  if ((local_80 & 1) == 0) {
    if (local_d1 == false) {
      local_b8 = 0;
      uVar19 = uVar19 + 1;
      bVar1 = 0;
      goto LAB_00116a51;
    }
    if (local_c8 != 0) {
      bVar24 = false;
      bVar20 = false;
      uVar9 = 0;
      goto LAB_00116b00;
    }
    uVar19 = uVar19 + 1;
    local_b8 = 0;
    bVar1 = 0;
    goto LAB_00116a51;
  }
  uVar19 = uVar19 + 1;
  if (param_4 == 0xffffffffffffffff) goto LAB_00116928;
  if (uVar19 == param_4) goto LAB_00116946;
  __s1 = (byte *)(param_3 + uVar19);
  goto LAB_0011682d;
LAB_00117c90:
  param_1[uVar13 + 2] = bVar1;
  uVar13 = uVar13 + 3;
  uVar15 = (uint)(byte)param_3[uVar19];
  uVar19 = uVar19 + 1;
  bVar4 = false;
  goto LAB_00117c1b;
LAB_00117e4f:
  local_b4 = 5;
  param_2 = local_90;
  goto LAB_001166d0;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

undefined * FUN_00117f10(uint param_1,undefined8 param_2,undefined8 param_3,undefined4 *param_4)

{
  ulong *puVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  ulong uVar5;
  int *piVar6;
  undefined8 *puVar7;
  ulong uVar8;
  undefined *puVar9;
  long lVar10;
  long in_FS_OFFSET;
  long local_48;
  long local_40;
  
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  piVar6 = __errno_location();
  iVar2 = *piVar6;
  if (0x7ffffffe < param_1) {
                    // WARNING: Subroutine does not return
    abort();
  }
  puVar7 = (undefined8 *)PTR_DAT_00127260;
  if (DAT_00127258 <= (int)param_1) {
    local_48 = (long)DAT_00127258;
    lVar10 = (long)(int)((param_1 - DAT_00127258) + 1);
    if (PTR_DAT_00127260 == &DAT_00127270) {
      puVar7 = (undefined8 *)FUN_00119f30(0,&local_48,lVar10,0x7fffffff,0x10);
      puVar9 = PTR_DAT_00127278;
      PTR_DAT_00127260 = (undefined *)puVar7;
      *puVar7 = _DAT_00127270;
      puVar7[1] = puVar9;
    }
    else {
      puVar7 = (undefined8 *)FUN_00119f30(PTR_DAT_00127260,&local_48,lVar10,0x7fffffff,0x10);
      PTR_DAT_00127260 = (undefined *)puVar7;
    }
    memset(puVar7 + (long)DAT_00127258 * 2,0,(local_48 - DAT_00127258) * 0x10);
    DAT_00127258 = (int)local_48;
  }
  uVar3 = param_4[1];
  puVar1 = puVar7 + (long)(int)param_1 * 2;
  uVar5 = *puVar1;
  puVar9 = (undefined *)puVar1[1];
  uVar8 = FUN_00116660(puVar9,uVar5,param_2,param_3,*param_4,uVar3 | 1,param_4 + 2,
                       *(undefined8 *)(param_4 + 10),*(undefined8 *)(param_4 + 0xc));
  if (uVar5 <= uVar8) {
    uVar8 = uVar8 + 1;
    *puVar1 = uVar8;
    if (puVar9 != &DAT_00128460) {
      free(puVar9);
    }
    puVar9 = (undefined *)FUN_00119d40(uVar8);
    uVar4 = *param_4;
    puVar1[1] = (ulong)puVar9;
    FUN_00116660(puVar9,uVar8,param_2,param_3,uVar4,uVar3 | 1,param_4 + 2,
                 *(undefined8 *)(param_4 + 10),*(undefined8 *)(param_4 + 0xc));
  }
  *piVar6 = iVar2;
  if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
    return puVar9;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_00118100(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  
  piVar2 = __errno_location();
  iVar1 = *piVar2;
  if (param_1 == (undefined4 *)0x0) {
    param_1 = &DAT_00128560;
  }
  FUN_0011a0c0(param_1,0x38);
  *piVar2 = iVar1;
  return;
}



undefined4 FUN_00118140(undefined4 *param_1)

{
  if (param_1 == (undefined4 *)0x0) {
    param_1 = &DAT_00128560;
  }
  return *param_1;
}



void FUN_00118160(undefined4 *param_1,undefined4 param_2)

{
  if (param_1 == (undefined4 *)0x0) {
    param_1 = &DAT_00128560;
  }
  *param_1 = param_2;
  return;
}



void FUN_00118180(undefined4 *param_1,byte param_2,uint param_3)

{
  uint uVar1;
  
  if (param_1 == (undefined4 *)0x0) {
    param_1 = &DAT_00128560;
  }
  uVar1 = param_1[(ulong)(param_2 >> 5) + 2];
  param_1[(ulong)(param_2 >> 5) + 2] =
       (param_3 & 1 ^ uVar1 >> (param_2 & 0x1f) & 1) << (param_2 & 0x1f) ^ uVar1;
  return;
}



undefined4 FUN_001181c0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  if (param_1 == (undefined4 *)0x0) {
    param_1 = &DAT_00128560;
  }
  uVar1 = param_1[1];
  param_1[1] = param_2;
  return uVar1;
}



void FUN_001181e0(undefined4 *param_1,long param_2,long param_3)

{
  if (param_1 == (undefined4 *)0x0) {
    param_1 = &DAT_00128560;
  }
  *param_1 = 10;
  if ((param_2 != 0) && (param_3 != 0)) {
    *(long *)(param_1 + 10) = param_2;
    *(long *)(param_1 + 0xc) = param_3;
    return;
  }
                    // WARNING: Subroutine does not return
  abort();
}



void FUN_00118220(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined4 *param_5)

{
  int iVar1;
  int *piVar2;
  
  if (param_5 == (undefined4 *)0x0) {
    param_5 = &DAT_00128560;
  }
  piVar2 = __errno_location();
  iVar1 = *piVar2;
  FUN_00116660(param_1,param_2,param_3,param_4,*param_5,param_5[1],param_5 + 2,
               *(undefined8 *)(param_5 + 10),*(undefined8 *)(param_5 + 0xc));
  *piVar2 = iVar1;
  return;
}



undefined8 FUN_001182a0(undefined8 param_1,undefined8 param_2,long *param_3,undefined4 *param_4)

{
  int iVar1;
  int *piVar2;
  long lVar3;
  undefined8 uVar4;
  uint uVar5;
  
  if (param_4 == (undefined4 *)0x0) {
    param_4 = &DAT_00128560;
  }
  piVar2 = __errno_location();
  iVar1 = *piVar2;
  uVar5 = (uint)(param_3 == (long *)0x0) | param_4[1];
  lVar3 = FUN_00116660(0,0,param_1,param_2,*param_4,uVar5,param_4 + 2,*(undefined8 *)(param_4 + 10),
                       *(undefined8 *)(param_4 + 0xc));
  uVar4 = FUN_00119d40(lVar3 + 1);
  FUN_00116660(uVar4,lVar3 + 1,param_1,param_2,*param_4,uVar5,param_4 + 2,
               *(undefined8 *)(param_4 + 10),*(undefined8 *)(param_4 + 0xc));
  *piVar2 = iVar1;
  if (param_3 != (long *)0x0) {
    *param_3 = lVar3;
  }
  return uVar4;
}



void FUN_00118390(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  FUN_001182a0(param_1,param_2,0,param_3);
  return;
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_001183a0(void)

{
  undefined8 *puVar1;
  void *__ptr;
  undefined *__ptr_00;
  undefined8 *puVar2;
  
  __ptr_00 = PTR_DAT_00127260;
  if (1 < DAT_00127258) {
    puVar2 = (undefined8 *)(PTR_DAT_00127260 + 0x18);
    puVar1 = (undefined8 *)(PTR_DAT_00127260 + (ulong)(DAT_00127258 - 2) * 0x10 + 0x28);
    do {
      __ptr = (void *)*puVar2;
      puVar2 = puVar2 + 2;
      free(__ptr);
    } while (puVar2 != puVar1);
  }
  if (*(undefined **)(__ptr_00 + 8) != &DAT_00128460) {
    free(*(undefined **)(__ptr_00 + 8));
    PTR_DAT_00127278 = &DAT_00128460;
    _DAT_00127270 = 0x100;
  }
  if (__ptr_00 != &DAT_00127270) {
    free(__ptr_00);
    PTR_DAT_00127260 = &DAT_00127270;
  }
  DAT_00127258 = 1;
  return;
}



void FUN_00118440(undefined8 param_1,undefined8 param_2)

{
  FUN_00117f10(param_1,param_2,0xffffffffffffffff,&DAT_00128560);
  return;
}



void FUN_00118460(void)

{
  FUN_00117f10();
  return;
}



void FUN_00118470(undefined8 param_1)

{
  FUN_00117f10(0,param_1,0xffffffffffffffff,&DAT_00128560);
  return;
}



void FUN_00118490(undefined8 param_1,undefined8 param_2)

{
  FUN_00117f10(0,param_1,param_2,&DAT_00128560);
  return;
}



void FUN_001184b0(undefined8 param_1,int param_2,undefined8 param_3)

{
  long in_FS_OFFSET;
  int local_48 [2];
  undefined1 local_40 [16];
  undefined1 local_30 [16];
  undefined1 local_20 [16];
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  if (param_2 == 10) {
                    // WARNING: Subroutine does not return
    abort();
  }
  local_40 = (undefined1  [16])0x0;
  local_30 = (undefined1  [16])0x0;
  local_48[1] = 0;
  local_20 = (undefined1  [16])0x0;
  local_48[0] = param_2;
  FUN_00117f10(param_1,param_3,0xffffffffffffffff,local_48);
  if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
    return;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_00118520(undefined8 param_1,int param_2,undefined8 param_3,undefined8 param_4)

{
  long in_FS_OFFSET;
  int local_48 [2];
  undefined1 local_40 [16];
  undefined1 local_30 [16];
  undefined1 local_20 [16];
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  if (param_2 == 10) {
                    // WARNING: Subroutine does not return
    abort();
  }
  local_40 = (undefined1  [16])0x0;
  local_30 = (undefined1  [16])0x0;
  local_48[1] = 0;
  local_20 = (undefined1  [16])0x0;
  local_48[0] = param_2;
  FUN_00117f10(param_1,param_3,param_4,local_48);
  if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
    return;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_00118590(int param_1,undefined8 param_2)

{
  long in_FS_OFFSET;
  int local_48 [2];
  undefined1 local_40 [16];
  undefined1 local_30 [16];
  undefined1 local_20 [16];
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  if (param_1 == 10) {
                    // WARNING: Subroutine does not return
    abort();
  }
  local_40 = (undefined1  [16])0x0;
  local_30 = (undefined1  [16])0x0;
  local_48[1] = 0;
  local_20 = (undefined1  [16])0x0;
  local_48[0] = param_1;
  FUN_00117f10(0,param_2,0xffffffffffffffff,local_48);
  if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
    return;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_00118600(int param_1,undefined8 param_2,undefined8 param_3)

{
  long in_FS_OFFSET;
  int local_48 [2];
  undefined1 local_40 [16];
  undefined1 local_30 [16];
  undefined1 local_20 [16];
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  if (param_1 == 10) {
                    // WARNING: Subroutine does not return
    abort();
  }
  local_40 = (undefined1  [16])0x0;
  local_30 = (undefined1  [16])0x0;
  local_48[1] = 0;
  local_20 = (undefined1  [16])0x0;
  local_48[0] = param_1;
  FUN_00117f10(0,param_2,param_3,local_48);
  if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
    return;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_00118670(undefined8 param_1,undefined8 param_2,uint param_3)

{
  uint *puVar1;
  uint uVar2;
  long in_FS_OFFSET;
  undefined8 local_48;
  undefined8 uStack_40;
  undefined8 local_38;
  undefined8 uStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined8 local_18;
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  local_18 = DAT_00128590;
  local_48 = _DAT_00128560;
  uStack_40 = _DAT_00128568;
  local_38 = _DAT_00128570;
  uStack_30 = uRam0000000000128578;
  puVar1 = (uint *)((long)&uStack_40 + (ulong)(byte)((byte)param_3 >> 5) * 4);
  local_28 = _DAT_00128580;
  uStack_20 = DAT_00128588;
  uVar2 = *puVar1;
  *puVar1 = (uint)((uVar2 >> (param_3 & 0x1f) & 1) == 0) << (sbyte)(param_3 & 0x1f) ^ uVar2;
  FUN_00117f10(0,param_1,param_2,&local_48);
  if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
    return;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_00118710(undefined8 param_1,uint param_2)

{
  uint *puVar1;
  uint uVar2;
  long in_FS_OFFSET;
  undefined8 local_48;
  undefined8 uStack_40;
  undefined8 local_38;
  undefined8 uStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined8 local_18;
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  local_18 = DAT_00128590;
  local_48 = _DAT_00128560;
  uStack_40 = _DAT_00128568;
  local_38 = _DAT_00128570;
  uStack_30 = uRam0000000000128578;
  puVar1 = (uint *)((long)&uStack_40 + (ulong)(byte)((byte)param_2 >> 5) * 4);
  local_28 = _DAT_00128580;
  uStack_20 = DAT_00128588;
  uVar2 = *puVar1;
  *puVar1 = (uint)((uVar2 >> (param_2 & 0x1f) & 1) == 0) << (sbyte)(param_2 & 0x1f) ^ uVar2;
  FUN_00117f10(0,param_1,0xffffffffffffffff,&local_48);
  if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
    return;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_001187b0(undefined8 param_1)

{
  long in_FS_OFFSET;
  undefined8 local_48;
  ulong uStack_40;
  undefined8 local_38;
  undefined8 uStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined8 local_18;
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  local_48 = _DAT_00128560;
  local_18 = DAT_00128590;
  local_38 = _DAT_00128570;
  uStack_30 = uRam0000000000128578;
  uStack_40 = CONCAT44(DAT_0012856c,_DAT_00128568) | 0x400000000000000;
  local_28 = _DAT_00128580;
  uStack_20 = DAT_00128588;
  FUN_00117f10(0,param_1,0xffffffffffffffff,&local_48);
  if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
    return;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_00118840(undefined8 param_1,undefined8 param_2)

{
  long in_FS_OFFSET;
  undefined8 local_48;
  ulong uStack_40;
  undefined8 local_38;
  undefined8 uStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined8 local_18;
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  local_48 = _DAT_00128560;
  local_18 = DAT_00128590;
  local_38 = _DAT_00128570;
  uStack_30 = uRam0000000000128578;
  uStack_40 = CONCAT44(DAT_0012856c,_DAT_00128568) | 0x400000000000000;
  local_28 = _DAT_00128580;
  uStack_20 = DAT_00128588;
  FUN_00117f10(0,param_1,param_2,&local_48);
  if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
    return;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_001188d0(undefined8 param_1,int param_2,undefined8 param_3)

{
  long in_FS_OFFSET;
  int local_48 [6];
  undefined1 local_30 [16];
  undefined1 local_20 [16];
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  if (param_2 == 10) {
                    // WARNING: Subroutine does not return
    abort();
  }
  local_20 = (undefined1  [16])0x0;
  local_48[1] = 0;
  local_48[2] = 0;
  local_48[3] = 0x4000000;
  local_48[4] = 0;
  local_48[5] = 0;
  local_30 = (undefined1  [16])0x0;
  local_48[0] = param_2;
  FUN_00117f10(param_1,param_3,0xffffffffffffffff,local_48);
  if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
    return;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_00118950(undefined8 param_1,long param_2,long param_3,undefined8 param_4)

{
  long in_FS_OFFSET;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined8 local_38;
  undefined8 uStack_30;
  undefined8 local_28;
  long lStack_20;
  long local_18;
  long local_10;
  
  uStack_40 = _DAT_00128568;
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  local_18 = DAT_00128590;
  local_38 = _DAT_00128570;
  uStack_30 = uRam0000000000128578;
  local_28 = _DAT_00128580;
  lStack_20 = DAT_00128588;
  _local_48 = CONCAT44((int)((ulong)_DAT_00128560 >> 0x20),10);
  if ((param_2 != 0) && (param_3 != 0)) {
    lStack_20 = param_2;
    local_18 = param_3;
    FUN_00117f10(param_1,param_4,0xffffffffffffffff,&local_48);
    if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
      return;
    }
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_001189f0(undefined4 param_1,long param_2,long param_3,undefined8 param_4,undefined8 param_5
                 )

{
  long in_FS_OFFSET;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined8 local_38;
  undefined8 uStack_30;
  undefined8 local_28;
  long lStack_20;
  long local_18;
  long local_10;
  
  uStack_40 = _DAT_00128568;
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  local_18 = DAT_00128590;
  local_38 = _DAT_00128570;
  uStack_30 = uRam0000000000128578;
  local_28 = _DAT_00128580;
  lStack_20 = DAT_00128588;
  _local_48 = CONCAT44((int)((ulong)_DAT_00128560 >> 0x20),10);
  if ((param_2 != 0) && (param_3 != 0)) {
    lStack_20 = param_2;
    local_18 = param_3;
    FUN_00117f10(param_1,param_4,param_5,&local_48);
    if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
      return;
    }
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_00118a90(long param_1,long param_2,undefined8 param_3)

{
  long in_FS_OFFSET;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined8 local_38;
  undefined8 uStack_30;
  undefined8 local_28;
  long lStack_20;
  long local_18;
  long local_10;
  
  uStack_40 = _DAT_00128568;
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  local_18 = DAT_00128590;
  local_38 = _DAT_00128570;
  uStack_30 = uRam0000000000128578;
  local_28 = _DAT_00128580;
  lStack_20 = DAT_00128588;
  _local_48 = CONCAT44((int)((ulong)_DAT_00128560 >> 0x20),10);
  if ((param_1 != 0) && (param_2 != 0)) {
    lStack_20 = param_1;
    local_18 = param_2;
    FUN_00117f10(0,param_3,0xffffffffffffffff,&local_48);
    if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
      return;
    }
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
                    // WARNING: Subroutine does not return
  abort();
}



// WARNING: Globals starting with '_' overlap smaller symbols at the same address

void FUN_00118b30(long param_1,long param_2,undefined8 param_3,undefined8 param_4)

{
  long in_FS_OFFSET;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined8 local_38;
  undefined8 uStack_30;
  undefined8 local_28;
  long lStack_20;
  long local_18;
  long local_10;
  
  uStack_40 = _DAT_00128568;
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  local_18 = DAT_00128590;
  local_38 = _DAT_00128570;
  uStack_30 = uRam0000000000128578;
  local_28 = _DAT_00128580;
  lStack_20 = DAT_00128588;
  _local_48 = CONCAT44((int)((ulong)_DAT_00128560 >> 0x20),10);
  if ((param_1 != 0) && (param_2 != 0)) {
    lStack_20 = param_1;
    local_18 = param_2;
    FUN_00117f10(0,param_3,param_4,&local_48);
    if (local_10 == *(long *)(in_FS_OFFSET + 0x28)) {
      return;
    }
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
                    // WARNING: Subroutine does not return
  abort();
}



void FUN_00118bd0(void)

{
  FUN_00117f10();
  return;
}



void FUN_00118be0(undefined8 param_1,undefined8 param_2)

{
  FUN_00117f10(0,param_1,param_2,&DAT_00127220);
  return;
}



void FUN_00118c00(undefined8 param_1,undefined8 param_2)

{
  FUN_00117f10(param_1,param_2,0xffffffffffffffff,&DAT_00127220);
  return;
}



void FUN_00118c20(undefined8 param_1)

{
  FUN_00117f10(0,param_1,0xffffffffffffffff,&DAT_00127220);
  return;
}



int FUN_00118c40(undefined8 param_1,undefined8 *param_2)

{
  char *__s1;
  int iVar1;
  int *piVar2;
  
  iVar1 = getfilecon();
  if (iVar1 == 0) {
    piVar2 = __errno_location();
    *piVar2 = 0x5f;
  }
  else {
    if (iVar1 != 10) {
      return iVar1;
    }
    __s1 = (char *)*param_2;
    iVar1 = strcmp(__s1,"unlabeled");
    if (iVar1 != 0) {
      return 10;
    }
    freecon(__s1);
    *param_2 = 0;
    piVar2 = __errno_location();
    *piVar2 = 0x3d;
  }
  return -1;
}



int FUN_00118cc0(undefined8 param_1,undefined8 *param_2)

{
  char *__s1;
  int iVar1;
  int *piVar2;
  
  iVar1 = getfilecon_raw();
  if (iVar1 == 0) {
    piVar2 = __errno_location();
    *piVar2 = 0x5f;
  }
  else {
    if (iVar1 != 10) {
      return iVar1;
    }
    __s1 = (char *)*param_2;
    iVar1 = strcmp(__s1,"unlabeled");
    if (iVar1 != 0) {
      return 10;
    }
    freecon(__s1);
    *param_2 = 0;
    piVar2 = __errno_location();
    *piVar2 = 0x3d;
  }
  return -1;
}



int FUN_00118d40(undefined8 param_1,undefined8 *param_2)

{
  char *__s1;
  int iVar1;
  int *piVar2;
  
  iVar1 = lgetfilecon();
  if (iVar1 == 0) {
    piVar2 = __errno_location();
    *piVar2 = 0x5f;
  }
  else {
    if (iVar1 != 10) {
      return iVar1;
    }
    __s1 = (char *)*param_2;
    iVar1 = strcmp(__s1,"unlabeled");
    if (iVar1 != 0) {
      return 10;
    }
    freecon(__s1);
    *param_2 = 0;
    piVar2 = __errno_location();
    *piVar2 = 0x3d;
  }
  return -1;
}



int FUN_00118dc0(undefined8 param_1,undefined8 *param_2)

{
  char *__s1;
  int iVar1;
  int *piVar2;
  
  iVar1 = lgetfilecon_raw();
  if (iVar1 == 0) {
    piVar2 = __errno_location();
    *piVar2 = 0x5f;
  }
  else {
    if (iVar1 != 10) {
      return iVar1;
    }
    __s1 = (char *)*param_2;
    iVar1 = strcmp(__s1,"unlabeled");
    if (iVar1 != 0) {
      return 10;
    }
    freecon(__s1);
    *param_2 = 0;
    piVar2 = __errno_location();
    *piVar2 = 0x3d;
  }
  return -1;
}



int FUN_00118e40(undefined8 param_1,undefined8 *param_2)

{
  char *__s1;
  int iVar1;
  int *piVar2;
  
  iVar1 = fgetfilecon();
  if (iVar1 == 0) {
    piVar2 = __errno_location();
    *piVar2 = 0x5f;
  }
  else {
    if (iVar1 != 10) {
      return iVar1;
    }
    __s1 = (char *)*param_2;
    iVar1 = strcmp(__s1,"unlabeled");
    if (iVar1 != 0) {
      return 10;
    }
    freecon(__s1);
    *param_2 = 0;
    piVar2 = __errno_location();
    *piVar2 = 0x3d;
  }
  return -1;
}



int FUN_00118ec0(undefined8 param_1,undefined8 *param_2)

{
  char *__s1;
  int iVar1;
  int *piVar2;
  
  iVar1 = fgetfilecon_raw();
  if (iVar1 == 0) {
    piVar2 = __errno_location();
    *piVar2 = 0x5f;
  }
  else {
    if (iVar1 != 10) {
      return iVar1;
    }
    __s1 = (char *)*param_2;
    iVar1 = strcmp(__s1,"unlabeled");
    if (iVar1 != 0) {
      return 10;
    }
    freecon(__s1);
    *param_2 = 0;
    piVar2 = __errno_location();
    *piVar2 = 0x3d;
  }
  return -1;
}



void thunk_FUN_00118f70(void)

{
  FUN_00118f70();
  return;
}



void thunk_FUN_00118f60(void)

{
  FUN_00118f60();
  return;
}



void FUN_00118f60(int param_1)

{
  setlocale(param_1,(char *)0x0);
  return;
}



undefined8 FUN_00118f70(int param_1,undefined1 *param_2,ulong param_3)

{
  char *__s;
  size_t sVar1;
  undefined8 uVar2;
  
  __s = setlocale(param_1,(char *)0x0);
  if (__s == (char *)0x0) {
    if (param_3 != 0) {
      *param_2 = 0;
    }
    uVar2 = 0x16;
  }
  else {
    sVar1 = strlen(__s);
    if (sVar1 < param_3) {
      memcpy(param_2,__s,sVar1 + 1);
      return 0;
    }
    if (param_3 != 0) {
      memcpy(param_2,__s,param_3 - 1);
      param_2[param_3 - 1] = 0;
    }
    uVar2 = 0x22;
  }
  return uVar2;
}



undefined8 FUN_00119000(long *param_1)

{
  long *plVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined8 uVar5;
  
  piVar3 = __errno_location();
  iVar4 = *piVar3;
  if ((char)param_1[1] == '\0') {
    iVar2 = unsetenv("TZ");
  }
  else {
    iVar2 = setenv("TZ",(char *)((long)param_1 + 9),1);
  }
  if (iVar2 == 0) {
    tzset();
    uVar5 = 1;
  }
  else {
    iVar4 = *piVar3;
    uVar5 = 0;
  }
  do {
    plVar1 = (long *)*param_1;
    free(param_1);
    param_1 = plVar1;
  } while (plVar1 != (long *)0x0);
  *piVar3 = iVar4;
  return uVar5;
}



undefined8 * FUN_00119090(char *param_1)

{
  ulong __n;
  size_t sVar1;
  ulong uVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  
  if (param_1 == (char *)0x0) {
    puVar4 = malloc(0x80);
    puVar3 = (undefined8 *)0x0;
    if (puVar4 != (undefined8 *)0x0) {
      *puVar4 = 0;
      *(undefined2 *)(puVar4 + 1) = 0;
      return puVar4;
    }
  }
  else {
    sVar1 = strlen(param_1);
    __n = sVar1 + 1;
    uVar2 = 0x76;
    if (0x75 < __n) {
      uVar2 = __n;
    }
    puVar3 = malloc(uVar2 + 0x11 & 0xfffffffffffffff8);
    if (puVar3 != (undefined8 *)0x0) {
      *puVar3 = 0;
      *(undefined2 *)(puVar3 + 1) = 1;
      memcpy((void *)((long)puVar3 + 9),param_1,__n);
      *(undefined1 *)((long)puVar3 + sVar1 + 10) = 0;
    }
  }
  return puVar3;
}



undefined8 FUN_00119130(long *param_1,char *param_2)

{
  char *__s2;
  long *plVar1;
  int iVar2;
  size_t sVar3;
  long lVar4;
  char *__s1;
  
  __s2 = *(char **)(param_2 + 0x30);
  if ((__s2 != (char *)0x0) && ((__s2 < param_2 || (param_2 + 0x38 <= __s2)))) {
    __s1 = (char *)((long)param_1 + 9);
    if (*__s2 == '\0') {
      __s1 = "";
    }
    else {
      while (iVar2 = strcmp(__s1,__s2), iVar2 != 0) {
        while( true ) {
          if ((*__s1 == '\0') &&
             ((__s1 != (char *)((long)param_1 + 9) || ((char)param_1[1] == '\0')))) {
            sVar3 = strlen(__s2);
            if ((long)(sVar3 + 1) < (long)param_1 + (0x80 - (long)__s1)) {
              memcpy(__s1,__s2,sVar3 + 1);
              __s1[sVar3 + 1] = '\0';
            }
            else {
              lVar4 = FUN_00119090(__s2);
              *param_1 = lVar4;
              if (lVar4 == 0) {
                return 0;
              }
              *(undefined1 *)(lVar4 + 8) = 0;
              __s1 = (char *)(lVar4 + 9);
            }
            goto LAB_001191d0;
          }
          sVar3 = strlen(__s1);
          __s1 = __s1 + sVar3 + 1;
          if ((*__s1 != '\0') || (plVar1 = (long *)*param_1, plVar1 == (long *)0x0)) break;
          __s1 = (char *)((long)plVar1 + 9);
          iVar2 = strcmp(__s1,__s2);
          param_1 = plVar1;
          if (iVar2 == 0) goto LAB_001191d0;
        }
      }
    }
LAB_001191d0:
    *(char **)(param_2 + 0x30) = __s1;
  }
  return 1;
}



void FUN_00119250(undefined8 *param_1)

{
  undefined8 *puVar1;
  
  if (param_1 == (undefined8 *)0x1) {
    return;
  }
  while (param_1 != (undefined8 *)0x0) {
    puVar1 = (undefined8 *)*param_1;
    free(param_1);
    param_1 = puVar1;
  }
  return;
}



long * FUN_00119290(long param_1)

{
  long *plVar1;
  int iVar2;
  char *__s2;
  long *__ptr;
  int *piVar3;
  
  __s2 = getenv("TZ");
  if (__s2 == (char *)0x0) {
    if (*(char *)(param_1 + 8) == '\0') {
      return (long *)0x1;
    }
  }
  else {
    if (*(char *)(param_1 + 8) == '\0') {
      __ptr = (long *)FUN_00119090(__s2);
      if (__ptr == (long *)0x0) {
        return (long *)0x0;
      }
      iVar2 = unsetenv("TZ");
      goto joined_r0x00119338;
    }
    iVar2 = strcmp((char *)(param_1 + 9),__s2);
    if (iVar2 == 0) {
      return (long *)0x1;
    }
  }
  __ptr = (long *)FUN_00119090(__s2);
  if (__ptr == (long *)0x0) {
    return (long *)0x0;
  }
  iVar2 = setenv("TZ",(char *)(param_1 + 9),1);
joined_r0x00119338:
  if (iVar2 != 0) {
    piVar3 = __errno_location();
    iVar2 = *piVar3;
    if (__ptr != (long *)0x1) {
      do {
        plVar1 = (long *)*__ptr;
        free(__ptr);
        __ptr = plVar1;
      } while (plVar1 != (long *)0x0);
    }
    *piVar3 = iVar2;
    return (long *)0x0;
  }
  tzset();
  return __ptr;
}



undefined8 FUN_00119390(long param_1)

{
  undefined8 uVar1;
  
  if (param_1 != 1) {
    uVar1 = FUN_00119000();
    return uVar1;
  }
  return 1;
}



tm * FUN_001193b0(long param_1,time_t *param_2,tm *param_3)

{
  char cVar1;
  long lVar2;
  tm *ptVar3;
  
  if (param_1 == 0) {
    ptVar3 = gmtime_r(param_2,param_3);
    return ptVar3;
  }
  lVar2 = FUN_00119290();
  if (lVar2 != 0) {
    ptVar3 = localtime_r(param_2,param_3);
    if ((ptVar3 != (tm *)0x0) && (cVar1 = FUN_00119130(param_1,param_3), cVar1 != '\0')) {
      if ((lVar2 != 1) && (cVar1 = FUN_00119000(lVar2), cVar1 == '\0')) {
        return (tm *)0x0;
      }
      return param_3;
    }
    if (lVar2 != 1) {
      FUN_00119000(lVar2);
    }
  }
  return (tm *)0x0;
}



time_t FUN_00119460(long param_1,tm *param_2)

{
  char cVar1;
  long lVar2;
  time_t tVar3;
  long in_FS_OFFSET;
  tm local_68;
  long local_30;
  
  local_30 = *(long *)(in_FS_OFFSET + 0x28);
  if (param_1 == 0) {
    if (local_30 == *(long *)(in_FS_OFFSET + 0x28)) {
      tVar3 = timegm(param_2);
      return tVar3;
    }
    goto LAB_00119584;
  }
  lVar2 = FUN_00119290();
  if (lVar2 == 0) {
LAB_001194db:
    tVar3 = -1;
  }
  else {
    local_68.tm_mon = param_2->tm_mon;
    local_68.tm_year = param_2->tm_year;
    local_68.tm_sec = param_2->tm_sec;
    local_68.tm_min = param_2->tm_min;
    local_68.tm_hour = param_2->tm_hour;
    local_68.tm_mday = param_2->tm_mday;
    local_68.tm_yday = -1;
    local_68.tm_isdst = param_2->tm_isdst;
    tVar3 = mktime(&local_68);
    if (local_68.tm_yday < 0) {
LAB_001194cd:
      if (lVar2 != 1) {
        FUN_00119000(lVar2);
      }
      goto LAB_001194db;
    }
    cVar1 = FUN_00119130(param_1,&local_68);
    if (cVar1 == '\0') goto LAB_001194cd;
    if (lVar2 != 1) {
      cVar1 = FUN_00119000(lVar2);
      if (cVar1 == '\0') goto LAB_001194db;
    }
    param_2->tm_sec = local_68.tm_sec;
    param_2->tm_min = local_68.tm_min;
    param_2->tm_hour = local_68.tm_hour;
    param_2->tm_mday = local_68.tm_mday;
    param_2->tm_zone = local_68.tm_zone;
    param_2->tm_mon = local_68.tm_mon;
    param_2->tm_year = local_68.tm_year;
    param_2->tm_wday = local_68.tm_wday;
    param_2->tm_yday = local_68.tm_yday;
    *(ulong *)&param_2->tm_isdst = CONCAT44(local_68._36_4_,local_68.tm_isdst);
    param_2->tm_gmtoff = local_68.tm_gmtoff;
  }
  if (local_30 == *(long *)(in_FS_OFFSET + 0x28)) {
    return tVar3;
  }
LAB_00119584:
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



long FUN_001195a0(FILE *param_1,long param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 *param_5,ulong param_6)

{
  undefined8 uVar1;
  long lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  char *pcVar9;
  undefined8 local_60;
  undefined8 local_58;
  undefined8 local_50;
  undefined8 local_48;
  
  if (param_2 == 0) {
    __fprintf_chk(param_1,1,"%s %s\n",param_3,param_4);
  }
  else {
    __fprintf_chk(param_1,1,"%s (%s) %s\n",param_2,param_3,param_4);
  }
  uVar1 = dcgettext("gnulib","Packaged by %s (%s)\n",5);
  __fprintf_chk(param_1,1,uVar1,"Debian","9.7-3");
  uVar1 = dcgettext("gnulib",&DAT_0011d6fc,5);
  __fprintf_chk(param_1,1,"Copyright %s %d Free Software Foundation, Inc.",uVar1,0x7e9);
  fputc_unlocked(10,param_1);
  uVar1 = dcgettext("gnulib",
                    "License GPLv3+: GNU GPL version 3 or later <%s>.\nThis is free software: you are free to change and redistribute it.\nThere is NO WARRANTY, to the extent permitted by law.\n"
                    ,5);
  __fprintf_chk(param_1,1,uVar1,"https://gnu.org/licenses/gpl.html");
  fputc_unlocked(10,param_1);
  if (9 < param_6) {
    local_48 = param_5[7];
    pcVar9 = "Written by %s, %s, %s,\n%s, %s, %s, %s,\n%s, %s, and others.\n";
    local_50 = param_5[6];
    local_60 = param_5[2];
    local_58 = param_5[1];
    uVar1 = param_5[5];
    uVar4 = param_5[4];
    uVar5 = param_5[3];
    uVar6 = *param_5;
LAB_001197b9:
    uVar3 = dcgettext("gnulib",pcVar9,5);
LAB_001196ff:
    lVar2 = __fprintf_chk(param_1,1,uVar3,uVar6,local_58,local_60,uVar5,uVar4,uVar1,local_50,
                          local_48);
switchD_001196ad_caseD_0:
    return lVar2;
  }
  lVar2 = (long)&switchD_001196ad::switchdataD_00120248 +
          (long)(int)(&switchD_001196ad::switchdataD_00120248)[param_6];
  switch(param_6) {
  case 0:
    goto switchD_001196ad_caseD_0;
  case 1:
    uVar1 = *param_5;
    uVar4 = dcgettext("gnulib","Written by %s.\n",5);
    lVar2 = __fprintf_chk(param_1,1,uVar4,uVar1);
    return lVar2;
  case 2:
    uVar1 = param_5[1];
    uVar4 = *param_5;
    uVar5 = dcgettext("gnulib","Written by %s and %s.\n",5);
    lVar2 = __fprintf_chk(param_1,1,uVar5,uVar4,uVar1);
    return lVar2;
  case 3:
    uVar1 = param_5[2];
    uVar4 = param_5[1];
    uVar5 = *param_5;
    uVar6 = dcgettext("gnulib","Written by %s, %s, and %s.\n",5);
    lVar2 = __fprintf_chk(param_1,1,uVar6,uVar5,uVar4,uVar1);
    return lVar2;
  case 4:
    lVar2 = param_5[3];
    uVar4 = param_5[2];
    uVar1 = param_5[1];
    uVar5 = *param_5;
    uVar6 = dcgettext("gnulib","Written by %s, %s, %s,\nand %s.\n",5);
    break;
  case 5:
    uVar1 = param_5[1];
    lVar2 = param_5[3];
    uVar4 = param_5[2];
    uVar5 = *param_5;
    uVar6 = dcgettext("gnulib","Written by %s, %s, %s,\n%s, and %s.\n",5);
    break;
  case 6:
    uVar4 = param_5[2];
    uVar1 = param_5[1];
    uVar5 = param_5[5];
    uVar6 = param_5[4];
    uVar3 = param_5[3];
    uVar8 = *param_5;
    uVar7 = dcgettext("gnulib","Written by %s, %s, %s,\n%s, %s, and %s.\n",5);
    goto LAB_0011998d;
  case 7:
    uVar1 = param_5[1];
    uVar4 = param_5[2];
    uVar5 = param_5[5];
    uVar6 = param_5[4];
    uVar3 = param_5[3];
    uVar8 = *param_5;
    uVar7 = dcgettext("gnulib","Written by %s, %s, %s,\n%s, %s, %s, and %s.\n",5);
LAB_0011998d:
    lVar2 = __fprintf_chk(param_1,1,uVar7,uVar8,uVar1,uVar4,uVar3,uVar6,uVar5);
    return lVar2;
  case 8:
    local_48 = param_5[7];
    local_50 = param_5[6];
    local_60 = param_5[2];
    local_58 = param_5[1];
    uVar1 = param_5[5];
    uVar4 = param_5[4];
    uVar5 = param_5[3];
    uVar6 = *param_5;
    uVar3 = dcgettext("gnulib","Written by %s, %s, %s,\n%s, %s, %s, %s,\nand %s.\n",5);
    goto LAB_001196ff;
  case 9:
    local_48 = param_5[7];
    pcVar9 = "Written by %s, %s, %s,\n%s, %s, %s, %s,\n%s, and %s.\n";
    local_50 = param_5[6];
    local_60 = param_5[2];
    local_58 = param_5[1];
    uVar1 = param_5[5];
    uVar4 = param_5[4];
    uVar5 = param_5[3];
    uVar6 = *param_5;
    goto LAB_001197b9;
  }
  __fprintf_chk(param_1,1,uVar6,uVar5,uVar1,uVar4);
  return lVar2;
}



void FUN_00119a70(void)

{
  long lVar1;
  long *in_R8;
  long lVar2;
  
  lVar2 = 0;
  lVar1 = *in_R8;
  while (lVar1 != 0) {
    lVar2 = lVar2 + 1;
    lVar1 = in_R8[lVar2];
  }
  FUN_001195a0();
  return;
}



void FUN_00119a90(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 uint *param_5)

{
  uint uVar1;
  long *plVar2;
  long lVar3;
  long lVar4;
  long in_FS_OFFSET;
  long local_68 [11];
  long local_10;
  
  lVar4 = 0;
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  do {
    uVar1 = *param_5;
    if (uVar1 < 0x30) {
      *param_5 = uVar1 + 8;
      lVar3 = *(long *)((ulong)uVar1 + *(long *)(param_5 + 4));
      local_68[lVar4] = lVar3;
    }
    else {
      plVar2 = *(long **)(param_5 + 2);
      *(long **)(param_5 + 2) = plVar2 + 1;
      lVar3 = *plVar2;
      local_68[lVar4] = lVar3;
    }
  } while ((lVar3 != 0) && (lVar4 = lVar4 + 1, lVar4 != 10));
  FUN_001195a0(param_1,param_2,param_3,param_4);
  if (local_10 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return;
}



void FUN_00119b30(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6)

{
  long *plVar1;
  long lVar2;
  uint uVar3;
  ulong uVar4;
  long lVar5;
  long in_FS_OFFSET;
  long local_98 [11];
  long local_40;
  long local_38 [4];
  undefined8 local_18;
  undefined8 local_10;
  
  local_18 = param_5;
  local_10 = param_6;
  plVar1 = local_98;
  lVar5 = 0;
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  uVar3 = 0x20;
  do {
    if (0x2f < uVar3) goto LAB_00119c00;
    uVar4 = (ulong)uVar3;
    uVar3 = uVar3 + 8;
    lVar2 = *(long *)((long)local_38 + uVar4);
    plVar1[lVar5] = lVar2;
    if (lVar2 == 0) goto LAB_00119bc3;
    lVar5 = lVar5 + 1;
  } while (lVar5 != 10);
  goto LAB_00119bbd;
  while (lVar5 = lVar5 + 1, lVar5 != 10) {
LAB_00119c00:
    register0x00000020 = (BADSPACEBASE *)((long)register0x00000020 + 8);
    lVar2 = *(long *)register0x00000020;
    plVar1[lVar5] = lVar2;
    if (lVar2 == 0) goto LAB_00119bc3;
  }
LAB_00119bbd:
  lVar5 = 10;
LAB_00119bc3:
  FUN_001195a0(param_1,param_2,param_3,param_4,plVar1,lVar5);
  if (local_40 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return;
}



void FUN_00119c30(void)

{
  undefined8 uVar1;
  
  fputc_unlocked(10,stdout);
  uVar1 = dcgettext("gnulib","Report bugs to: %s\n",5);
  __printf_chk(1,uVar1,"bug-coreutils@gnu.org");
  uVar1 = dcgettext("gnulib","%s home page: <%s>\n",5);
  __printf_chk(1,uVar1,"GNU coreutils","https://www.gnu.org/software/coreutils/");
  uVar1 = dcgettext("gnulib","General help using GNU software: <%s>\n",5);
  __printf_chk(1,uVar1,"https://www.gnu.org/gethelp/");
  return;
}



void FUN_00119ce0(void)

{
  long lVar1;
  
  lVar1 = FUN_0011acb0();
  if (lVar1 != 0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_00119d00(size_t param_1)

{
  void *pvVar1;
  
  pvVar1 = malloc(param_1);
  if (pvVar1 != (void *)0x0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_00119d20(size_t param_1)

{
  void *pvVar1;
  
  pvVar1 = malloc(param_1);
  if (pvVar1 != (void *)0x0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_00119d40(size_t param_1)

{
  void *pvVar1;
  
  pvVar1 = malloc(param_1);
  if (pvVar1 != (void *)0x0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_00119d60(void *param_1,size_t param_2)

{
  void *pvVar1;
  
  if (param_2 == 0) {
    param_2 = 1;
  }
  pvVar1 = realloc(param_1,param_2);
  if (pvVar1 != (void *)0x0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_00119d90(void *param_1,size_t param_2)

{
  void *pvVar1;
  
  if (param_2 == 0) {
    param_2 = 1;
  }
  pvVar1 = realloc(param_1,param_2);
  if (pvVar1 != (void *)0x0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_00119dc0(void)

{
  long lVar1;
  
  lVar1 = FUN_0011acb0();
  if (lVar1 != 0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_00119de0(void)

{
  long lVar1;
  
  lVar1 = FUN_0011acb0();
  if (lVar1 != 0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_00119e00(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  
  lVar1 = FUN_0011acb0(0,param_1,param_2);
  if (lVar1 != 0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_00119e30(undefined8 param_1,undefined8 param_2)

{
  long lVar1;
  
  lVar1 = FUN_0011acb0(0,param_1,param_2);
  if (lVar1 != 0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_00119e60(long param_1,ulong *param_2)

{
  ulong uVar1;
  long lVar2;
  ulong uVar3;
  bool bVar4;
  
  uVar3 = *param_2;
  if (param_1 == 0) {
    if (uVar3 == 0) {
      uVar3 = 0x80;
    }
  }
  else {
    uVar1 = (uVar3 >> 1) + 1;
    bVar4 = CARRY8(uVar3,uVar1);
    uVar3 = uVar3 + uVar1;
    if (bVar4) goto LAB_00119eb6;
  }
  lVar2 = FUN_0011acb0(param_1,uVar3,1);
  if (lVar2 != 0) {
    *param_2 = uVar3;
    return;
  }
LAB_00119eb6:
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_00119ec0(long param_1,ulong *param_2,ulong param_3)

{
  undefined1 auVar1 [16];
  ulong uVar2;
  long lVar3;
  ulong uVar4;
  bool bVar5;
  
  uVar4 = *param_2;
  if (param_1 == 0) {
    if (uVar4 == 0) {
      auVar1._8_8_ = 0;
      auVar1._0_8_ = param_3;
      uVar4 = SUB168((ZEXT816(0) << 0x40 | ZEXT816(0x80)) / auVar1,0) + (ulong)(0x80 < param_3);
    }
  }
  else {
    uVar2 = (uVar4 >> 1) + 1;
    bVar5 = CARRY8(uVar4,uVar2);
    uVar4 = uVar4 + uVar2;
    if (bVar5) goto LAB_00119f29;
  }
  lVar3 = FUN_0011acb0(param_1,uVar4,param_3);
  if (lVar3 != 0) {
    *param_2 = uVar4;
    return;
  }
LAB_00119f29:
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_00119f30(void *param_1,long *param_2,long param_3,long param_4,long param_5)

{
  long lVar1;
  size_t sVar2;
  void *pvVar3;
  long lVar4;
  size_t __size;
  long lVar5;
  
  lVar1 = *param_2;
  lVar4 = (lVar1 >> 1) + lVar1;
  if (SCARRY8(lVar1 >> 1,lVar1)) {
    lVar4 = 0x7fffffffffffffff;
  }
  lVar5 = param_4;
  if (lVar4 <= param_4) {
    lVar5 = lVar4;
  }
  if (-1 < param_4) {
    lVar4 = lVar5;
  }
  sVar2 = lVar4 * param_5;
  if (SEXT816((long)sVar2) == SEXT816(lVar4) * SEXT816(param_5)) {
    if (0x7f < (long)sVar2) goto joined_r0x00119fe9;
    lVar5 = 0x80;
  }
  else {
    lVar5 = 0x7fffffffffffffff;
  }
  lVar4 = lVar5 / param_5;
  sVar2 = lVar5 - lVar5 % param_5;
joined_r0x00119fe9:
  if (param_1 == (void *)0x0) {
    *param_2 = 0;
  }
  if ((param_3 <= lVar4 - lVar1) ||
     ((lVar4 = lVar1 + param_3, !SCARRY8(lVar1,param_3) &&
      (((param_4 < 0 || (lVar4 <= param_4)) &&
       (sVar2 = lVar4 * param_5, SEXT816((long)sVar2) == SEXT816(lVar4) * SEXT816(param_5))))))) {
    __size = 1;
    if (sVar2 != 0) {
      __size = sVar2;
    }
    pvVar3 = realloc(param_1,__size);
    if (pvVar3 != (void *)0x0) {
      *param_2 = lVar4;
      return;
    }
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_0011a020(size_t param_1)

{
  void *pvVar1;
  
  pvVar1 = calloc(param_1,1);
  if (pvVar1 != (void *)0x0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_0011a050(size_t param_1)

{
  void *pvVar1;
  
  pvVar1 = calloc(param_1,1);
  if (pvVar1 != (void *)0x0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_0011a080(size_t param_1,size_t param_2)

{
  void *pvVar1;
  
  pvVar1 = calloc(param_1,param_2);
  if (pvVar1 != (void *)0x0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_0011a0a0(size_t param_1,size_t param_2)

{
  void *pvVar1;
  
  pvVar1 = calloc(param_1,param_2);
  if (pvVar1 != (void *)0x0) {
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_0011a0c0(void *param_1,size_t param_2)

{
  void *__dest;
  
  __dest = malloc(param_2);
  if (__dest != (void *)0x0) {
    memcpy(__dest,param_1,param_2);
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_0011a100(void *param_1,size_t param_2)

{
  void *__dest;
  
  __dest = malloc(param_2);
  if (__dest != (void *)0x0) {
    memcpy(__dest,param_1,param_2);
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_0011a140(void *param_1,size_t param_2)

{
  void *__dest;
  
  __dest = malloc(param_2 + 1);
  if (__dest != (void *)0x0) {
    *(undefined1 *)((long)__dest + param_2) = 0;
    memcpy(__dest,param_1,param_2);
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_0011a180(char *param_1)

{
  size_t sVar1;
  void *__dest;
  
  sVar1 = strlen(param_1);
  __dest = malloc(sVar1 + 1);
  if (__dest != (void *)0x0) {
    memcpy(__dest,param_1,sVar1 + 1);
    return;
  }
                    // WARNING: Subroutine does not return
  FUN_0011a1c0();
}



void FUN_0011a1c0(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uVar1 = DAT_001271f8;
  uVar2 = dcgettext("gnulib","memory exhausted",5);
  error(uVar1,0,&DAT_0011d505,uVar2);
                    // WARNING: Subroutine does not return
  abort();
}



ulong FUN_0011a200(undefined8 param_1,undefined4 param_2,ulong param_3,ulong param_4,
                  undefined8 param_5,undefined8 param_6,int param_7,uint param_8)

{
  uint uVar1;
  undefined8 uVar2;
  int *piVar3;
  ulong extraout_RDX;
  int iVar4;
  int iVar5;
  long in_FS_OFFSET;
  ulong local_48;
  long local_40;
  
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  uVar1 = FUN_0011a540(param_1,0,param_2,&local_48);
  if (uVar1 != 4) {
    if (param_3 <= local_48) goto LAB_0011a2a0;
    iVar4 = (-(uint)((param_8 & 4) == 0) & 0x29) + 0x22;
    local_48 = param_3;
    if (uVar1 < 2) goto LAB_0011a309;
  }
  do {
    iVar5 = 0;
LAB_0011a26f:
    while( true ) {
      if (param_7 == 0) {
        param_7 = 1;
      }
      uVar2 = FUN_00118c20(param_1);
      uVar1 = error(param_7,iVar5,"%s: %s",param_6,uVar2);
      local_48 = extraout_RDX;
LAB_0011a2a0:
      if (param_4 < local_48) break;
      if (uVar1 == 1) {
        iVar4 = 0x4b;
        goto LAB_0011a309;
      }
      iVar4 = 0;
      iVar5 = 0;
      if (uVar1 == 0) {
LAB_0011a2b1:
        piVar3 = __errno_location();
        *piVar3 = iVar4;
        if (local_40 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
          __stack_chk_fail();
        }
        return local_48;
      }
    }
    iVar4 = (-(uint)((param_8 & 8) == 0) & 0x29) + 0x22;
    local_48 = param_4;
  } while (1 < uVar1);
LAB_0011a309:
  iVar5 = iVar4;
  if ((param_8 & 2) != 0) goto LAB_0011a2b1;
  goto LAB_0011a26f;
}



void FUN_0011a330(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,undefined8 param_6)

{
  FUN_0011a200(param_1,10,param_2,param_3,param_4,param_5,param_6,0);
  return;
}



char * FUN_0011a360(void)

{
  int iVar1;
  uint *puVar2;
  char *__name;
  long lVar3;
  size_t sVar4;
  char *__ptr;
  long in_FS_OFFSET;
  long local_a0;
  char local_98 [104];
  long local_30;
  
  local_30 = *(long *)(in_FS_OFFSET + 0x28);
  __name = local_98;
  local_a0 = 100;
  puVar2 = (uint *)__errno_location();
  lVar3 = 100;
  __ptr = (char *)0x0;
  while( true ) {
    __name[lVar3 + -1] = '\0';
    *puVar2 = 0;
    iVar1 = gethostname(__name,lVar3 - 1U);
    if (iVar1 == 0) {
      sVar4 = strlen(__name);
      if ((long)(sVar4 + 1) < (long)(lVar3 - 1U)) {
        if (__ptr == (char *)0x0) {
          __ptr = (char *)FUN_0011a100(__name,sVar4 + 1);
        }
        goto LAB_0011a429;
      }
      *puVar2 = 0;
    }
    free(__ptr);
    if ((0x24 < *puVar2) || ((0xffffffefffbfeffeU >> ((ulong)*puVar2 & 0x3f) & 1) != 0)) break;
    __name = (char *)FUN_00119f30(0,&local_a0,1,0xffffffffffffffff,1);
    lVar3 = local_a0;
    __ptr = __name;
  }
  __ptr = (char *)0x0;
LAB_0011a429:
  if (local_30 == *(long *)(in_FS_OFFSET + 0x28)) {
    return __ptr;
  }
                    // WARNING: Subroutine does not return
  __stack_chk_fail();
}



void FUN_0011a470(uint param_1,int param_2,undefined1 param_3,long param_4,undefined8 param_5)

{
  undefined4 uVar1;
  undefined8 uVar2;
  char *pcVar3;
  undefined *puVar4;
  undefined1 *puVar5;
  long in_FS_OFFSET;
  undefined1 local_32;
  undefined1 local_31;
  undefined8 local_30;
  
  uVar1 = DAT_001271f8;
  local_30 = *(undefined8 *)(in_FS_OFFSET + 0x28);
  if (param_1 < 4) {
    pcVar3 = "invalid suffix in %s%s argument \'%s\'";
    if ((param_1 < 2) && (pcVar3 = "%s%s argument \'%s\' too large", param_1 != 1)) {
                    // WARNING: Subroutine does not return
      abort();
    }
  }
  else {
    pcVar3 = "invalid %s%s argument \'%s\'";
    if (param_1 != 4) {
                    // WARNING: Subroutine does not return
      abort();
    }
  }
  if (param_2 < 0) {
    puVar5 = &local_32;
    local_31 = 0;
    puVar4 = &DAT_0011d7d6 + -(long)param_2;
    local_32 = param_3;
  }
  else {
    puVar4 = &DAT_0011d7d6;
    puVar5 = *(undefined1 **)(param_4 + (long)param_2 * 0x20);
  }
  uVar2 = dcgettext("gnulib",pcVar3,5);
  error(uVar1,0,uVar2,puVar4,puVar5,param_5);
                    // WARNING: Subroutine does not return
  abort();
}



byte FUN_0011a540(byte *param_1,undefined8 *param_2,undefined4 param_3,ulong *param_4,char *param_5)

{
  byte bVar1;
  undefined1 auVar2 [16];
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  undefined1 auVar15 [16];
  undefined1 auVar16 [16];
  undefined1 auVar17 [16];
  undefined1 auVar18 [16];
  undefined1 auVar19 [16];
  undefined1 auVar20 [16];
  undefined1 auVar21 [16];
  undefined1 auVar22 [16];
  undefined1 auVar23 [16];
  undefined1 auVar24 [16];
  undefined1 auVar25 [16];
  undefined1 auVar26 [16];
  undefined1 auVar27 [16];
  undefined1 auVar28 [16];
  undefined1 auVar29 [16];
  undefined1 auVar30 [16];
  undefined1 auVar31 [16];
  undefined1 auVar32 [16];
  uint uVar33;
  ushort **ppuVar34;
  byte *pbVar35;
  int *piVar36;
  ulong uVar37;
  char *pcVar38;
  ulong uVar39;
  int iVar40;
  int iVar41;
  byte bVar42;
  ulong uVar43;
  byte bVar44;
  long in_FS_OFFSET;
  bool bVar45;
  bool bVar46;
  bool bVar47;
  bool bVar48;
  undefined8 local_48;
  long local_40;
  
  bVar44 = *param_1;
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  if (param_2 == (undefined8 *)0x0) {
    param_2 = &local_48;
  }
  ppuVar34 = __ctype_b_loc();
  bVar42 = *(byte *)((long)*ppuVar34 + (ulong)bVar44 * 2 + 1);
  pbVar35 = param_1;
  while ((bVar42 & 0x20) != 0) {
    bVar44 = pbVar35[1];
    pbVar35 = pbVar35 + 1;
    bVar42 = *(byte *)((long)*ppuVar34 + (ulong)bVar44 * 2 + 1);
  }
  if (bVar44 == 0x2d) {
    *param_2 = param_1;
    bVar44 = 4;
    goto LAB_0011a602;
  }
  piVar36 = __errno_location();
  *piVar36 = 0;
  uVar37 = __isoc23_strtoumax(param_1,param_2,param_3);
  pbVar35 = (byte *)*param_2;
  if (pbVar35 != param_1) {
    if (*piVar36 == 0) {
      bVar44 = 0;
    }
    else {
      bVar44 = 1;
      if (*piVar36 != 0x22) goto LAB_0011a63b;
    }
    if ((param_5 != (char *)0x0) && (bVar42 = *pbVar35, bVar42 != 0)) {
      pcVar38 = strchr(param_5,(int)(char)bVar42);
      uVar43 = uVar37;
      if (pcVar38 != (char *)0x0) goto LAB_0011a67a;
      goto switchD_0011a715_caseD_1;
    }
    goto LAB_0011a5ff;
  }
  if (((param_5 == (char *)0x0) || (bVar42 = *param_1, bVar42 == 0)) ||
     (pcVar38 = strchr(param_5,(int)(char)bVar42), pcVar38 == (char *)0x0)) {
LAB_0011a63b:
    bVar44 = 4;
    goto LAB_0011a602;
  }
  uVar43 = 1;
  bVar44 = 0;
LAB_0011a67a:
  uVar33 = bVar42 - 0x45;
  if ((((byte)uVar33 < 0x30) && ((0x81440030b945U >> ((ulong)uVar33 & 0x3f) & 1) != 0)) &&
     (pcVar38 = strchr(param_5,0x30), pcVar38 != (char *)0x0)) {
    bVar1 = pbVar35[1];
    if (bVar1 == 0x44) {
LAB_0011a6cc:
      iVar40 = 2;
      uVar39 = 1000;
    }
    else if (bVar1 == 0x69) {
      if (pbVar35[2] != 0x42) goto LAB_0011a6f0;
      iVar40 = 3;
      uVar39 = 0x400;
    }
    else {
      iVar40 = 1;
      uVar39 = 0x400;
      if (bVar1 == 0x42) goto LAB_0011a6cc;
    }
  }
  else {
LAB_0011a6f0:
    iVar40 = 1;
    uVar39 = 0x400;
  }
  uVar37 = uVar43;
  switch(bVar42 - 0x42 & 0xff) {
  case 0:
    auVar32._8_8_ = uVar43 >> 0x36;
    auVar32._0_8_ = uVar43 << 10;
    goto joined_r0x0011a83b;
  default:
switchD_0011a715_caseD_1:
    *param_4 = uVar43;
    bVar44 = bVar44 | 2;
    goto LAB_0011a602;
  case 3:
    iVar41 = 6;
    bVar42 = 0;
    do {
      auVar13._8_8_ = 0;
      auVar13._0_8_ = uVar37;
      auVar28._8_8_ = 0;
      auVar28._0_8_ = uVar39;
      uVar37 = SUB168(auVar13 * auVar28,0);
      if (SUB168(auVar13 * auVar28,8) != 0) {
        bVar42 = 1;
        uVar37 = 0xffffffffffffffff;
      }
      iVar41 = iVar41 + -1;
    } while (iVar41 != 0);
    break;
  case 5:
  case 0x25:
    auVar3._8_8_ = 0;
    auVar3._0_8_ = uVar43;
    auVar18._8_8_ = 0;
    auVar18._0_8_ = uVar39;
    uVar37 = SUB168(auVar3 * auVar18,0);
    bVar45 = SUB168(auVar3 * auVar18,8) != 0;
    if (bVar45) {
      uVar37 = 0xffffffffffffffff;
    }
    auVar4._8_8_ = 0;
    auVar4._0_8_ = uVar37;
    auVar19._8_8_ = 0;
    auVar19._0_8_ = uVar39;
    uVar37 = SUB168(auVar4 * auVar19,0);
    if (SUB168(auVar4 * auVar19,8) != 0) {
      bVar45 = true;
      uVar37 = 0xffffffffffffffff;
    }
    goto LAB_0011a7af;
  case 9:
  case 0x29:
    auVar2._8_8_ = 0;
    auVar2._0_8_ = (long)(int)uVar39;
    auVar17._8_8_ = 0;
    auVar17._0_8_ = uVar43;
    auVar32 = auVar2 * auVar17;
    goto joined_r0x0011a83b;
  case 0xb:
  case 0x2b:
    auVar6._8_8_ = 0;
    auVar6._0_8_ = uVar43;
    auVar21._8_8_ = 0;
    auVar21._0_8_ = uVar39;
    uVar37 = SUB168(auVar6 * auVar21,0);
    if (SUB168(auVar6 * auVar21,8) == 0) {
      bVar45 = false;
    }
    else {
      uVar37 = 0xffffffffffffffff;
      bVar45 = true;
    }
LAB_0011a7af:
    auVar5._8_8_ = 0;
    auVar5._0_8_ = uVar39;
    auVar20._8_8_ = 0;
    auVar20._0_8_ = uVar37;
    uVar37 = SUB168(auVar5 * auVar20,0);
    if (SUB168(auVar5 * auVar20,8) == 0) {
      bVar44 = bVar44 | bVar45;
      goto switchD_0011a715_caseD_21;
    }
    goto LAB_0011a820;
  case 0xe:
    iVar41 = 5;
    bVar42 = 0;
    do {
      auVar15._8_8_ = 0;
      auVar15._0_8_ = uVar43;
      auVar30._8_8_ = 0;
      auVar30._0_8_ = uVar39;
      uVar43 = SUB168(auVar15 * auVar30,0);
      if (SUB168(auVar15 * auVar30,8) != 0) {
        bVar42 = 1;
        uVar43 = 0xffffffffffffffff;
      }
      iVar41 = iVar41 + -1;
      uVar37 = uVar43;
    } while (iVar41 != 0);
    break;
  case 0xf:
    iVar41 = 10;
    bVar42 = 0;
    do {
      auVar16._8_8_ = 0;
      auVar16._0_8_ = uVar43;
      auVar31._8_8_ = 0;
      auVar31._0_8_ = uVar39;
      uVar43 = SUB168(auVar16 * auVar31,0);
      if (SUB168(auVar16 * auVar31,8) != 0) {
        bVar42 = 1;
        uVar43 = 0xffffffffffffffff;
      }
      iVar41 = iVar41 + -1;
      uVar37 = uVar43;
    } while (iVar41 != 0);
    break;
  case 0x10:
    iVar41 = 9;
    bVar42 = 0;
    do {
      auVar14._8_8_ = 0;
      auVar14._0_8_ = uVar43;
      auVar29._8_8_ = 0;
      auVar29._0_8_ = uVar39;
      uVar43 = SUB168(auVar14 * auVar29,0);
      if (SUB168(auVar14 * auVar29,8) != 0) {
        bVar42 = 1;
        uVar43 = 0xffffffffffffffff;
      }
      iVar41 = iVar41 + -1;
      uVar37 = uVar43;
    } while (iVar41 != 0);
    break;
  case 0x12:
  case 0x32:
    auVar7._8_8_ = 0;
    auVar7._0_8_ = uVar43;
    auVar22._8_8_ = 0;
    auVar22._0_8_ = uVar39;
    uVar37 = SUB168(auVar7 * auVar22,0);
    bVar45 = SUB168(auVar7 * auVar22,8) != 0;
    if (bVar45) {
      uVar37 = 0xffffffffffffffff;
    }
    auVar8._8_8_ = 0;
    auVar8._0_8_ = uVar37;
    auVar23._8_8_ = 0;
    auVar23._0_8_ = uVar39;
    uVar37 = SUB168(auVar8 * auVar23,0);
    bVar46 = SUB168(auVar8 * auVar23,8) != 0;
    if (bVar46) {
      uVar37 = 0xffffffffffffffff;
    }
    auVar9._8_8_ = 0;
    auVar9._0_8_ = uVar37;
    auVar24._8_8_ = 0;
    auVar24._0_8_ = uVar39;
    uVar37 = SUB168(auVar9 * auVar24,0);
    bVar47 = SUB168(auVar9 * auVar24,8) != 0;
    if (bVar47) {
      uVar37 = 0xffffffffffffffff;
    }
    auVar10._8_8_ = 0;
    auVar10._0_8_ = uVar39;
    auVar25._8_8_ = 0;
    auVar25._0_8_ = uVar37;
    uVar37 = SUB168(auVar10 * auVar25,0);
    bVar48 = SUB168(auVar10 * auVar25,8) != 0;
    if (bVar48) {
      uVar37 = 0xffffffffffffffff;
    }
    bVar44 = bVar44 | (bVar48 || (bVar47 || (bVar46 || bVar45)));
    goto switchD_0011a715_caseD_21;
  case 0x17:
    iVar41 = 8;
    bVar42 = 0;
    do {
      auVar11._8_8_ = 0;
      auVar11._0_8_ = uVar43;
      auVar26._8_8_ = 0;
      auVar26._0_8_ = uVar39;
      uVar43 = SUB168(auVar11 * auVar26,0);
      if (SUB168(auVar11 * auVar26,8) != 0) {
        bVar42 = 1;
        uVar43 = 0xffffffffffffffff;
      }
      iVar41 = iVar41 + -1;
      uVar37 = uVar43;
    } while (iVar41 != 0);
    break;
  case 0x18:
    iVar41 = 7;
    bVar42 = 0;
    do {
      auVar12._8_8_ = 0;
      auVar12._0_8_ = uVar43;
      auVar27._8_8_ = 0;
      auVar27._0_8_ = uVar39;
      uVar43 = SUB168(auVar12 * auVar27,0);
      if (SUB168(auVar12 * auVar27,8) != 0) {
        bVar42 = 1;
        uVar43 = 0xffffffffffffffff;
      }
      iVar41 = iVar41 + -1;
      uVar37 = uVar43;
    } while (iVar41 != 0);
    break;
  case 0x20:
    auVar32._8_8_ = uVar43 >> 0x37;
    auVar32._0_8_ = uVar43 << 9;
joined_r0x0011a83b:
    uVar37 = auVar32._0_8_;
    if (auVar32._8_8_ != 0) {
LAB_0011a820:
      bVar44 = 1;
      uVar37 = 0xffffffffffffffff;
    }
  case 0x21:
    goto switchD_0011a715_caseD_21;
  case 0x35:
    uVar37 = uVar43 * 2;
    if (-1 < (long)uVar43) goto switchD_0011a715_caseD_21;
    goto LAB_0011a820;
  }
  bVar44 = bVar44 | bVar42;
switchD_0011a715_caseD_21:
  *param_2 = pbVar35 + iVar40;
  if (pbVar35[iVar40] != 0) {
    bVar44 = bVar44 | 2;
  }
LAB_0011a5ff:
  *param_4 = uVar37;
LAB_0011a602:
  if (local_40 != *(long *)(in_FS_OFFSET + 0x28)) {
                    // WARNING: Subroutine does not return
    __stack_chk_fail();
  }
  return bVar44;
}



int FUN_0011aa10(long param_1,long param_2)

{
  uint uVar1;
  int iVar2;
  long lVar3;
  byte bVar4;
  uint uVar5;
  
  iVar2 = 0;
  if (param_1 != param_2) {
    lVar3 = 0;
    do {
      bVar4 = *(byte *)(param_1 + lVar3);
      uVar1 = (uint)bVar4;
      uVar5 = (uint)*(byte *)(param_2 + lVar3);
      if (uVar1 - 0x41 < 0x1a) {
        uVar1 = uVar1 + 0x20;
        bVar4 = bVar4 + 0x20;
        if (uVar5 - 0x41 < 0x1a) {
          uVar5 = uVar5 + 0x20;
        }
      }
      else {
        if (uVar5 - 0x41 < 0x1a) {
          uVar5 = uVar5 + 0x20;
        }
        if (uVar1 == 0) break;
      }
      lVar3 = lVar3 + 1;
    } while (bVar4 == (byte)uVar5);
    iVar2 = uVar1 - uVar5;
  }
  return iVar2;
}



ulong FUN_0011aa70(uint *param_1)

{
  uint uVar1;
  long lVar2;
  ulong uVar3;
  int *piVar4;
  
  lVar2 = __fpending();
  uVar1 = *param_1;
  uVar3 = FUN_0011aad0(param_1);
  if ((uVar1 & 0x20) == 0) {
    if ((int)uVar3 == 0) {
      return uVar3;
    }
    if (lVar2 == 0) {
      piVar4 = __errno_location();
      return (ulong)-(uint)(*piVar4 != 9);
    }
  }
  else if ((int)uVar3 == 0) {
    piVar4 = __errno_location();
    *piVar4 = 0;
  }
  return 0xffffffff;
}



int FUN_0011aad0(FILE *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  __off_t _Var4;
  
  iVar1 = fileno(param_1);
  if (-1 < iVar1) {
    iVar1 = __freading();
    if (iVar1 != 0) {
      iVar1 = fileno(param_1);
      _Var4 = lseek(iVar1,0,1);
      if (_Var4 == -1) goto LAB_0011ab3f;
    }
    iVar1 = FUN_0011ab60(param_1);
    if (iVar1 != 0) {
      piVar3 = __errno_location();
      iVar1 = *piVar3;
      iVar2 = fclose(param_1);
      if (iVar1 != 0) {
        *piVar3 = iVar1;
        iVar2 = -1;
      }
      return iVar2;
    }
  }
LAB_0011ab3f:
  iVar1 = fclose(param_1);
  return iVar1;
}



void FUN_0011ab60(FILE *param_1)

{
  int iVar1;
  
  if (param_1 != (FILE *)0x0) {
    iVar1 = __freading();
    if ((iVar1 != 0) && ((param_1->_flags & 0x100) != 0)) {
      FUN_0011aba0(param_1,0,1);
      fflush(param_1);
      return;
    }
  }
  fflush(param_1);
  return;
}



int FUN_0011aba0(FILE *param_1,__off_t param_2,int param_3)

{
  int iVar1;
  __off_t _Var2;
  
  if (((param_1->_IO_read_end == param_1->_IO_read_ptr) &&
      (param_1->_IO_write_ptr == param_1->_IO_write_base)) &&
     (param_1->_IO_save_base == (char *)0x0)) {
    iVar1 = fileno(param_1);
    _Var2 = lseek(iVar1,param_2,param_3);
    if (_Var2 == -1) {
      iVar1 = -1;
    }
    else {
      param_1->_flags = param_1->_flags & 0xffffffef;
      param_1->_offset = _Var2;
      iVar1 = 0;
    }
    return iVar1;
  }
  iVar1 = fseeko(param_1,param_2,param_3);
  return iVar1;
}



ulong FUN_0011ac20(char *param_1,ulong param_2)

{
  char cVar1;
  ulong uVar2;
  
  cVar1 = *param_1;
  if (cVar1 != '\0') {
    uVar2 = 0;
    do {
      param_1 = param_1 + 1;
      uVar2 = (uVar2 << 9 | uVar2 >> 0x37) + (long)cVar1;
      cVar1 = *param_1;
    } while (cVar1 != '\0');
    return uVar2 % param_2;
  }
  return 0;
}



char * FUN_0011ac70(void)

{
  char *pcVar1;
  
  pcVar1 = nl_langinfo(0xe);
  if (pcVar1 != (char *)0x0) {
    if (*pcVar1 == '\0') {
      pcVar1 = "ASCII";
    }
    return pcVar1;
  }
  return "ASCII";
}



void * FUN_0011acb0(void *param_1,ulong param_2,ulong param_3)

{
  undefined1 auVar1 [16];
  undefined1 auVar2 [16];
  size_t __size;
  void *pvVar3;
  int *piVar4;
  
  auVar1._8_8_ = 0;
  auVar1._0_8_ = param_2;
  auVar2._8_8_ = 0;
  auVar2._0_8_ = param_3;
  __size = SUB168(auVar1 * auVar2,0);
  if (SUB168(auVar1 * auVar2,8) == 0) {
    if (__size == 0) {
      __size = 1;
    }
    pvVar3 = realloc(param_1,__size);
    return pvVar3;
  }
  piVar4 = __errno_location();
  *piVar4 = 0xc;
  return (void *)0x0;
}



void FUN_0011ace0(undefined8 param_1)

{
  __cxa_atexit(param_1,0,PTR_LOOP_00127008);
  return;
}



void _DT_FINI(void)

{
  return;
}


